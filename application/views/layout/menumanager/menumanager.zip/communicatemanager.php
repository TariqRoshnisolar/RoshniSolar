<link rel="stylesheet" href="<?php echo base_url(); ?>backend/menumanager/style.css"/>

<div class="content-wrapper ">
    <section class="content-header">
        <h1>
            <i class="fa fa-bullhorn"></i>Communicate</h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">           
            <div class="col-md-12">             
                <div class="box box-primary">
                    <div class="box-header with-border">
                    
                    </div> 

                    <div class="box-body">
<div class="col-md-10 col-md-offset-2 boxbody">

<div class="col-md-4 managerhead">
<h2>
Communicate Manager
</h2>
</div>

<div class="col-md-4 descriptionhead">
<span class="managerdescription" style="border-bottom: 1px solid gray;margin-bottom: 18px;">Welcome</span>
<span class="managerdescription">User Name</span>
<span class="managerdescription">Communicate Manager</span>
</div>

            <!----
            <div class="welcome-logo slideRight">
                <img src="https://d1oukm3yurls9s.cloudfront.net/media/catalog/product/cache/image/265x265/beff4985b56e3afdbeabfc89641a4582/h/a/handling-fee-manager.jpg">
            </div>
            <div class="welcome-text slideLeft">
                <span class="welcome-text-w">Welcome</span><br>
                <span class="welcome-user">Atul Kumar Mishra</span>
                <hr>
                <span class="product-name">Academics Manager</span>
            </div>
            --->
                </div>
 </div>                   
                </div> 
            </div>
            
        </div> 
    </section>
</div>