<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-21 05:33:00 --> Severity: Compile Error --> Cannot use try without catch or finally C:\xampp\htdocs\smartschool\application\models\Mm_termsforexam_model.php 22
ERROR - 2019-02-21 05:43:36 --> Severity: Compile Error --> Cannot use try without catch or finally C:\xampp\htdocs\smartschool\application\models\Mm_termsforexam_model.php 22
ERROR - 2019-02-21 10:57:36 --> Severity: Notice --> Undefined variable: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\termsForExam.php 89
ERROR - 2019-02-21 10:57:36 --> Severity: Notice --> Undefined variable: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\termsForExam.php 105
ERROR - 2019-02-21 11:19:42 --> Could not find the language line "by_date1"
ERROR - 2019-02-21 10:13:40 --> Severity: Compile Error --> Cannot redeclare class Mm_termsforexam_model C:\xampp\htdocs\smartschool\application\models\Mm_examtype_model.php 133
ERROR - 2019-02-21 14:44:31 --> Could not find the language line "form_validation_check_exam_exists"
ERROR - 2019-02-21 16:47:55 --> Severity: Error --> Call to undefined function check_exam_exists_edit() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamtype.php 176
ERROR - 2019-02-21 16:49:26 --> Severity: Error --> Call to undefined function check_exam_exists_edit() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamtype.php 176
