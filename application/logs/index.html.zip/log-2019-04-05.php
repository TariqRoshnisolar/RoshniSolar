<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-05 06:33:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-04-05 06:33:54 --> Unable to connect to the database
ERROR - 2019-04-05 10:17:05 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:17:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:17:09 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:17:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:23:15 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:23:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\disablestudents.php 38
ERROR - 2019-04-05 10:23:15 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\smartschool\application\views\student\disablestudents.php 93
ERROR - 2019-04-05 10:23:46 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:23:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:23:58 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:23:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:27:32 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:27:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:27:41 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:27:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:27:52 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:27:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:28:05 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\disablestudents.php 38
ERROR - 2019-04-05 10:28:05 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\smartschool\application\views\student\disablestudents.php 93
ERROR - 2019-04-05 10:28:13 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:13 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:13 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:13 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:13 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:14 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:14 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:14 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:14 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:14 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:15 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:15 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:15 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:15 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:15 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:16 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:29 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:29 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:29 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:29 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:29 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:34 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:34 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:34 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:34 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:34 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:46 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:46 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:46 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:46 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:46 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:51 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:51 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:51 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:51 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:51 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:28:55 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:28:55 --> Could not find the language line "detail"
ERROR - 2019-04-05 10:28:55 --> Could not find the language line "file"
ERROR - 2019-04-05 10:28:55 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-05 10:28:55 --> Could not find the language line "Documents"
ERROR - 2019-04-05 10:29:26 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:29:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 10:29:42 --> Could not find the language line "student1"
ERROR - 2019-04-05 10:29:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-05 12:20:39 --> Could not find the language line "student_fee"
ERROR - 2019-04-05 12:20:39 --> Could not find the language line "back"
ERROR - 2019-04-05 12:21:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-04-05 12:22:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-04-05 12:22:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-05 12:22:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-05 12:42:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-05 12:43:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-05 15:44:28 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 90
ERROR - 2019-04-05 15:44:28 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 91
ERROR - 2019-04-05 15:44:28 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 90
ERROR - 2019-04-05 15:44:28 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 91
ERROR - 2019-04-05 15:44:28 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 90
ERROR - 2019-04-05 15:44:28 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 91
