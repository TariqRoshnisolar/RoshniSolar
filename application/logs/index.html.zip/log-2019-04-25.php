<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-25 09:47:21 --> Could not find the language line "student1"
ERROR - 2019-04-25 09:47:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-25 09:47:26 --> Could not find the language line "student1"
ERROR - 2019-04-25 09:47:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-25 09:47:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-25 09:47:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-25 09:47:47 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-25 09:47:47 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-25 09:47:47 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-25 10:26:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-25 10:26:28 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-25 10:26:28 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-25 10:26:28 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-25 12:06:20 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:06:20 --> Could not find the language line "back"
ERROR - 2019-04-25 12:06:20 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:07:10 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:07:10 --> Could not find the language line "back"
ERROR - 2019-04-25 12:07:10 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:07:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:55:09 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:55:09 --> Could not find the language line "back"
ERROR - 2019-04-25 12:55:09 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:55:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:55:23 --> Could not find the language line "back"
ERROR - 2019-04-25 12:55:23 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:55:37 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:55:37 --> Could not find the language line "back"
ERROR - 2019-04-25 12:55:37 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:55:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 12:57:19 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:57:19 --> Could not find the language line "back"
ERROR - 2019-04-25 12:57:19 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 12:57:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 12:58:49 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 12:58:49 --> Could not find the language line "back"
ERROR - 2019-04-25 12:58:49 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1153
ERROR - 2019-04-25 12:58:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1153
ERROR - 2019-04-25 13:03:41 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:03:41 --> Could not find the language line "back"
ERROR - 2019-04-25 13:03:41 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 13:03:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 13:04:21 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:04:21 --> Could not find the language line "back"
ERROR - 2019-04-25 13:04:21 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 13:04:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 13:04:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:04:46 --> Could not find the language line "back"
ERROR - 2019-04-25 13:04:46 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 13:04:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 13:06:42 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:06:42 --> Could not find the language line "back"
ERROR - 2019-04-25 13:06:42 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:06:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:09:28 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:09:28 --> Could not find the language line "back"
ERROR - 2019-04-25 13:09:28 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:10:29 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:10:29 --> Could not find the language line "back"
ERROR - 2019-04-25 13:10:29 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1180
ERROR - 2019-04-25 13:10:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1180
ERROR - 2019-04-25 13:12:04 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:12:04 --> Could not find the language line "back"
ERROR - 2019-04-25 13:12:04 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:12:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:12:29 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:12:29 --> Could not find the language line "back"
ERROR - 2019-04-25 13:12:29 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 13:15:18 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:15:18 --> Could not find the language line "back"
ERROR - 2019-04-25 13:15:18 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 13:15:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 13:16:40 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:16:40 --> Could not find the language line "back"
ERROR - 2019-04-25 13:16:40 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 13:16:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 13:19:47 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:19:47 --> Could not find the language line "back"
ERROR - 2019-04-25 13:19:47 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 13:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 13:24:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:24:13 --> Could not find the language line "back"
ERROR - 2019-04-25 13:24:13 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1187
ERROR - 2019-04-25 13:24:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1187
ERROR - 2019-04-25 13:25:58 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:25:58 --> Could not find the language line "back"
ERROR - 2019-04-25 13:25:58 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1188
ERROR - 2019-04-25 13:25:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1188
ERROR - 2019-04-25 13:27:54 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:27:54 --> Could not find the language line "back"
ERROR - 2019-04-25 13:27:54 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:27:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:38:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:38:13 --> Could not find the language line "back"
ERROR - 2019-04-25 13:38:13 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:38:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:38:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:38:46 --> Could not find the language line "back"
ERROR - 2019-04-25 13:38:46 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:40:30 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 13:40:30 --> Could not find the language line "back"
ERROR - 2019-04-25 13:40:30 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 13:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1189
ERROR - 2019-04-25 14:48:28 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:48:28 --> Could not find the language line "back"
ERROR - 2019-04-25 14:48:28 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1191
ERROR - 2019-04-25 14:48:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1191
ERROR - 2019-04-25 14:49:15 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:49:15 --> Could not find the language line "back"
ERROR - 2019-04-25 14:49:15 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:49:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:49:48 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:49:48 --> Could not find the language line "back"
ERROR - 2019-04-25 14:49:48 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:50:34 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:50:34 --> Could not find the language line "back"
ERROR - 2019-04-25 14:50:34 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:53:03 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:53:03 --> Could not find the language line "back"
ERROR - 2019-04-25 14:53:03 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1192
ERROR - 2019-04-25 14:58:39 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:58:39 --> Could not find the language line "back"
ERROR - 2019-04-25 14:58:39 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 14:58:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 14:59:07 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 14:59:07 --> Could not find the language line "back"
ERROR - 2019-04-25 14:59:07 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 14:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:00:19 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:00:19 --> Could not find the language line "back"
ERROR - 2019-04-25 15:00:19 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1205
ERROR - 2019-04-25 15:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1205
ERROR - 2019-04-25 15:01:14 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:01:14 --> Could not find the language line "back"
ERROR - 2019-04-25 15:01:14 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1205
ERROR - 2019-04-25 15:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1205
ERROR - 2019-04-25 15:03:02 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:03:02 --> Could not find the language line "back"
ERROR - 2019-04-25 15:03:02 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1205
ERROR - 2019-04-25 15:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1205
ERROR - 2019-04-25 15:08:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:08:13 --> Could not find the language line "back"
ERROR - 2019-04-25 15:08:13 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1210
ERROR - 2019-04-25 15:08:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1210
ERROR - 2019-04-25 15:14:30 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:14:30 --> Could not find the language line "back"
ERROR - 2019-04-25 15:14:30 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1210
ERROR - 2019-04-25 15:14:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1210
ERROR - 2019-04-25 15:19:17 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:19:17 --> Could not find the language line "back"
ERROR - 2019-04-25 15:19:17 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1206
ERROR - 2019-04-25 15:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1206
ERROR - 2019-04-25 15:20:55 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:20:55 --> Could not find the language line "back"
ERROR - 2019-04-25 15:20:55 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:20:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:24:07 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:24:07 --> Could not find the language line "back"
ERROR - 2019-04-25 15:24:07 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:24:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:24:40 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:24:40 --> Could not find the language line "back"
ERROR - 2019-04-25 15:24:40 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:24:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:24:57 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:24:57 --> Could not find the language line "back"
ERROR - 2019-04-25 15:24:57 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1207
ERROR - 2019-04-25 15:26:00 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:26:00 --> Could not find the language line "back"
ERROR - 2019-04-25 15:26:00 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:26:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:26:57 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:26:57 --> Could not find the language line "back"
ERROR - 2019-04-25 15:26:57 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:27:51 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:27:51 --> Could not find the language line "back"
ERROR - 2019-04-25 15:27:51 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:28:48 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:28:48 --> Could not find the language line "back"
ERROR - 2019-04-25 15:28:48 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1202
ERROR - 2019-04-25 15:30:05 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:30:05 --> Could not find the language line "back"
ERROR - 2019-04-25 15:30:05 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:30:52 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:30:52 --> Could not find the language line "back"
ERROR - 2019-04-25 15:30:52 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:31:16 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:31:16 --> Could not find the language line "back"
ERROR - 2019-04-25 15:31:16 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:31:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:31:53 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:31:53 --> Could not find the language line "back"
ERROR - 2019-04-25 15:31:53 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:31:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:32:52 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:32:52 --> Could not find the language line "back"
ERROR - 2019-04-25 15:32:52 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:32:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:33:45 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:33:45 --> Could not find the language line "back"
ERROR - 2019-04-25 15:33:45 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1194
ERROR - 2019-04-25 15:38:09 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:38:09 --> Could not find the language line "back"
ERROR - 2019-04-25 15:38:09 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 15:38:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 15:39:33 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:39:33 --> Could not find the language line "back"
ERROR - 2019-04-25 15:39:33 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:40:36 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:40:36 --> Could not find the language line "back"
ERROR - 2019-04-25 15:40:36 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:40:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:40:50 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:40:50 --> Could not find the language line "back"
ERROR - 2019-04-25 15:40:50 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:41:05 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:41:05 --> Could not find the language line "back"
ERROR - 2019-04-25 15:41:05 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:41:20 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:41:20 --> Could not find the language line "back"
ERROR - 2019-04-25 15:41:20 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:41:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:44:49 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:44:49 --> Could not find the language line "back"
ERROR - 2019-04-25 15:44:49 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:44:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1184
ERROR - 2019-04-25 15:45:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:45:46 --> Could not find the language line "back"
ERROR - 2019-04-25 15:45:46 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1180
ERROR - 2019-04-25 15:45:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1180
ERROR - 2019-04-25 15:48:11 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:48:11 --> Could not find the language line "back"
ERROR - 2019-04-25 15:48:11 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1180
ERROR - 2019-04-25 15:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1180
ERROR - 2019-04-25 15:49:05 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:49:05 --> Could not find the language line "back"
ERROR - 2019-04-25 15:49:05 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 15:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 15:50:06 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:50:06 --> Could not find the language line "back"
ERROR - 2019-04-25 15:50:06 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 15:50:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 15:53:24 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:53:24 --> Could not find the language line "back"
ERROR - 2019-04-25 15:53:24 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:53:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:54:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:54:13 --> Could not find the language line "back"
ERROR - 2019-04-25 15:54:13 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:54:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:54:38 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:54:38 --> Could not find the language line "back"
ERROR - 2019-04-25 15:54:38 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:54:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:56:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:56:46 --> Could not find the language line "back"
ERROR - 2019-04-25 15:56:46 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1178
ERROR - 2019-04-25 15:58:07 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:58:07 --> Could not find the language line "back"
ERROR - 2019-04-25 15:58:07 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1177
ERROR - 2019-04-25 15:58:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1177
ERROR - 2019-04-25 15:59:39 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 15:59:39 --> Could not find the language line "back"
ERROR - 2019-04-25 15:59:39 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 15:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:00:12 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:00:12 --> Could not find the language line "back"
ERROR - 2019-04-25 16:00:12 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:00:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:00:44 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:00:44 --> Could not find the language line "back"
ERROR - 2019-04-25 16:00:44 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 16:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1174
ERROR - 2019-04-25 16:02:41 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:02:41 --> Could not find the language line "back"
ERROR - 2019-04-25 16:02:41 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:02:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:03:19 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:03:19 --> Could not find the language line "back"
ERROR - 2019-04-25 16:03:19 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:03:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:03:36 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:03:36 --> Could not find the language line "back"
ERROR - 2019-04-25 16:03:36 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:03:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:04:26 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:04:26 --> Could not find the language line "back"
ERROR - 2019-04-25 16:04:26 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1177
ERROR - 2019-04-25 16:04:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1177
ERROR - 2019-04-25 16:06:04 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:06:04 --> Could not find the language line "back"
ERROR - 2019-04-25 16:06:04 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:09:01 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:09:01 --> Could not find the language line "back"
ERROR - 2019-04-25 16:09:01 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:10:42 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:10:42 --> Could not find the language line "back"
ERROR - 2019-04-25 16:10:42 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:10:56 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:10:56 --> Could not find the language line "back"
ERROR - 2019-04-25 16:10:56 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:11:06 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:11:06 --> Could not find the language line "back"
ERROR - 2019-04-25 16:11:06 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:13:09 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:13:09 --> Could not find the language line "back"
ERROR - 2019-04-25 16:13:09 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1176
ERROR - 2019-04-25 16:16:03 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:16:03 --> Could not find the language line "back"
ERROR - 2019-04-25 16:16:03 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:17:06 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:17:06 --> Could not find the language line "back"
ERROR - 2019-04-25 16:17:06 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1183
ERROR - 2019-04-25 16:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1183
ERROR - 2019-04-25 16:17:26 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:17:26 --> Could not find the language line "back"
ERROR - 2019-04-25 16:17:26 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:17:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:18:18 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:18:18 --> Could not find the language line "back"
ERROR - 2019-04-25 16:18:18 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:18:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:18:37 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:18:37 --> Could not find the language line "back"
ERROR - 2019-04-25 16:18:37 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:19:15 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:19:15 --> Could not find the language line "back"
ERROR - 2019-04-25 16:19:15 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:22:02 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:22:02 --> Could not find the language line "back"
ERROR - 2019-04-25 16:22:02 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:22:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:22:15 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:22:15 --> Could not find the language line "back"
ERROR - 2019-04-25 16:22:15 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:22:36 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:22:36 --> Could not find the language line "back"
ERROR - 2019-04-25 16:22:36 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:22:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1181
ERROR - 2019-04-25 16:24:35 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:24:35 --> Could not find the language line "back"
ERROR - 2019-04-25 16:24:35 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:24:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:26:49 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:26:49 --> Could not find the language line "back"
ERROR - 2019-04-25 16:26:49 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:26:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:31:16 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:31:16 --> Could not find the language line "back"
ERROR - 2019-04-25 16:31:16 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:31:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:32:10 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:32:10 --> Could not find the language line "back"
ERROR - 2019-04-25 16:32:10 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:33:49 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:33:49 --> Could not find the language line "back"
ERROR - 2019-04-25 16:33:49 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:33:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:34:36 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:34:36 --> Could not find the language line "back"
ERROR - 2019-04-25 16:34:36 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:34:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:37:03 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:37:03 --> Could not find the language line "back"
ERROR - 2019-04-25 16:37:03 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:37:22 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:37:22 --> Could not find the language line "back"
ERROR - 2019-04-25 16:37:22 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:37:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:40:41 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:40:41 --> Could not find the language line "back"
ERROR - 2019-04-25 16:40:41 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:40:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:41:33 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:41:33 --> Could not find the language line "back"
ERROR - 2019-04-25 16:41:33 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1182
ERROR - 2019-04-25 16:42:04 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:42:04 --> Could not find the language line "back"
ERROR - 2019-04-25 16:42:04 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:44:57 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:44:57 --> Could not find the language line "back"
ERROR - 2019-04-25 16:44:57 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:46:14 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:46:14 --> Could not find the language line "back"
ERROR - 2019-04-25 16:46:14 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:46:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:46:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:46:46 --> Could not find the language line "back"
ERROR - 2019-04-25 16:46:46 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:47:19 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:47:19 --> Could not find the language line "back"
ERROR - 2019-04-25 16:47:19 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:47:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:49:05 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:49:05 --> Could not find the language line "back"
ERROR - 2019-04-25 16:49:05 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1173
ERROR - 2019-04-25 16:50:15 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:50:15 --> Could not find the language line "back"
ERROR - 2019-04-25 16:50:15 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:52:07 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:52:07 --> Could not find the language line "back"
ERROR - 2019-04-25 16:52:07 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:55:26 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:55:26 --> Could not find the language line "back"
ERROR - 2019-04-25 16:55:26 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:56:19 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 16:56:19 --> Could not find the language line "back"
ERROR - 2019-04-25 16:56:19 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:06:22 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:06:22 --> Could not find the language line "back"
ERROR - 2019-04-25 17:06:22 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:10:36 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:10:36 --> Could not find the language line "back"
ERROR - 2019-04-25 17:10:36 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:10:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:11:04 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:11:04 --> Could not find the language line "back"
ERROR - 2019-04-25 17:11:04 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:11:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:19:34 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:19:34 --> Could not find the language line "back"
ERROR - 2019-04-25 17:19:34 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:23:48 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:23:48 --> Could not find the language line "back"
ERROR - 2019-04-25 17:23:48 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:23:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:27:44 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:27:44 --> Could not find the language line "back"
ERROR - 2019-04-25 17:27:44 --> Severity: Warning --> Wrong parameter count for number_format() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1039
ERROR - 2019-04-25 17:27:44 --> Severity: Warning --> Wrong parameter count for number_format() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1039
ERROR - 2019-04-25 17:27:44 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:27:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:27:55 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:27:55 --> Could not find the language line "back"
ERROR - 2019-04-25 17:27:55 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:27:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:33:21 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:33:21 --> Could not find the language line "back"
ERROR - 2019-04-25 17:33:21 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:36:05 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:36:05 --> Could not find the language line "back"
ERROR - 2019-04-25 17:36:05 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:37:45 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:37:45 --> Could not find the language line "back"
ERROR - 2019-04-25 17:37:45 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:39:01 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:39:01 --> Could not find the language line "back"
ERROR - 2019-04-25 17:39:01 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:40:05 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:40:05 --> Could not find the language line "back"
ERROR - 2019-04-25 17:40:05 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:40:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:42:09 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:42:09 --> Could not find the language line "back"
ERROR - 2019-04-25 17:42:09 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:47:53 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:47:53 --> Could not find the language line "back"
ERROR - 2019-04-25 17:47:53 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:48:47 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:48:47 --> Could not find the language line "back"
ERROR - 2019-04-25 17:48:47 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:49:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:49:23 --> Could not find the language line "back"
ERROR - 2019-04-25 17:49:23 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:49:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:49:52 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:49:52 --> Could not find the language line "back"
ERROR - 2019-04-25 17:49:52 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:49:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:52:29 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:52:29 --> Could not find the language line "back"
ERROR - 2019-04-25 17:52:29 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:52:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:53:14 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:53:14 --> Could not find the language line "back"
ERROR - 2019-04-25 17:53:14 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:55:45 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:55:45 --> Could not find the language line "back"
ERROR - 2019-04-25 17:55:45 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:55:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:56:52 --> Could not find the language line "student_fee"
ERROR - 2019-04-25 17:56:52 --> Could not find the language line "back"
ERROR - 2019-04-25 17:56:52 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-25 17:56:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
