<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-28 13:20:28 --> Could not find the language line "form_validation_subjectcodeuniquetest"
ERROR - 2019-01-28 13:27:48 --> Severity: Error --> Call to undefined method Subject_model::check_code_exists() C:\xampp\htdocs\smartschool\application\controllers\admin\Subject.php 89
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: role_name C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 32
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 37
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 38
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 44
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 47
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 53
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: message C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 57
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: attach_file C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 60
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: publish_date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 71
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 72
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: created_by C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 74
ERROR - 2019-01-28 14:46:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 79
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: visible_student C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 87
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: visible_parent C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 90
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:46:13 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: role_name C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 32
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 37
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 38
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 44
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 47
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 53
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: message C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 57
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: attach_file C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 60
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: publish_date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 71
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 72
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: created_by C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 74
ERROR - 2019-01-28 14:46:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 79
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: visible_student C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 87
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: visible_parent C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 90
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:46:30 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:47:10 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:47:10 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:47:10 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: role_name C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 32
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 37
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 38
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 44
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 47
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 53
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: message C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 57
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: attach_file C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 60
ERROR - 2019-01-28 14:47:32 --> Severity: Notice --> Undefined index: publish_date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 71
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 72
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined index: created_by C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 74
ERROR - 2019-01-28 14:47:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 79
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined index: visible_student C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 87
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined index: visible_parent C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 90
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 14:47:33 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-28 15:20:42 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:21:19 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:21:38 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:21:54 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:26:54 --> Severity: Notice --> Undefined variable: sms_content C:\xampp\htdocs\smartschool\application\controllers\admin\Sendcredential.php 198
ERROR - 2019-01-28 15:26:55 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:27:45 --> Severity: Notice --> Undefined variable: sms_content C:\xampp\htdocs\smartschool\application\controllers\admin\Sendcredential.php 198
ERROR - 2019-01-28 15:28:06 --> Severity: Notice --> Undefined variable: sms_content C:\xampp\htdocs\smartschool\application\controllers\admin\Sendcredential.php 198
ERROR - 2019-01-28 15:28:16 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:29:04 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:42:51 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:43:12 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:43:24 --> Severity: Notice --> Undefined variable: sms_content C:\xampp\htdocs\smartschool\application\controllers\admin\Sendcredential.php 198
ERROR - 2019-01-28 15:48:07 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:48:22 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:48:25 --> Severity: Notice --> Undefined variable: sms_content C:\xampp\htdocs\smartschool\application\controllers\admin\Sendcredential.php 127
ERROR - 2019-01-28 15:48:25 --> Severity: Notice --> Undefined variable: sms_content C:\xampp\htdocs\smartschool\application\controllers\admin\Sendcredential.php 130
ERROR - 2019-01-28 15:48:25 --> Query error: Column 'content' cannot be null - Invalid query: INSERT INTO `composesmsreport` (`name`, `mobile`, `sender_id`, `date`, `smstype`, `content`, `empid`, `admino`, `class_section`) VALUES ('Super Admin ', '8745956993', '0', '2019-01-28 15:48:25', '14', NULL, '', '', '')
ERROR - 2019-01-28 15:53:57 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:54:13 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 15:54:23 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:01:09 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:01:21 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:01:27 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:01:34 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:03:03 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:03:31 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:03:34 --> Could not find the language line "by_date1"
ERROR - 2019-01-28 16:36:33 --> Could not find the language line "student_fees1"
ERROR - 2019-01-28 16:36:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-28 16:54:28 --> Could not find the language line "student_fees1"
ERROR - 2019-01-28 16:54:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-28 16:54:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-28 17:09:04 --> Could not find the language line "student_fees1"
ERROR - 2019-01-28 17:09:04 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-28 17:09:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-28 17:09:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-28 17:09:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-28 17:09:42 --> Could not find the language line "student_fees1"
ERROR - 2019-01-28 17:09:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-28 17:11:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
