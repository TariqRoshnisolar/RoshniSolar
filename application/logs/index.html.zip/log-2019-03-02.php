<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-02 10:45:37 --> Could not find the language line "student_fee"
ERROR - 2019-03-02 10:45:37 --> Could not find the language line "back"
ERROR - 2019-03-02 11:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\gradeScaleForSubject.php 43
ERROR - 2019-03-02 11:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\gradeScaleForSubject.php 118
ERROR - 2019-03-02 11:40:46 --> Severity: Parsing Error --> syntax error, unexpected '>' C:\xampp\htdocs\smartschool\application\models\Mm_subjectwisemarksentry_model.php 77
ERROR - 2019-03-02 12:06:14 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\smartschool\application\models\Mm_subjectwisemarksentry_model.php 93
