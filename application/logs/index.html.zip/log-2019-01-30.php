<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-30 11:42:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_driver.php 1477
ERROR - 2019-01-30 11:42:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_driver.php 1477
ERROR - 2019-01-30 11:42:09 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `mm_subjects` (`classsection`, `subject`) VALUES (Array, Array)
ERROR - 2019-01-30 12:18:00 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:18:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-30 12:18:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-30 12:21:07 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:21:07 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-01-30 12:21:15 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:21:15 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:21:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:21:29 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:21:29 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:21:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:22:11 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:22:11 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:22:38 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:22:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-30 12:22:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-30 12:23:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-30 12:23:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-30 12:23:13 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:23:13 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:24:34 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:24:34 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:24:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-01-30 12:24:57 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 12:24:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-30 12:28:57 --> Could not find the language line "detail"
ERROR - 2019-01-30 12:28:57 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 676
ERROR - 2019-01-30 12:28:57 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 686
ERROR - 2019-01-30 12:28:57 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 696
ERROR - 2019-01-30 12:28:57 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 706
ERROR - 2019-01-30 12:28:57 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 716
ERROR - 2019-01-30 13:15:19 --> Could not find the language line "setting1"
ERROR - 2019-01-30 13:16:07 --> Could not find the language line "student1"
ERROR - 2019-01-30 13:16:07 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-01-30 13:16:11 --> Could not find the language line "student1"
ERROR - 2019-01-30 13:16:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-01-30 13:19:53 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 13:20:09 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 13:20:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-01-30 13:20:14 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 13:20:14 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-01-30 13:20:20 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 13:20:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-01-30 13:20:30 --> Could not find the language line "student_fees1"
ERROR - 2019-01-30 13:20:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-01-30 13:25:35 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-01-30 13:25:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-01-30 13:25:42 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-01-30 13:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-01-30 13:26:25 --> Could not find the language line "by_date1"
ERROR - 2019-01-30 13:26:33 --> Could not find the language line "by_date1"
ERROR - 2019-01-30 13:26:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\stuattendence\attendenceList.php 125
ERROR - 2019-01-30 13:26:42 --> Could not find the language line "by_date1"
ERROR - 2019-01-30 13:26:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\stuattendence\attendenceList.php 125
ERROR - 2019-01-30 08:57:08 --> Severity: Parsing Error --> syntax error, unexpected '$e' (T_VARIABLE), expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjecttoclass.php 59
ERROR - 2019-01-30 13:27:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examList.php 37
ERROR - 2019-01-30 13:27:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examList.php 37
ERROR - 2019-01-30 13:27:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\mark\markList.php 67
ERROR - 2019-01-30 13:27:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\mark\markCreate.php 62
ERROR - 2019-01-30 13:28:32 --> Could not find the language line "detail"
ERROR - 2019-01-30 13:28:32 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 676
ERROR - 2019-01-30 13:28:32 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 686
ERROR - 2019-01-30 13:28:32 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 696
ERROR - 2019-01-30 13:28:32 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 706
ERROR - 2019-01-30 13:28:32 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 716
ERROR - 2019-01-30 13:28:50 --> Could not find the language line "detail"
ERROR - 2019-01-30 13:28:50 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 676
ERROR - 2019-01-30 13:28:50 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 686
ERROR - 2019-01-30 13:28:50 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 696
ERROR - 2019-01-30 13:28:50 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 706
ERROR - 2019-01-30 13:28:50 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 716
ERROR - 2019-01-30 13:29:43 --> Could not find the language line "detail"
ERROR - 2019-01-30 13:29:43 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 676
ERROR - 2019-01-30 13:29:43 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 686
ERROR - 2019-01-30 13:29:43 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 696
ERROR - 2019-01-30 13:29:43 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 706
ERROR - 2019-01-30 13:29:43 --> Severity: Notice --> Undefined offset: 2019 C:\xampp\htdocs\smartschool\application\views\admin\staff\staffprofile.php 716
ERROR - 2019-01-30 13:30:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\homework\homeworklist.php 40
ERROR - 2019-01-30 13:30:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\homework\homework_evaluation.php 40
ERROR - 2019-01-30 13:30:29 --> Could not find the language line "by_date1"
ERROR - 2019-01-30 13:31:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\book\getall.php 56
ERROR - 2019-01-30 13:31:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\route\studentroutedetails.php 105
ERROR - 2019-01-30 13:32:59 --> Could not find the language line "filter_by_name1"
ERROR - 2019-01-30 13:32:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentReport.php 30
ERROR - 2019-01-30 13:33:12 --> Could not find the language line "filter_by_name1"
ERROR - 2019-01-30 13:33:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentReport.php 30
ERROR - 2019-01-30 13:33:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-01-30 13:33:25 --> Could not find the language line "student1"
ERROR - 2019-01-30 13:33:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\disablestudents.php 38
ERROR - 2019-01-30 13:33:25 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\smartschool\application\views\student\disablestudents.php 93
ERROR - 2019-01-30 13:33:33 --> Could not find the language line "filter_by_name1"
ERROR - 2019-01-30 13:33:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentReport.php 30
ERROR - 2019-01-30 13:33:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\guardianReport.php 106
ERROR - 2019-01-30 13:33:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\users\logindetailreport.php 106
ERROR - 2019-01-30 13:33:49 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\users\logindetailreport.php 106
ERROR - 2019-01-30 13:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\users\admissionReport.php 106
ERROR - 2019-01-30 13:34:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\users\admissionReport.php 106
ERROR - 2019-01-30 09:42:44 --> Severity: Parsing Error --> syntax error, unexpected '$e' (T_VARIABLE), expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjecttoclass.php 59
ERROR - 2019-01-30 15:52:59 --> Could not find the language line "student1"
ERROR - 2019-01-30 15:52:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-01-30 15:54:12 --> Could not find the language line "student1"
ERROR - 2019-01-30 15:54:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
