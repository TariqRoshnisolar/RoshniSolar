<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-04 10:37:16 --> Could not find the language line "student_fee"
ERROR - 2019-04-04 10:37:16 --> Could not find the language line "back"
ERROR - 2019-04-04 11:28:13 --> Query error: Unknown column 'stu_fee_detail.yearsession.yearsession' in 'where clause' - Invalid query: select * 
                   from stu_fee_detail
                   left join stu_fee_amount on (stu_fee_detail.id = stu_fee_amount.receipt_id and stu_fee_amount.is_deleted = 0)
                   left join class_sections on (class_sections.id = stu_fee_detail.classsection and class_sections.is_active = 'yes')
                   where class_sections.class_id = 1
                   and class_sections.section_id = 100
                   and stu_fee_detail.feetype = 1
                   and stu_fee_detail.feegroup = 1
                   and stu_fee_detail.yearsession.yearsession = 14
                   and stu_fee_detail.is_deleted = 0
                  
ERROR - 2019-04-04 11:53:26 --> Query error: Unknown column 'pay_mode.is_active' in 'on clause' - Invalid query: select students.firstname, students.lastname, students.admission_no, students.mobileno, students.father_name, pay_mode.name as pay_mode, stu_fee_detail.totalamt  
                   from stu_fee_detail
                   left join class_sections on (class_sections.id = stu_fee_detail.classsection and class_sections.is_active = 'yes')
                   left join students on (students.id = stu_fee_detail.student and students.is_active = 'yes')
                   left join pay_mode on (pay_mode.id = stu_fee_detail.paymode and pay_mode.is_active = 'yes')
                   where class_sections.class_id = 1
                   and class_sections.section_id = 100
                   and stu_fee_detail.feetype = 1
                   and stu_fee_detail.feegroup = 1
                   and stu_fee_detail.yearsession = 14
                   and stu_fee_detail.is_deleted = 0
                  
ERROR - 2019-04-04 12:12:59 --> Could not find the language line "student1"
ERROR - 2019-04-04 12:12:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 12:13:03 --> Could not find the language line "student1"
ERROR - 2019-04-04 12:13:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:02:06 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:02:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:02:12 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:02:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:02:43 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:02:43 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:02:43 --> Could not find the language line "file"
ERROR - 2019-04-04 15:02:43 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:02:43 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:25:46 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:25:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:25:50 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:25:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:31:40 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:31:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:31:55 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:31:55 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:31:55 --> Could not find the language line "file"
ERROR - 2019-04-04 15:31:55 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:31:55 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:33:36 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:33:36 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:33:36 --> Could not find the language line "file"
ERROR - 2019-04-04 15:33:36 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:33:36 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:39:10 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:39:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:39:25 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:39:25 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:39:25 --> Could not find the language line "file"
ERROR - 2019-04-04 15:39:25 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:39:25 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:39:43 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:39:43 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:39:43 --> Could not find the language line "file"
ERROR - 2019-04-04 15:39:43 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:39:43 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:39:53 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:39:53 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:39:53 --> Could not find the language line "file"
ERROR - 2019-04-04 15:39:53 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:39:53 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:40:07 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:40:07 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:40:07 --> Could not find the language line "file"
ERROR - 2019-04-04 15:40:07 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:40:07 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:40:22 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:40:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:40:25 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:40:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:41:10 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:41:10 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:41:10 --> Could not find the language line "file"
ERROR - 2019-04-04 15:41:10 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:41:10 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:41:20 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:41:20 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:41:20 --> Could not find the language line "file"
ERROR - 2019-04-04 15:41:20 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:41:20 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:41:32 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:41:32 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:41:32 --> Could not find the language line "file"
ERROR - 2019-04-04 15:41:32 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:41:32 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:41:56 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:41:56 --> Could not find the language line "detail"
ERROR - 2019-04-04 15:41:56 --> Could not find the language line "file"
ERROR - 2019-04-04 15:41:56 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 15:41:56 --> Could not find the language line "Documents"
ERROR - 2019-04-04 15:47:03 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:47:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:47:03 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 251
ERROR - 2019-04-04 15:47:03 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 276
ERROR - 2019-04-04 15:47:35 --> Could not find the language line "student1"
ERROR - 2019-04-04 15:47:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 15:47:35 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 251
ERROR - 2019-04-04 15:47:35 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 276
ERROR - 2019-04-04 16:02:34 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:02:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:02:43 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:02:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:03:28 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:03:28 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:03:28 --> Could not find the language line "file"
ERROR - 2019-04-04 16:03:28 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:03:28 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:04:02 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:04:02 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:04:02 --> Could not find the language line "file"
ERROR - 2019-04-04 16:04:02 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:04:02 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:04:12 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:04:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:04:16 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:04:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:17:27 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:17:27 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:17:27 --> Could not find the language line "file"
ERROR - 2019-04-04 16:17:27 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:17:27 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:18:26 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:18:26 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:18:26 --> Could not find the language line "file"
ERROR - 2019-04-04 16:18:26 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:18:26 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:18:37 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:18:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:37:28 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:37:28 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:37:28 --> Could not find the language line "file"
ERROR - 2019-04-04 16:37:28 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:37:28 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:46:14 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:46:14 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:46:31 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `users` SET `id` = '1', `status` = 'no'
WHERE `id` = '1'
ERROR - 2019-04-04 16:46:32 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:46:32 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:46:32 --> Could not find the language line "file"
ERROR - 2019-04-04 16:46:32 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:46:32 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:46:44 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:46:44 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:46:44 --> Could not find the language line "file"
ERROR - 2019-04-04 16:46:44 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:46:44 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:46:50 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:46:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:46:56 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:46:56 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:46:56 --> Could not find the language line "file"
ERROR - 2019-04-04 16:46:57 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:46:57 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:49:01 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:49:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:49:07 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:49:07 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:49:19 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `users` SET `id` = '1', `status` = 'no'
WHERE `id` = '1'
ERROR - 2019-04-04 16:49:19 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:49:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:49:26 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:49:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:49:34 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:49:34 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:49:34 --> Could not find the language line "file"
ERROR - 2019-04-04 16:49:34 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:49:34 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:49:59 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:49:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:50:07 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:50:07 --> Could not find the language line "detail"
ERROR - 2019-04-04 16:50:07 --> Could not find the language line "file"
ERROR - 2019-04-04 16:50:07 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 16:50:07 --> Could not find the language line "Documents"
ERROR - 2019-04-04 16:51:08 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:51:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:51:35 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `users` SET `id` = '2', `status` = 'no'
WHERE `id` = '2'
ERROR - 2019-04-04 16:51:35 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:51:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:51:45 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:51:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:51:51 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:51:51 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:51:57 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `users` SET `id` = '3', `status` = 'no'
WHERE `id` = '3'
ERROR - 2019-04-04 16:51:58 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:51:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:53:33 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:53:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:55:04 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:55:04 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:55:44 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:55:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:55:51 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:55:51 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:57:06 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:57:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 16:57:12 --> Could not find the language line "student1"
ERROR - 2019-04-04 16:57:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 17:03:21 --> Could not find the language line "student1"
ERROR - 2019-04-04 17:03:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-04 17:04:08 --> Could not find the language line "student1"
ERROR - 2019-04-04 17:04:08 --> Could not find the language line "detail"
ERROR - 2019-04-04 17:04:08 --> Could not find the language line "file"
ERROR - 2019-04-04 17:04:08 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 17:04:08 --> Could not find the language line "Documents"
ERROR - 2019-04-04 17:04:24 --> Could not find the language line "student1"
ERROR - 2019-04-04 17:04:24 --> Could not find the language line "detail"
ERROR - 2019-04-04 17:04:24 --> Could not find the language line "file"
ERROR - 2019-04-04 17:04:24 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 17:04:24 --> Could not find the language line "Documents"
ERROR - 2019-04-04 17:04:39 --> Could not find the language line "student1"
ERROR - 2019-04-04 17:04:39 --> Could not find the language line "detail"
ERROR - 2019-04-04 17:04:39 --> Could not find the language line "file"
ERROR - 2019-04-04 17:04:39 --> Could not find the language line "upload_documents1"
ERROR - 2019-04-04 17:04:39 --> Could not find the language line "Documents"
