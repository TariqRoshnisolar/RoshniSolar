<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-21 05:05:34 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 25
ERROR - 2019-05-21 05:05:34 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 154
ERROR - 2019-05-21 05:05:34 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 156
ERROR - 2019-05-21 05:05:34 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 157
ERROR - 2019-05-21 05:05:39 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 25
ERROR - 2019-05-21 05:05:39 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 154
ERROR - 2019-05-21 05:05:39 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 156
ERROR - 2019-05-21 05:05:39 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 157
ERROR - 2019-05-21 05:06:36 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 136
ERROR - 2019-05-21 05:06:36 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 138
ERROR - 2019-05-21 05:06:36 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 139
ERROR - 2019-05-21 05:07:19 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 132
ERROR - 2019-05-21 05:07:19 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 134
ERROR - 2019-05-21 05:07:19 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/payment.php 135
ERROR - 2019-05-21 05:30:58 --> Severity: Error --> Call to undefined function json_ecode() /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 54
ERROR - 2019-05-21 05:34:23 --> Severity: Notice --> Undefined variable: issuing_bank /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 46
ERROR - 2019-05-21 11:44:38 --> Severity: Notice --> Undefined property: Form::$regstration_model /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:44:38 --> Severity: Error --> Call to a member function add() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:45:00 --> Severity: Notice --> Undefined property: Form::$regstration_model /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:45:00 --> Severity: Error --> Call to a member function add() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:48:16 --> Severity: Notice --> Undefined property: Form::$Regstration_model /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:48:16 --> Severity: Error --> Call to a member function add() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:48:40 --> Severity: Notice --> Undefined property: Form::$regstration_model /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 11:48:40 --> Severity: Error --> Call to a member function add() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 112
ERROR - 2019-05-21 06:22:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:22:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:22:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:22:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:23:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:23:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:23:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:23:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:23:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 06:23:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-05-21 11:53:48 --> Query error: Unknown column 'application-no' in 'field list' - Invalid query: INSERT INTO `users_info` (`application-no`, `f_name`, `m_name`, `l_name`, `phone_no`, `email_id`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-21 11:54:22 --> Query error: Column 'f_name' cannot be null - Invalid query: INSERT INTO `users_info` (`f_name`, `m_name`, `l_name`, `phone_no`, `email_id`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-21 06:24:46 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 39
ERROR - 2019-05-21 06:25:27 --> Severity: Runtime Notice --> Only variables should be passed by reference /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 41
ERROR - 2019-05-21 06:25:27 --> Severity: Notice --> Undefined variable: allowed_extensio /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 43
ERROR - 2019-05-21 06:25:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 43
ERROR - 2019-05-21 06:27:19 --> Severity: Runtime Notice --> Only variables should be passed by reference /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 41
ERROR - 2019-05-21 06:27:47 --> Severity: Notice --> Array to string conversion /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 43
ERROR - 2019-05-21 06:29:05 --> Severity: Notice --> Undefined variable: allowed_extensio /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 44
ERROR - 2019-05-21 06:29:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 44
ERROR - 2019-05-21 12:00:34 --> Severity: Notice --> Undefined property: Form::$rbac /home/o2ixr95i7zue/public_html/application/controllers/Form.php 89
ERROR - 2019-05-21 12:00:34 --> Severity: Error --> Call to a member function hasPrivilege() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 89
ERROR - 2019-05-21 06:58:38 --> Severity: Notice --> Use of undefined constant dmYHis - assumed 'dmYHis' /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 60
ERROR - 2019-05-21 12:49:02 --> Severity: Notice --> Undefined property: Form::$rbac /home/o2ixr95i7zue/public_html/application/controllers/Form.php 90
ERROR - 2019-05-21 12:49:02 --> Severity: Error --> Call to a member function hasPrivilege() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 90
ERROR - 2019-05-21 12:49:03 --> Severity: Notice --> Undefined property: Form::$rbac /home/o2ixr95i7zue/public_html/application/controllers/Form.php 90
ERROR - 2019-05-21 12:49:03 --> Severity: Error --> Call to a member function hasPrivilege() on null /home/o2ixr95i7zue/public_html/application/controllers/Form.php 90
ERROR - 2019-05-21 13:16:09 --> Query error: Column 'f_name' cannot be null - Invalid query: INSERT INTO `users_info` (`f_name`, `m_name`, `l_name`, `phone_no`, `email_id`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-21 13:17:38 --> Query error: Column 'f_name' cannot be null - Invalid query: INSERT INTO `users_info` (`f_name`, `m_name`, `l_name`, `phone_no`, `email_id`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-21 13:17:44 --> Query error: Column 'f_name' cannot be null - Invalid query: INSERT INTO `users_info` (`f_name`, `m_name`, `l_name`, `phone_no`, `email_id`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-21 15:12:04 --> Severity: Notice --> Use of undefined constant CCA_MERCHANT_ID - assumed 'CCA_MERCHANT_ID' /home/o2ixr95i7zue/public_html/application/views/form/payment.php 59
ERROR - 2019-05-21 15:47:05 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/views/form/payment.php 2
