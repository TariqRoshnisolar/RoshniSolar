<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-26 11:55:20 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\smartschool\application\models\Mm_gradescale_model.php 31
