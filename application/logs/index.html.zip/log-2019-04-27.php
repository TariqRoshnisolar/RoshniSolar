<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-27 04:44:41 --> Severity: Notice --> Undefined property: Site::$staffroles_model C:\xampp\htdocs\uvsil\system\core\Model.php 77
ERROR - 2019-04-27 04:44:41 --> Severity: Error --> Call to a member function getStaffRoles() on null C:\xampp\htdocs\uvsil\application\models\Staff_model.php 344
ERROR - 2019-04-27 04:56:08 --> Severity: Notice --> Undefined property: Site::$staffroles_model C:\xampp\htdocs\uvsil\system\core\Model.php 77
ERROR - 2019-04-27 04:56:08 --> Severity: Error --> Call to a member function getStaffRoles() on null C:\xampp\htdocs\uvsil\application\models\Staff_model.php 344
ERROR - 2019-04-27 05:01:19 --> Severity: Notice --> Undefined property: Site::$staffroles_model C:\xampp\htdocs\uvsil\system\core\Model.php 77
ERROR - 2019-04-27 05:01:19 --> Severity: Error --> Call to a member function getStaffRoles() on null C:\xampp\htdocs\uvsil\application\models\Staff_model.php 344
ERROR - 2019-04-27 07:03:40 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Staffroles_model.php 10
