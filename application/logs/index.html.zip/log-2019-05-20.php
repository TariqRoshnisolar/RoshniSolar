<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-20 11:58:07 --> Severity: Notice --> Undefined variable: header /home/o2ixr95i7zue/public_html/application/views/form/index.php 3
ERROR - 2019-05-20 11:58:07 --> Severity: Notice --> Undefined variable: footer /home/o2ixr95i7zue/public_html/application/views/form/index.php 107
ERROR - 2019-05-20 12:02:13 --> Severity: Notice --> Undefined variable: header /home/o2ixr95i7zue/public_html/application/views/form/index.php 3
ERROR - 2019-05-20 12:02:13 --> Severity: Notice --> Undefined variable: footer /home/o2ixr95i7zue/public_html/application/views/form/index.php 107
ERROR - 2019-05-20 12:02:34 --> Severity: Notice --> Undefined variable: header /home/o2ixr95i7zue/public_html/application/views/form/index.php 3
ERROR - 2019-05-20 12:02:34 --> Severity: Notice --> Undefined variable: footer /home/o2ixr95i7zue/public_html/application/views/form/index.php 107
ERROR - 2019-05-20 12:04:17 --> Severity: Notice --> Undefined variable: header /home/o2ixr95i7zue/public_html/application/views/form/index.php 3
ERROR - 2019-05-20 12:04:17 --> Severity: Notice --> Undefined variable: footer /home/o2ixr95i7zue/public_html/application/views/form/index.php 107
ERROR - 2019-05-20 12:04:40 --> Severity: Notice --> Undefined variable: header /home/o2ixr95i7zue/public_html/application/views/form/index.php 3
ERROR - 2019-05-20 12:04:40 --> Severity: Notice --> Undefined variable: footer /home/o2ixr95i7zue/public_html/application/views/form/index.php 107
ERROR - 2019-05-20 12:05:38 --> Severity: Notice --> Undefined variable: header /home/o2ixr95i7zue/public_html/application/views/form/index.php 3
ERROR - 2019-05-20 12:05:38 --> Severity: Notice --> Undefined variable: footer /home/o2ixr95i7zue/public_html/application/views/form/index.php 107
ERROR - 2019-05-20 12:32:12 --> Severity: Parsing Error --> syntax error, unexpected ''draft_no'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 49
ERROR - 2019-05-20 12:33:28 --> Severity: Parsing Error --> syntax error, unexpected ''draft_no'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Payment.php 49
ERROR - 2019-05-20 12:34:43 --> Severity: Compile Error --> Cannot redeclare class Staff_model /home/o2ixr95i7zue/public_html/application/models/Payment_model.php 27
