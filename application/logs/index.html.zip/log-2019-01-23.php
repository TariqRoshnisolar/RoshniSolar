<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-23 12:36:52 --> Severity: Notice --> Undefined property: Defineremarks::$mm_remarks_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineremarks.php 23
ERROR - 2019-01-23 12:36:53 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineremarks.php 23
ERROR - 2019-01-23 08:08:09 --> Severity: Compile Error --> Cannot redeclare class Mm_remarkstype_model C:\xampp\htdocs\smartschool\application\models\Mm_remarks_model.php 86
ERROR - 2019-01-23 14:09:07 --> Query error: Unknown column 'created_by' in 'field list' - Invalid query: INSERT INTO `mm_remarks` (`remarks`, `type`, `created_at`, `created_by`) VALUES ('Weak in english', '2', '2019-01-23 14:09:07', '0')
ERROR - 2019-01-23 14:14:56 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\defineRemarks.php 118
ERROR - 2019-01-23 14:24:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\defineRemarks.php 130
ERROR - 2019-01-23 14:24:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\defineRemarks.php 137
ERROR - 2019-01-23 15:19:21 --> Severity: Notice --> Undefined property: Definehealthstatus::$mm_healthstatus_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Definehealthstatus.php 23
ERROR - 2019-01-23 15:19:21 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Definehealthstatus.php 23
ERROR - 2019-01-23 15:54:13 --> Could not find the language line "student_fees1"
ERROR - 2019-01-23 15:54:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-01-23 16:09:27 --> Severity: Notice --> Undefined property: Definehouse::$mm_house_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Definehouse.php 23
ERROR - 2019-01-23 16:09:27 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Definehouse.php 23
ERROR - 2019-01-23 16:24:12 --> Severity: Notice --> Undefined property: Definehouse::$mm_house_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Definehouse.php 23
ERROR - 2019-01-23 16:24:12 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Definehouse.php 23
ERROR - 2019-01-23 17:22:18 --> Could not find the language line "student_fee"
ERROR - 2019-01-23 17:22:18 --> Could not find the language line "back"
ERROR - 2019-01-23 17:23:29 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-01-23 17:23:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
