<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-15 13:11:19 --> Severity: Notice --> Undefined property: Subjectgrouping::$mm_mastersubjectforgroup_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 56
ERROR - 2019-02-15 13:11:19 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 56
ERROR - 2019-02-15 08:42:11 --> Severity: Notice --> Undefined property: Subjectgrouping::$load C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 9
ERROR - 2019-02-15 08:42:11 --> Severity: Error --> Call to a member function model() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 9
ERROR - 2019-02-15 11:09:43 --> Severity: Compile Error --> Cannot use try without catch or finally C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 87
ERROR - 2019-02-15 16:43:28 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2019-02-15 16:44:29 --> Severity: Error --> Call to undefined method CI_Form_validation::set_messages() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 48
