<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-05 12:56:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-02-05 13:08:57 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::num_rows() C:\xampp\htdocs\smartschool\application\models\Student_model.php 907
ERROR - 2019-02-05 14:38:48 --> Severity: Error --> Call to undefined method Student_model::getstudentsubjectbyclasssection() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjecttostudents.php 56
