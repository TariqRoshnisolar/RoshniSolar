<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-11 12:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 2008
ERROR - 2019-02-11 12:06:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-11 12:06:27 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `mm_subjecttoclass` SET `is_deleted` = 1
WHERE 0 = `Array`
ERROR - 2019-02-11 12:06:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-11 12:06:46 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `mm_subjecttoclass` SET `is_deleted` = 1
WHERE 0 = `Array`
ERROR - 2019-02-11 12:07:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-11 12:07:02 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `mm_subjecttoclass` SET `is_deleted` = 1
WHERE 0 = `Array`
ERROR - 2019-02-11 12:07:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-11 12:07:36 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `mm_subjecttoclass` SET `is_deleted` = 1
WHERE 0 = `Array`
ERROR - 2019-02-11 12:13:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1965
ERROR - 2019-02-11 12:13:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1965
ERROR - 2019-02-11 12:13:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1978
ERROR - 2019-02-11 12:13:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1978
ERROR - 2019-02-11 12:13:57 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `mm_subjecttoclass` SET `is_deleted` = CASE 
WHEN `subject` = Array THEN 1
WHEN `subject` = Array THEN 1
ELSE `is_deleted` END
WHERE `classsection` = '1'
AND `subject` IN(Array,Array)
ERROR - 2019-02-11 12:13:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smartschool\system\core\Exceptions.php:271) C:\xampp\htdocs\smartschool\system\core\Common.php 570
ERROR - 2019-02-11 12:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 2008
ERROR - 2019-02-11 12:17:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1965
ERROR - 2019-02-11 12:17:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1965
ERROR - 2019-02-11 12:17:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1978
ERROR - 2019-02-11 12:17:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1978
ERROR - 2019-02-11 12:17:52 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `mm_subjecttoclass` SET `is_deleted` = CASE 
WHEN `subject` = Array THEN 1
WHEN `subject` = Array THEN 1
ELSE `is_deleted` END
WHERE `classsection` = '1'
AND `subject` IN(Array,Array)
ERROR - 2019-02-11 12:17:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smartschool\system\core\Exceptions.php:271) C:\xampp\htdocs\smartschool\system\core\Common.php 570
