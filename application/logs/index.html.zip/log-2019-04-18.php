<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-18 06:28:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-04-18 06:28:13 --> Unable to connect to the database
ERROR - 2019-04-18 10:19:23 --> Could not find the language line "by_date1"
ERROR - 2019-04-18 10:41:38 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:41:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:41:44 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:41:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feehead.php 128
ERROR - 2019-04-18 10:46:10 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:49:26 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:51:27 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 10:51:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 11:21:04 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 11:21:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 11:21:20 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-18 11:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
