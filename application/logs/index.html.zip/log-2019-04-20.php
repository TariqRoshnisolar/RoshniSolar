<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-20 12:51:18 --> Could not find the language line "student1"
ERROR - 2019-04-20 12:51:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-20 12:51:22 --> Could not find the language line "student1"
ERROR - 2019-04-20 12:51:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
