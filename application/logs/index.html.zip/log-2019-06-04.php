<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-04 00:02:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:02:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:03:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:03:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:05:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:05:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:06:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:06:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:06:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:06:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:06:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:06:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:06:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:06:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:06:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:06:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:36:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:36:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:36:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:36:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:44:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:44:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:44:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:44:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:44:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:44:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:44:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:44:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 00:45:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 00:45:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 01:06:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 01:06:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 02:00:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 02:00:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 02:01:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 02:01:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 02:15:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 02:15:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 02:32:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 02:32:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 03:07:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 03:07:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 04:15:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 04:15:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 04:16:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 04:16:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 04:59:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 04:59:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 05:07:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 05:07:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 05:07:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 05:07:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 05:18:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 05:18:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 06:18:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 06:18:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 06:30:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 06:30:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 06:39:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 06:39:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:09:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:09:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:09:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:09:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:10:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:10:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:40:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:40:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:47:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:47:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:48:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:48:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:52:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:52:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 07:53:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 07:53:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:02:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:02:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:07:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:07:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:09:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:09:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:27:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:27:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:27:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:27:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:27:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:27:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:30:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:30:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:31:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:31:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 08:54:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 08:54:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:17:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:17:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:17:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:17:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:24:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:24:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:31:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:31:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:31:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:31:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:32:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:32:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:47:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:47:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 09:58:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 09:58:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:03:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:03:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:03:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:03:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:03:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:03:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:03:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:03:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:05:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:05:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:08:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:08:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:09:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:09:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:09:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:09:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:10:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:10:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:12:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:12:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:13:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:13:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:13:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:15:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:16:52 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:16:52 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:20:20 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:23:58 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:23:58 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:24:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:24:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:25:48 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:25:48 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:26:00 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 231
ERROR - 2019-06-04 10:26:00 --> Severity: Notice --> Undefined index: userid /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 241
ERROR - 2019-06-04 10:26:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:26:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:26:45 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:26:56 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:27:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@rediffmail.com and user_credentials.password=md5('kumar2')' at line 1 - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=dilip_dynamic@rediffmail.com and user_credentials.password=md5('kumar2')
ERROR - 2019-06-04 10:27:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@rediffmail.com and user_credentials.password=md5('kumar2')' at line 1 - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=dilip_dynamic@rediffmail.com and user_credentials.password=md5('kumar2')
ERROR - 2019-06-04 10:27:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:27:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:33:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:33:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:33:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:33:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:33:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:33:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:35:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:35:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:36:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:36:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:38:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:38:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:39:34 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:42:50 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:43:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:43:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:46:23 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:46:51 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 10:54:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:54:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 10:59:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 10:59:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:00:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:00:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:00:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:00:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:01:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:01:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:01:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:01:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:02:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:02:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:03:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:03:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:04:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:04:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:04:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:04:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:05:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:05:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:05:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:05:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:05:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:05:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:06:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:06:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:08:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:08:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:08:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:08:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:16:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:16:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:18:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:18:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:18:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:21:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:21:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:25:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:25:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:28:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:28:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:28:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:28:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:39:48 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:41:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:41:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:41:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:41:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:42:11 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:42:30 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:43:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:43:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:43:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:43:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:43:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:43:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:44:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:44:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:48:36 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:53:35 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:54:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:54:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 11:55:40 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:57:12 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:59:51 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 11:59:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 11:59:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:00:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:00:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:07:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:07:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:15:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:15:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 06:53:28 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 53
ERROR - 2019-06-04 06:53:31 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 53
ERROR - 2019-06-04 06:53:51 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 55
ERROR - 2019-06-04 06:53:54 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 55
ERROR - 2019-06-04 06:54:10 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 55
ERROR - 2019-06-04 06:55:55 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:58:49 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:58:51 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:58:55 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:58:56 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:03 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:04 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:05 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:06 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:11 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:12 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:13 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:13 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 59
ERROR - 2019-06-04 06:59:32 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:36 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:36 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:37 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:49 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:50 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:53 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:54 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:56 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:58 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 06:59:58 --> Severity: Parsing Error --> syntax error, unexpected 'BY' (T_STRING) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 62
ERROR - 2019-06-04 12:35:02 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 12:35:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:35:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:35:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:35:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:36:06 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 12:37:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:37:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:37:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:37:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:38:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:38:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:43:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:43:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:44:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:44:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:46:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:46:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:46:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:46:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:47:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:47:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:48:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:48:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:48:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:48:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:48:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:48:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:48:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:48:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:49:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:49:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:49:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:49:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:49:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:49:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:50:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:50:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:51:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:51:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:51:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:51:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:51:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:51:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:52:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:52:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:53:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:53:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:56:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:56:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:56:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:56:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:56:22 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 12:57:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 12:57:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:57:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:57:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:57:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:57:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:57:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:57:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 12:57:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 12:58:19 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 12:59:34 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 12:59:52 --> Query error: Unknown column '3454543rtte' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=3454543rtte and user_credentials.password=md5('43434344')
ERROR - 2019-06-04 12:59:58 --> Query error: Unknown column '3454543rtte' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=3454543rtte and user_credentials.password=md5('43434344')
ERROR - 2019-06-04 13:00:00 --> Query error: Unknown column '3454543rtte' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=3454543rtte and user_credentials.password=md5('43434344')
ERROR - 2019-06-04 13:00:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:00:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:00:14 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 13:00:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:00:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:00:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:00:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:01:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:01:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:02:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:02:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:03:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:03:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:03:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:03:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:03:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:03:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:03:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:03:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:04:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:04:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:19:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:19:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:26:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:26:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:27:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:27:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:29:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:29:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:30:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:30:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:33:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:33:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:36:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:36:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:36:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:36:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 13:40:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 13:40:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:07:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:07:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:07:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:07:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:08:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:08:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:12:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:12:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:13:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:13:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:20:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:20:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:21:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:21:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:23:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:23:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:24:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:24:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:25:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:25:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:28:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:28:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:28:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:28:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:29:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:29:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:52:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:52:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:54:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:54:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 14:54:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 14:54:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:01:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:01:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:02:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:02:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:02:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:02:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:03:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:03:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:06:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:06:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:07:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:07:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:09:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:09:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:13:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:13:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:13:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:13:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:13:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:13:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:13:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:13:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:14:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:14:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:14:41 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:14:41 --> Severity: Warning --> date() expects parameter 2 to be long, string given /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 431
ERROR - 2019-06-04 15:15:02 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:15:02 --> Severity: Warning --> date() expects parameter 2 to be long, string given /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 431
ERROR - 2019-06-04 15:15:35 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:15:35 --> Severity: Warning --> date() expects parameter 2 to be long, string given /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 431
ERROR - 2019-06-04 15:15:59 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:15:59 --> Severity: Warning --> date() expects parameter 2 to be long, string given /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 431
ERROR - 2019-06-04 15:16:37 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:16:37 --> Severity: Warning --> date() expects parameter 2 to be long, string given /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 431
ERROR - 2019-06-04 15:17:32 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:18:48 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:18:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:18:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:19:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:19:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:22:14 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:22:38 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:23:53 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:24:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:24:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:24:40 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:25:57 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:27:54 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:29:37 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:30:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:30:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:31:11 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:34:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:34:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:35:26 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:35:26 --> Severity: Warning --> date() expects parameter 2 to be long, string given /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:36:27 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:36:27 --> Severity: Notice --> A non well formed numeric value encountered /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:37:33 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:39:02 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:39:02 --> Severity: Notice --> Use of undefined constant v - assumed 'v' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:39:02 --> Severity: Notice --> Use of undefined constant dob - assumed 'dob' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:39:02 --> Severity: Notice --> Undefined variable: vdob /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:40:26 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:41:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:41:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:41:39 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:41:39 --> Severity: Notice --> Use of undefined constant v - assumed 'v' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:41:39 --> Severity: Notice --> Use of undefined constant dob - assumed 'dob' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:41:39 --> Severity: Notice --> Undefined variable: vdob /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 433
ERROR - 2019-06-04 15:42:58 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:42:58 --> Severity: Notice --> Use of undefined constant d - assumed 'd' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 434
ERROR - 2019-06-04 15:42:58 --> Severity: Notice --> Undefined variable: d /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 434
ERROR - 2019-06-04 15:44:07 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:45:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:45:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:45:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:45:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:45:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:45:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:45:54 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:50:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 15:50:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 15:52:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:54:25 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:54:25 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 15:55:59 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:00:03 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:00:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:02:18 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:03:53 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:04:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:05:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:05:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:06:43 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:08:32 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:09:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:09:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:15:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:15:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:17:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:17:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:17:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:17:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:19:48 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:21:17 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:22:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:23:20 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:23:58 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:25:43 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:26:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:26:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:26:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:28:05 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:28:57 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:29:42 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:30:36 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:31:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:32:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:32:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:33:54 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:35:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:35:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:35:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:35:49 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:37:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@gmail.com and user_credentials.password=md5('7630810192')' at line 1 - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=budhunabam@gmail.com and user_credentials.password=md5('7630810192')
ERROR - 2019-06-04 16:37:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@gmail.com and user_credentials.password=md5('7630810192')' at line 1 - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=budhunabam@gmail.com and user_credentials.password=md5('7630810192')
ERROR - 2019-06-04 16:37:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@gmail.com and user_credentials.password=md5('7630810192')' at line 1 - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=budhunabam@gmail.com and user_credentials.password=md5('7630810192')
ERROR - 2019-06-04 16:38:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:38:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:39:05 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:39:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:40:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:40:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:41:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:41:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:43:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:43:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:43:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:43:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:43:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:44:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:44:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:50:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:50:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:51:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:51:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:53:01 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:54:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:54:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:54:48 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:55:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:55:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:55:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 16:55:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 16:56:30 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:58:14 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 16:58:58 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:03:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:03:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:03:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:03:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:04:05 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:04:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:04:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:05:15 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:05:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:05:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:05:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:05:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:05:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:06:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:06:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:07:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:07:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:07:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:07:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:07:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:07:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:08:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:08:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:13:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:13:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:13:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:13:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:14:07 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:15:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:15:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:15:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:15:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:16:46 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:18:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'BY users_info.id DESC' at line 12 - Invalid query: SELECT users_info.id as user_id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.jobstate, jobstates.state as jobstate_name , users_info.acceptpolicy, users_info.is_peradderss_same, users_info.agree_preview, users_info.payment_mode, users_info.offline_payment_status, users_info.online_payment_status, users_info.category, categories.category as category_name, users_info.religion, religions.religion as religion_name, users_info.pancard, users_info.aadharno, users_info.dob, users_info.gender, genders.gender as gender_name, users_info.maritalstatus, marital_statues.status as maritalstatus_name, users_info.father_name, users_info.mother_name, users_info.spouse_name, users_info.present_addressline1, users_info.present_addressline2, users_info.present_state, pre_state.state as present_state_name, users_info.present_district, users_info.present_pincode, users_info.permanent_addressline1, users_info.permanent_addressline2, users_info.permanent_state, per_state.state as permanent_state_name , users_info.permanent_district, users_info.permanent_pincode, users_info.degree, degrees.degree as degree_name , users_info.university, users_info.passing_year, users_info.marks, users_info.result, users_info.have_certificates, users_info.photo, users_info.signature 
FROM users_info 
INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) 
LEFT JOIN jobstates ON (jobstates.id=users_info.jobstate and jobstates.is_deleted=0) 
LEFT JOIN categories ON (categories.id=users_info.category and categories.is_deleted=0) 
LEFT JOIN religions ON (religions.id=users_info.religion and religions.is_deleted=0) 
LEFT JOIN genders ON (genders.id=users_info.gender and genders.is_deleted=0) 
LEFT JOIN marital_statues ON (marital_statues.id=users_info.maritalstatus and marital_statues.is_deleted=0) 
LEFT JOIN states pre_state ON (pre_state.id=users_info.present_state and pre_state.is_deleted=0)
LEFT JOIN states per_state ON (per_state.id=users_info.permanent_state and per_state.is_deleted=0)
LEFT JOIN degrees ON (degrees.id=users_info.degree and degrees.is_deleted=0)
WHERE users_info.is_deleted=0 AND users_info.payment_mode=1ORDER BY users_info.id DESC
ERROR - 2019-06-04 17:18:44 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:19:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:19:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:19:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'BY users_info.id DESC' at line 12 - Invalid query: SELECT users_info.id as user_id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.jobstate, jobstates.state as jobstate_name , users_info.acceptpolicy, users_info.is_peradderss_same, users_info.agree_preview, users_info.payment_mode, users_info.offline_payment_status, users_info.online_payment_status, users_info.category, categories.category as category_name, users_info.religion, religions.religion as religion_name, users_info.pancard, users_info.aadharno, users_info.dob, users_info.gender, genders.gender as gender_name, users_info.maritalstatus, marital_statues.status as maritalstatus_name, users_info.father_name, users_info.mother_name, users_info.spouse_name, users_info.present_addressline1, users_info.present_addressline2, users_info.present_state, pre_state.state as present_state_name, users_info.present_district, users_info.present_pincode, users_info.permanent_addressline1, users_info.permanent_addressline2, users_info.permanent_state, per_state.state as permanent_state_name , users_info.permanent_district, users_info.permanent_pincode, users_info.degree, degrees.degree as degree_name , users_info.university, users_info.passing_year, users_info.marks, users_info.result, users_info.have_certificates, users_info.photo, users_info.signature 
FROM users_info 
INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) 
LEFT JOIN jobstates ON (jobstates.id=users_info.jobstate and jobstates.is_deleted=0) 
LEFT JOIN categories ON (categories.id=users_info.category and categories.is_deleted=0) 
LEFT JOIN religions ON (religions.id=users_info.religion and religions.is_deleted=0) 
LEFT JOIN genders ON (genders.id=users_info.gender and genders.is_deleted=0) 
LEFT JOIN marital_statues ON (marital_statues.id=users_info.maritalstatus and marital_statues.is_deleted=0) 
LEFT JOIN states pre_state ON (pre_state.id=users_info.present_state and pre_state.is_deleted=0)
LEFT JOIN states per_state ON (per_state.id=users_info.permanent_state and per_state.is_deleted=0)
LEFT JOIN degrees ON (degrees.id=users_info.degree and degrees.is_deleted=0)
WHERE users_info.is_deleted=0 AND users_info.payment_mode=1ORDER BY users_info.id DESC
ERROR - 2019-06-04 17:19:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:22:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:22:17 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:23:32 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:23:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:27:52 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:28:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:28:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:29:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:29:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:30:00 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:33:33 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:37:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:37:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:39:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:39:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:39:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:39:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:46:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:46:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:49:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:49:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:49:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:49:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:50:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:50:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:51:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:51:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:55:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:55:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:55:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:55:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:55:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:55:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:55:51 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:57:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:57:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:57:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:57:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:57:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:57:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 17:58:34 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-04 17:58:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 17:58:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:05:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:05:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:14:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:14:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:22:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:22:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:23:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:23:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:23:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:23:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:27:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:27:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:28:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:28:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:28:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:28:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:28:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:28:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:50:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:50:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:51:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:51:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 18:57:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 18:57:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:29:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:29:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:30:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:30:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:31:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:31:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:32:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:32:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:32:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:32:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:33:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:33:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:33:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:33:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:33:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:33:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 19:59:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 19:59:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:11:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:11:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:11:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:11:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:11:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:11:41 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:11:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:11:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:22:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:22:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:26:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:26:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:27:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:27:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:29:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:29:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:35:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:35:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 20:40:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 20:40:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:01:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:01:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:02:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:02:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:23:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:23:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:26:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:26:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:43:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:43:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:49:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:49:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 21:50:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 21:50:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:00:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:00:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:04:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:04:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:28:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:28:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:29:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:29:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:30:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:30:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:32:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:32:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:37:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:37:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:38:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:38:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:38:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:38:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:43:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:43:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:44:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:44:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:45:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:45:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:46:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:46:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:46:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:46:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:46:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:46:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 22:46:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 22:46:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:02:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:02:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:06:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:06:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:07:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:07:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:09:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:09:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:09:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:09:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:19:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:19:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:21:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:21:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:26:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:26:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:50:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:50:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:50:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:50:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:50:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:50:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:51:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:51:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:51:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:51:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:52:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:52:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-04 23:52:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-04 23:52:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
