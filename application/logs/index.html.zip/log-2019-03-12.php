<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-12 04:35:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\Site.php 104
ERROR - 2019-03-12 10:20:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-03-12 10:20:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-12 10:24:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-03-12 10:25:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-03-12 10:25:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-03-12 10:27:09 --> Could not find the language line "student_fee"
ERROR - 2019-03-12 10:27:09 --> Could not find the language line "back"
ERROR - 2019-03-12 10:29:04 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-12 10:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-12 10:40:42 --> Could not find the language line "student_fee"
ERROR - 2019-03-12 10:40:42 --> Could not find the language line "back"
ERROR - 2019-03-12 10:58:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-03-12 11:04:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-03-12 11:28:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 58
ERROR - 2019-03-12 11:29:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 58
ERROR - 2019-03-12 11:29:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 58
ERROR - 2019-03-12 11:29:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 60
ERROR - 2019-03-12 11:30:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 60
ERROR - 2019-03-12 11:30:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 60
ERROR - 2019-03-12 11:31:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\hostelAdmission.php 60
ERROR - 2019-03-12 11:39:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-03-12 11:40:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-03-12 12:00:44 --> Could not find the language line "student_fee"
ERROR - 2019-03-12 12:00:44 --> Could not find the language line "back"
ERROR - 2019-03-12 12:07:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-12 12:24:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-12 12:27:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-12 12:37:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-12 12:54:34 --> Could not find the language line "student1"
ERROR - 2019-03-12 12:54:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-03-12 12:54:40 --> Could not find the language line "student1"
ERROR - 2019-03-12 12:54:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-03-12 12:54:46 --> Could not find the language line "student1"
ERROR - 2019-03-12 12:54:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentEdit.php 60
ERROR - 2019-03-12 12:58:54 --> Could not find the language line "student1"
ERROR - 2019-03-12 12:58:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentEdit.php 60
ERROR - 2019-03-12 13:24:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
