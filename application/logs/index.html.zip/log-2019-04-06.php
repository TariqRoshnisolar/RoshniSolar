<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-06 10:24:01 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 90
ERROR - 2019-04-06 10:24:01 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 91
ERROR - 2019-04-06 10:24:01 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 90
ERROR - 2019-04-06 10:24:01 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 91
ERROR - 2019-04-06 10:24:01 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 90
ERROR - 2019-04-06 10:24:01 --> Severity: Notice --> Undefined index: section C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 91
ERROR - 2019-04-06 14:14:50 --> Severity: Notice --> Undefined variable: classlist C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 75
ERROR - 2019-04-06 14:14:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 75
ERROR - 2019-04-06 14:15:15 --> Severity: Notice --> Undefined variable: classlist C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 74
ERROR - 2019-04-06 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 74
ERROR - 2019-04-06 14:17:28 --> Severity: Notice --> Undefined variable: classlist C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 74
ERROR - 2019-04-06 14:17:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 74
ERROR - 2019-04-06 14:18:14 --> Severity: Notice --> Undefined variable: classlist C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 75
ERROR - 2019-04-06 14:18:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 75
ERROR - 2019-04-06 14:23:41 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 80
ERROR - 2019-04-06 11:56:38 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\smartschool\application\controllers\Studentfee.php 473
ERROR - 2019-04-06 16:36:59 --> Could not find the language line "student_fee"
ERROR - 2019-04-06 16:36:59 --> Could not find the language line "back"
