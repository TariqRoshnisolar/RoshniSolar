<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-19 12:51:01 --> Query error: Unknown column 'msg.subject_id' in 'on clause' - Invalid query: SELECT `msg`.`id`, `msfg`.`subject` as `master_subject`, `sub`.`name` as `subject_name`, `c`.`class`, `s`.`section`
FROM `mm_subjectgrouping` `msg`
LEFT JOIN `mm_mastersubjectforgrouping` `msfg` ON `msfg`.`id`=`msg`.`subjectgroup_id` and `msfg`.`is_deleted`=0
LEFT JOIN `subjects` `sub` ON `sub`.`id`=`msg`.`subject_id` and `sub`.`is_active`='yes'
LEFT JOIN `class_sections` `cs` ON `cs`.`id`=`msg`.`classsection_id` and `cs`.`is_active`='yes'
LEFT JOIN `classes` `c` ON `c`.`id`=`cs`.`class_id` and `c`.`is_active`='yes'
LEFT JOIN `sections` `s` ON `s`.`id`=`cs`.`section_id` and `s`.`is_active`='yes'
WHERE `msg`.`classsection_id` = '1'
AND `msg`.`is_deleted` =0
ERROR - 2019-02-19 12:53:24 --> Query error: Unknown column 'msg.subject_id' in 'on clause' - Invalid query: SELECT `msg`.`id`, `msfg`.`subject` as `master_subject`, `sub`.`name` as `subject_name`, `c`.`class`, `s`.`section`
FROM `mm_subjectgrouping` `msg`
LEFT JOIN `mm_mastersubjectforgrouping` `msfg` ON `msfg`.`id`=`msg`.`subjectgroup_id` and `msfg`.`is_deleted`=0
LEFT JOIN `subjects` `sub` ON `sub`.`id`=`msg`.`subject_id` and `sub`.`is_active`='yes'
LEFT JOIN `class_sections` `cs` ON `cs`.`id`=`msg`.`classsection_id` and `cs`.`is_active`='yes'
LEFT JOIN `classes` `c` ON `c`.`id`=`cs`.`class_id` and `c`.`is_active`='yes'
LEFT JOIN `sections` `s` ON `s`.`id`=`cs`.`section_id` and `s`.`is_active`='yes'
WHERE `msg`.`classsection_id` = '1'
AND `msg`.`is_deleted` =0
ERROR - 2019-02-19 12:54:05 --> Query error: Unknown column 'msg.subject_id' in 'on clause' - Invalid query: SELECT `msg`.`id`, `msfg`.`subject` as `master_subject`, `sub`.`name` as `subject_name`, `c`.`class`, `s`.`section`
FROM `mm_subjectgrouping` `msg`
LEFT JOIN `mm_mastersubjectforgrouping` `msfg` ON `msfg`.`id`=`msg`.`subjectgroup_id` and `msfg`.`is_deleted`=0
LEFT JOIN `subjects` `sub` ON `sub`.`id`=`msg`.`subject_id` and `sub`.`is_active`='yes'
LEFT JOIN `class_sections` `cs` ON `cs`.`id`=`msg`.`classsection_id` and `cs`.`is_active`='yes'
LEFT JOIN `classes` `c` ON `c`.`id`=`cs`.`class_id` and `c`.`is_active`='yes'
LEFT JOIN `sections` `s` ON `s`.`id`=`cs`.`section_id` and `s`.`is_active`='yes'
WHERE `msg`.`classsection_id` = '1'
AND `msg`.`is_deleted` =0
ERROR - 2019-02-19 12:55:27 --> Query error: Unknown column 'sub.name' in 'field list' - Invalid query: SELECT `msg`.`id`, `msfg`.`subject` as `master_subject`, `sub`.`name` as `subject_name`, `c`.`class`, `s`.`section`
FROM `mm_subjectgrouping` `msg`
LEFT JOIN `mm_mastersubjectforgrouping` `msfg` ON `msfg`.`id`=`msg`.`subjectgroup_id` and `msfg`.`is_deleted`=0
LEFT JOIN `class_sections` `cs` ON `cs`.`id`=`msg`.`classsection_id` and `cs`.`is_active`='yes'
LEFT JOIN `classes` `c` ON `c`.`id`=`cs`.`class_id` and `c`.`is_active`='yes'
LEFT JOIN `sections` `s` ON `s`.`id`=`cs`.`section_id` and `s`.`is_active`='yes'
WHERE `msg`.`classsection_id` = '1'
AND `msg`.`is_deleted` =0
