<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-14 08:42:53 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'trigente_uvsil98'@'localhost' (using password: YES) /home/o2ixr95i7zue/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-05-14 08:42:53 --> Unable to connect to the database
ERROR - 2019-05-14 08:43:23 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'trigente_uvsil98'@'localhost' (using password: YES) /home/o2ixr95i7zue/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-05-14 08:43:23 --> Unable to connect to the database
ERROR - 2019-05-14 08:44:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:44:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:44:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:44:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:45:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:45:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:45:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:45:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:45:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:45:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:47:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:47:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:49:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:49:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:49:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:49:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:49:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:49:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "setting1"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:01 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "setting1"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:11 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 08:50:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:50:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:50:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:50:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:50:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:50:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:50:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:50:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "setting1"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 14:20:57 --> Could not find the language line "add/edit"
ERROR - 2019-05-14 08:52:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:52:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:52:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:52:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:52:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:52:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:53:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:53:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:53:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:53:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:54:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:54:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:56:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:56:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:59:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:59:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:59:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:59:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 08:59:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 08:59:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:00:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:00:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:00:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:00:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:00:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:01:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:01:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:01:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:01:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:01:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:01:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:01:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:01:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:01:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:01:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:03:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:03:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:03:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:03:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:03:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:03:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:03:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:03:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:04:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:04:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 09:05:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 187
ERROR - 2019-05-14 09:05:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/o2ixr95i7zue/public_html/application/core/MY_Controller.php 191
ERROR - 2019-05-14 15:17:27 --> Could not find the language line "detail"
ERROR - 2019-05-14 15:17:43 --> Severity: Notice --> Undefined variable: getStaffRole /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 44
ERROR - 2019-05-14 15:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 44
ERROR - 2019-05-14 15:17:43 --> Severity: Notice --> Undefined variable: designation /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 63
ERROR - 2019-05-14 15:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 63
ERROR - 2019-05-14 15:17:43 --> Severity: Notice --> Undefined variable: department /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 81
ERROR - 2019-05-14 15:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 81
ERROR - 2019-05-14 15:17:43 --> Severity: Notice --> Undefined variable: leavetypeList /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 382
ERROR - 2019-05-14 15:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 382
ERROR - 2019-05-14 15:18:33 --> Severity: Notice --> Undefined variable: getStaffRole /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 44
ERROR - 2019-05-14 15:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 44
ERROR - 2019-05-14 15:18:33 --> Severity: Notice --> Undefined variable: designation /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 63
ERROR - 2019-05-14 15:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 63
ERROR - 2019-05-14 15:18:33 --> Severity: Notice --> Undefined variable: department /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 81
ERROR - 2019-05-14 15:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 81
ERROR - 2019-05-14 15:18:33 --> Severity: Notice --> Undefined variable: leavetypeList /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 382
ERROR - 2019-05-14 15:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/staff/staffedit.php 382
ERROR - 2019-05-14 12:38:59 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-14 17:34:31 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-14 17:46:49 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-14 18:01:06 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-14 18:02:07 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-14 18:03:41 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-14 18:56:11 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
