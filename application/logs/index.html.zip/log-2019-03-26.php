<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-26 11:30:43 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:30:43 --> Could not find the language line "back"
ERROR - 2019-03-26 11:30:50 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:30:50 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 11:30:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 11:30:50 --> Could not find the language line "back"
ERROR - 2019-03-26 11:30:50 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:30:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 07:07:34 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\smartschool\application\controllers\Studentfee.php 13
ERROR - 2019-03-26 11:39:25 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:39:25 --> Could not find the language line "back"
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:39:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:40:42 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:40:42 --> Could not find the language line "back"
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:40:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:44:42 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:44:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:44:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:44:42 --> Could not find the language line "back"
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:44:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:44:42 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:47:27 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:47:27 --> Could not find the language line "back"
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:47:27 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:48:22 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:48:22 --> Could not find the language line "back"
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:48:22 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:49:37 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:49:37 --> Could not find the language line "back"
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:49:37 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:52:29 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:52:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:52:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:52:29 --> Could not find the language line "back"
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:52:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:52:29 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 11:54:55 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 11:54:55 --> Could not find the language line "back"
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 11:54:55 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 11:54:56 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:00:17 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:00:17 --> Could not find the language line "back"
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:00:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:02:17 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:02:17 --> Could not find the language line "back"
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:02:17 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:02:18 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:06:26 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:06:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:06:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:06:26 --> Could not find the language line "back"
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:06:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:06:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:17:15 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:17:15 --> Could not find the language line "back"
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:17:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:18:11 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:18:11 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:18:11 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:18:11 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:18:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:18:12 --> Could not find the language line "back"
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:18:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:18:12 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:18:23 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:18:23 --> Could not find the language line "back"
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:18:23 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:22:20 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 76
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 78
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: class_section C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 90
ERROR - 2019-03-26 12:22:20 --> Could not find the language line "back"
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 160
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 163
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 167
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 169
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 173
ERROR - 2019-03-26 12:22:20 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 175
ERROR - 2019-03-26 12:22:21 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:22:21 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 191
ERROR - 2019-03-26 12:26:22 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:26:22 --> Could not find the language line "back"
ERROR - 2019-03-26 12:37:19 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 12:37:19 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 12:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 12:37:19 --> Could not find the language line "back"
ERROR - 2019-03-26 12:37:19 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 12:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:04:30 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:04:30 --> Could not find the language line "back"
ERROR - 2019-03-26 13:04:53 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:04:53 --> Could not find the language line "back"
ERROR - 2019-03-26 13:05:05 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:05:05 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:05:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:05:05 --> Could not find the language line "back"
ERROR - 2019-03-26 13:05:05 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:05:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:13:01 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:13:01 --> Could not find the language line "back"
ERROR - 2019-03-26 13:13:07 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:13:07 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:13:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:13:07 --> Could not find the language line "back"
ERROR - 2019-03-26 13:13:07 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:13:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:20:08 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:20:08 --> Could not find the language line "back"
ERROR - 2019-03-26 13:20:13 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:20:13 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:20:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:20:13 --> Could not find the language line "back"
ERROR - 2019-03-26 13:20:13 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:20:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:21:43 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:21:43 --> Could not find the language line "back"
ERROR - 2019-03-26 13:21:48 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:21:48 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:21:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:21:48 --> Could not find the language line "back"
ERROR - 2019-03-26 13:21:48 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:21:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:25:51 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:25:51 --> Could not find the language line "back"
ERROR - 2019-03-26 13:26:04 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:26:04 --> Could not find the language line "back"
ERROR - 2019-03-26 13:26:09 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 13:26:09 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:26:09 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:26:09 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 13:26:09 --> Could not find the language line "back"
ERROR - 2019-03-26 13:26:09 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 13:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:36:29 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:36:29 --> Could not find the language line "back"
ERROR - 2019-03-26 14:40:04 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:40:04 --> Could not find the language line "back"
ERROR - 2019-03-26 14:41:26 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:41:26 --> Could not find the language line "back"
ERROR - 2019-03-26 14:42:40 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:42:40 --> Could not find the language line "back"
ERROR - 2019-03-26 14:43:01 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:43:01 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:43:01 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:43:01 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:43:01 --> Could not find the language line "back"
ERROR - 2019-03-26 14:43:01 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:45:43 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:45:43 --> Could not find the language line "back"
ERROR - 2019-03-26 14:45:49 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:45:49 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:45:49 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:45:49 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:45:49 --> Could not find the language line "back"
ERROR - 2019-03-26 14:45:49 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:48:38 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:48:38 --> Could not find the language line "back"
ERROR - 2019-03-26 14:49:03 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:49:03 --> Could not find the language line "back"
ERROR - 2019-03-26 14:50:06 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:50:06 --> Could not find the language line "back"
ERROR - 2019-03-26 14:50:15 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:50:15 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:50:15 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:50:15 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:50:15 --> Could not find the language line "back"
ERROR - 2019-03-26 14:50:15 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:51:25 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:51:25 --> Could not find the language line "back"
ERROR - 2019-03-26 14:51:30 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 14:51:30 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:51:30 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:51:30 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 14:51:30 --> Could not find the language line "back"
ERROR - 2019-03-26 14:51:30 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 14:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 15:03:11 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:03:11 --> Could not find the language line "back"
ERROR - 2019-03-26 15:08:23 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:08:23 --> Could not find the language line "back"
ERROR - 2019-03-26 15:08:27 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:08:27 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 15:08:27 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 15:08:27 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-26 15:08:27 --> Could not find the language line "back"
ERROR - 2019-03-26 15:08:27 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-26 15:23:06 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:23:06 --> Could not find the language line "back"
ERROR - 2019-03-26 15:23:10 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:23:10 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:23:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:23:10 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:23:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:23:10 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:23:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:23:10 --> Could not find the language line "back"
ERROR - 2019-03-26 15:23:10 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:23:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:25:50 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:25:50 --> Could not find the language line "back"
ERROR - 2019-03-26 15:25:53 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:25:53 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:25:53 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:25:53 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:25:54 --> Could not find the language line "back"
ERROR - 2019-03-26 15:25:54 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:30:59 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:30:59 --> Could not find the language line "back"
ERROR - 2019-03-26 15:32:09 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:32:09 --> Could not find the language line "back"
ERROR - 2019-03-26 15:32:15 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:32:15 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:32:15 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:32:15 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:32:15 --> Could not find the language line "back"
ERROR - 2019-03-26 15:32:15 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:37:51 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:37:51 --> Could not find the language line "back"
ERROR - 2019-03-26 15:38:10 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:38:10 --> Could not find the language line "back"
ERROR - 2019-03-26 15:38:29 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:38:29 --> Could not find the language line "back"
ERROR - 2019-03-26 15:38:35 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:38:35 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:38:35 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:38:35 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:38:35 --> Could not find the language line "back"
ERROR - 2019-03-26 15:38:35 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:41:55 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:41:55 --> Could not find the language line "back"
ERROR - 2019-03-26 15:42:00 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:42:00 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:42:00 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:42:00 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-03-26 15:42:00 --> Could not find the language line "back"
ERROR - 2019-03-26 15:42:00 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-03-26 15:49:10 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:49:10 --> Could not find the language line "back"
ERROR - 2019-03-26 15:49:31 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:49:31 --> Could not find the language line "back"
ERROR - 2019-03-26 15:49:35 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:49:35 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 124
ERROR - 2019-03-26 15:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 124
ERROR - 2019-03-26 15:49:35 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 124
ERROR - 2019-03-26 15:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 124
ERROR - 2019-03-26 15:49:35 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 124
ERROR - 2019-03-26 15:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 124
ERROR - 2019-03-26 15:49:35 --> Could not find the language line "back"
ERROR - 2019-03-26 15:49:35 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 209
ERROR - 2019-03-26 15:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 209
ERROR - 2019-03-26 15:54:33 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:54:33 --> Could not find the language line "back"
ERROR - 2019-03-26 15:58:23 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 15:58:23 --> Could not find the language line "back"
ERROR - 2019-03-26 16:01:49 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:01:49 --> Could not find the language line "back"
ERROR - 2019-03-26 16:02:51 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:02:51 --> Could not find the language line "back"
ERROR - 2019-03-26 16:09:35 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:09:35 --> Could not find the language line "back"
ERROR - 2019-03-26 16:10:41 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:10:41 --> Could not find the language line "back"
ERROR - 2019-03-26 16:12:34 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:12:34 --> Could not find the language line "back"
ERROR - 2019-03-26 16:12:48 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:12:48 --> Could not find the language line "back"
ERROR - 2019-03-26 16:13:28 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:13:28 --> Could not find the language line "back"
ERROR - 2019-03-26 16:14:28 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:14:28 --> Could not find the language line "back"
ERROR - 2019-03-26 16:15:06 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:15:06 --> Could not find the language line "back"
ERROR - 2019-03-26 16:19:39 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:19:39 --> Could not find the language line "back"
ERROR - 2019-03-26 16:20:36 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:20:36 --> Could not find the language line "back"
ERROR - 2019-03-26 16:22:07 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:22:07 --> Could not find the language line "back"
ERROR - 2019-03-26 16:22:24 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 16:22:24 --> Could not find the language line "back"
ERROR - 2019-03-26 17:10:02 --> Could not find the language line "student_fee"
ERROR - 2019-03-26 17:10:02 --> Could not find the language line "back"
