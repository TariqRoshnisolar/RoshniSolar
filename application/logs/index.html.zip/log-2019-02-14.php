<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-14 12:02:56 --> Severity: Error --> Call to undefined function checkalreadyexit() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectforgrandtotal.php 58
ERROR - 2019-02-14 12:08:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectforgrandtotal.php 60
ERROR - 2019-02-14 12:20:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-14 12:20:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-14 12:20:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-02-14 12:20:32 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `mm_subjectforgrandtotal`
WHERE 0 = `Array`
OR 1 = `Array`
OR 2 = `Array`
ERROR - 2019-02-14 12:20:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smartschool\system\core\Exceptions.php:271) C:\xampp\htdocs\smartschool\system\core\Common.php 570
