<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-13 11:28:15 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:28:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 11:28:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 11:33:02 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:33:02 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 11:33:29 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:33:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 11:33:38 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:33:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 11:33:49 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:33:49 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 11:33:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 11:33:59 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:33:59 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 11:33:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 11:38:15 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:38:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 11:42:56 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:42:56 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 11:43:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 11:43:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 11:43:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 11:43:36 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 11:43:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 11:43:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:08:11 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:08:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 12:08:25 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:08:25 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:08:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:11:35 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:11:35 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:11:42 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:11:42 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:11:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:12:44 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:12:44 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:12:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:13:36 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:13:36 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:13:48 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:13:48 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:13:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:16:39 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:16:39 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:20:30 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:20:30 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:20:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:20:43 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:20:43 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:20:50 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:20:50 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:22:13 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:22:13 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:22:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:22:29 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:22:29 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:22:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:22:47 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:22:47 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:22:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:23:13 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:23:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 12:23:22 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:23:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 12:23:33 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:23:33 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:23:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:24:00 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:24:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 12:24:06 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:24:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 12:24:20 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:24:20 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-02-13 12:24:25 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:24:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-02-13 12:25:15 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:25:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:30:39 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:30:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:34:35 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:34:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:34:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:38:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:39:12 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:39:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:39:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:39:40 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:39:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:39:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:40:01 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:40:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:42:44 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:42:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:42:55 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:42:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:44:06 --> Could not find the language line "student_fees1"
ERROR - 2019-02-13 12:44:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-13 12:48:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 12:49:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 12:49:56 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 12:50:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:50:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-02-13 12:51:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 12:53:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 12:53:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 12:55:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 12:57:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 12:57:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 12:58:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 12:58:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:00:07 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 13:00:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:02:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:03:56 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:03:56 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:06:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 13:08:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 13:08:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:08:56 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:08:56 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:18:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-02-13 13:18:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 15:15:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 15:26:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-02-13 15:50:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\mark\markList.php 67
ERROR - 2019-02-13 15:50:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\mark\markList.php 67
ERROR - 2019-02-13 15:56:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examList.php 37
ERROR - 2019-02-13 17:17:54 --> Severity: Notice --> Undefined property: Subjectforgrandtotal::$mm_subjectforgrandtotal_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectforgrandtotal.php 59
ERROR - 2019-02-13 17:17:54 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectforgrandtotal.php 59
ERROR - 2019-02-13 17:49:43 --> Query error: Unknown column 'sfgt.classsection' in 'where clause' - Invalid query: SELECT `sfgt`.`id`, `sfgt`.`subject_id`, `subjects`.`name` as `subject_name`
FROM `mm_subjectforgrandtotal` `sfgt`
INNER JOIN `subjects` ON `subjects`.`id` = `sfgt`.`subject_id` and `subjects`.`is_active`='yes'
WHERE `sfgt`.`classsection` = '1'
AND `sfgt`.`is_deleted` =0
