<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-20 07:03:53 --> Severity: error --> Exception: C:\xampp\htdocs\smartschool\application\models/Mm_termsforexam_model.php exists, but doesn't declare class Mm_termsforexam_model C:\xampp\htdocs\smartschool\system\core\Loader.php 336
ERROR - 2019-02-20 11:34:48 --> Severity: Error --> Call to undefined method Mm_termsforexam_model::get() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Termsforexam.php 21
ERROR - 2019-02-20 11:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\termsForExam.php 70
ERROR - 2019-02-20 11:36:57 --> Severity: Notice --> Undefined variable: subjectlist C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\termsForExam.php 70
ERROR - 2019-02-20 11:36:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\termsForExam.php 70
ERROR - 2019-02-20 11:37:41 --> Severity: Notice --> Undefined variable: subjectlist C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\termsForExam.php 69
