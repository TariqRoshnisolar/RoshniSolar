<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-27 11:46:03 --> Could not find the language line "student_fee"
ERROR - 2019-03-27 11:46:03 --> Could not find the language line "back"
