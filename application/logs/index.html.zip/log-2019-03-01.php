<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-01 12:08:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\users\logindetailreport.php 106
ERROR - 2019-03-01 12:09:01 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:12:31 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:12:31 --> Could not find the language line "detail"
ERROR - 2019-03-01 12:12:31 --> Could not find the language line "file"
ERROR - 2019-03-01 12:12:31 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-01 12:12:31 --> Could not find the language line "Documents"
ERROR - 2019-03-01 12:14:26 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:15:06 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:16:03 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:16:55 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:17:56 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:17:56 --> Could not find the language line "detail"
ERROR - 2019-03-01 12:17:56 --> Could not find the language line "file"
ERROR - 2019-03-01 12:17:56 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-01 12:17:56 --> Could not find the language line "Documents"
ERROR - 2019-03-01 12:18:08 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:22:13 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:24:40 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:27:20 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:28:13 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:28:44 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:29:55 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:31:11 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:31:32 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:31:32 --> Could not find the language line "detail"
ERROR - 2019-03-01 12:31:32 --> Severity: Notice --> Undefined variable: student_doc_id C:\xampp\htdocs\smartschool\application\views\parent\student\getstudent.php 1046
ERROR - 2019-03-01 12:31:32 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-01 12:31:32 --> Could not find the language line "Documents"
ERROR - 2019-03-01 12:37:48 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:37:48 --> Could not find the language line "detail"
ERROR - 2019-03-01 12:37:48 --> Severity: Notice --> Undefined variable: student_doc_id C:\xampp\htdocs\smartschool\application\views\parent\student\getstudent.php 1046
ERROR - 2019-03-01 12:37:48 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-01 12:37:48 --> Could not find the language line "Documents"
ERROR - 2019-03-01 12:37:52 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:37:58 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:42:58 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:42:58 --> Could not find the language line "detail"
ERROR - 2019-03-01 12:42:58 --> Could not find the language line "file"
ERROR - 2019-03-01 12:42:58 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-01 12:42:58 --> Could not find the language line "Documents"
ERROR - 2019-03-01 12:43:08 --> Could not find the language line "student1"
ERROR - 2019-03-01 12:43:08 --> Could not find the language line "detail"
ERROR - 2019-03-01 12:43:08 --> Could not find the language line "file"
ERROR - 2019-03-01 12:43:08 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-01 12:43:08 --> Could not find the language line "Documents"
ERROR - 2019-03-01 13:18:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-01 13:20:46 --> Severity: Notice --> Undefined property: Subjectwisemarksentry::$mm_subjectwisemarksentry_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectwisemarksentry.php 84
ERROR - 2019-03-01 13:20:46 --> Severity: Error --> Call to a member function getstudent() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectwisemarksentry.php 84
ERROR - 2019-03-01 13:23:02 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-03-01 13:23:02 --> Query error:  - Invalid query: 
ERROR - 2019-03-01 13:24:43 --> Severity: Notice --> Undefined variable: classsection C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectwisemarksentry.php 85
ERROR - 2019-03-01 15:17:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when ('false'=1)
            then
            left join mm_subjecttostud' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when ('false'=1)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:18:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when ('false'==true)
            then
            left join mm_subjectto' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when ('false'==true)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:19:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when ('0'==true)
            then
            left join mm_subjecttostud' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when ('0'==true)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:20:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when ('0'==1)
            then
            left join mm_subjecttostudent' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when ('0'==1)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:21:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when ('0'=1)
            then
            left join mm_subjecttostudent ' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when ('0'=1)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:22:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when ('0'=1)
            then
            left join mm_subjecttostudent ' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when ('0'=1)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
           
            
ERROR - 2019-03-01 15:23:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(case when (1=1)
            then
            left join mm_subjecttostudent on' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            (case when (1=1)
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end)
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:24:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'case when 1=1
            then
            left join mm_subjecttostudent on (m' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            case when 1=1
            then
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            else
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            end
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:25:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'CASE WHEN 1=1
            THEN
            left join mm_subjecttostudent on (m' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            CASE WHEN 1=1
            THEN
            left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1'
            ELSE
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            END
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 15:30:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'CASE WHEN 0=1
            THEN
            (left join mm_subjecttostudent on (' at line 6 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            CASE WHEN 0=1
            THEN
            (left join mm_subjecttostudent on (mm_subjecttostudent.student_id=students.id and mm_subjecttostudent.is_deleted=0)
            where mm_subjecttostudent.subject_id='1')
            ELSE
            (left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1')
            END
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 17:16:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'from students
            inner join student_session on (student_session.studen' at line 3 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname,
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 17:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'from students
            inner join student_session on (student_session.studen' at line 3 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname,
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 17:18:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'from students 
            inner join student_session on (student_session.stude' at line 3 - Invalid query: select 
            students.admission_no, students.roll_no, students.firstname, students.lastname,
            from students 
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            and class_sections.id='1'
            and students.is_active='yes'
            
ERROR - 2019-03-01 17:24:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectwisemarksentry.php 89
ERROR - 2019-03-01 17:24:58 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectwisemarksentry.php 89
