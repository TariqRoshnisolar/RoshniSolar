<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-24 15:24:58 --> Severity: Error --> Call to undefined function post() C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Viewstudentimages.php 121
