<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-07 12:21:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 135
ERROR - 2019-03-07 12:22:12 --> Could not find the language line "student_fees1"
ERROR - 2019-03-07 12:22:19 --> Could not find the language line "student_fees1"
ERROR - 2019-03-07 12:22:27 --> Could not find the language line "student_fees1"
ERROR - 2019-03-07 12:22:34 --> Could not find the language line "student_fees1"
ERROR - 2019-03-07 12:22:41 --> Could not find the language line "student_fees1"
ERROR - 2019-03-07 12:23:47 --> Could not find the language line "student_fees1"
ERROR - 2019-03-07 12:25:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-07 12:28:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-07 12:29:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-07 12:32:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-07 12:34:04 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-07 12:38:20 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 140
ERROR - 2019-03-07 14:04:24 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\smartschool\application\models\Mm_subjectwisemarksentry_model.php 26
ERROR - 2019-03-07 14:04:24 --> Severity: Error --> Call to a member function result_array() on null C:\xampp\htdocs\smartschool\application\models\Mm_subjectwisemarksentry_model.php 26
ERROR - 2019-03-07 14:27:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, grade as 0
            from students
            inner join student_session' at line 2 - Invalid query: select 
            students.id as student_id, students.admission_no, students.roll_no, students.firstname, students.lastname, marks as 0, grade as 0
            from students
            inner join student_session on (student_session.student_id=students.id and student_session.session_id='13' and student_session.is_active='yes')
            inner join class_sections on (class_sections.class_id=student_session.class_id and class_sections.section_id=student_session.section_id and class_sections.is_active='yes')
            left join mm_subjecttoclass on (mm_subjecttoclass.classsection=class_sections.id and mm_subjecttoclass.is_deleted=0)
            where mm_subjecttoclass.subject='1'
            and class_sections.id='1'
            and students.is_active='yes'
            and students.id not in (1)
            
ERROR - 2019-03-07 14:33:51 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-03-07 14:34:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
