<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-30 07:16:22 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 63
ERROR - 2019-04-30 09:02:05 --> Severity: Notice --> Undefined variable: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 117
ERROR - 2019-04-30 09:02:57 --> Severity: Notice --> Undefined index: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 117
ERROR - 2019-04-30 09:05:01 --> Severity: Notice --> Undefined index: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 117
ERROR - 2019-04-30 09:06:16 --> Severity: Notice --> Undefined index: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\pages\page.php 2
ERROR - 2019-04-30 09:06:16 --> Severity: Notice --> Undefined index: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 117
ERROR - 2019-04-30 09:06:53 --> Severity: Notice --> Undefined index: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\pages\page.php 2
ERROR - 2019-04-30 09:06:55 --> Severity: Notice --> Undefined index: listMenus C:\xampp\htdocs\uvsil\application\views\themes\default\pages\page.php 2
ERROR - 2019-04-30 09:19:51 --> Query error: Unknown column 'about' in 'where clause' - Invalid query: SELECT * 
                    FROM front_cms_menu_items AS F1
                    INNER JOIN front_cms_menu_items AS F2
                    ON (F1.id = F2.parent_id)
                    WHERE F1.slug=about-us
ERROR - 2019-04-30 09:33:52 --> Query error: Unknown column 'F2.page_url' in 'field list' - Invalid query: SELECT F2.menu, F2.slug, F2.open_new_tab, F2.ext_url, F2.ext_url_link, F2.page_url 
                    FROM front_cms_menu_items AS F1
                    INNER JOIN front_cms_menu_items AS F2
                    ON (F1.id = F2.parent_id)
                    WHERE F1.slug='about-us'
ERROR - 2019-04-30 09:36:22 --> Query error: Unknown column 'F2.page_url' in 'field list' - Invalid query: SELECT F2.menu, F2.slug, F2.open_new_tab, F2.ext_url, F2.ext_url_link, F2.page_url, front_cms_pages.url as `page_url` 
                    FROM front_cms_menu_items AS F1
                    INNER JOIN front_cms_menu_items AS F2
                    ON (F1.id = F2.parent_id)
                    LEFT JOIN front_cms_pages
                    ON (front_cms_pages.id = F2.page_id)
                    WHERE F1.slug='about-us'
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 122
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 125
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 128
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 122
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 125
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 128
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 122
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 125
ERROR - 2019-04-30 09:37:06 --> Severity: Notice --> Undefined variable: menu_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 128
ERROR - 2019-04-30 13:37:28 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-30 13:37:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-30 13:38:39 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-30 13:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-30 13:41:25 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-30 13:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-30 13:44:36 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 196
ERROR - 2019-04-30 13:44:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 196
ERROR - 2019-04-30 15:11:27 --> Could not find the language line "detail"
ERROR - 2019-04-30 15:14:28 --> Could not find the language line "detail"
ERROR - 2019-04-30 13:04:53 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\uvsil\application\views\themes\default\pages\page.php 32
