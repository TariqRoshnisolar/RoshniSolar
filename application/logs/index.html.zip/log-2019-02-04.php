<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-04 12:22:34 --> Could not find the language line "student_fees1"
ERROR - 2019-02-04 12:22:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-02-04 12:22:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
