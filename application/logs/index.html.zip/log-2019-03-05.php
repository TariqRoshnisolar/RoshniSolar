<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-05 11:45:35 --> Could not find the language line "student1"
ERROR - 2019-03-05 11:45:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 11:45:44 --> Could not find the language line "student1"
ERROR - 2019-03-05 11:45:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 11:46:09 --> Could not find the language line "student1"
ERROR - 2019-03-05 11:46:09 --> Could not find the language line "detail"
ERROR - 2019-03-05 11:46:09 --> Could not find the language line "file"
ERROR - 2019-03-05 11:46:09 --> Could not find the language line "upload_documents1"
ERROR - 2019-03-05 11:46:09 --> Could not find the language line "Documents"
ERROR - 2019-03-05 11:51:53 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 11:52:47 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 11:54:14 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 11:54:33 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 11:55:47 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:22:14 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:22:14 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:22:38 --> Severity: Notice --> Undefined variable: vehroute_result C:\xampp\htdocs\rhsmemorial\application\controllers\Classes.php 55
ERROR - 2019-03-05 12:22:38 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:18 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:19 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:32 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:32 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:44 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:44 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:44 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:44 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:45 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:45 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:45 --> Severity: Notice --> Undefined variable: vehiclelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 61
ERROR - 2019-03-05 12:30:45 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\class\classList.php 119
ERROR - 2019-03-05 12:37:31 --> Could not find the language line "student1"
ERROR - 2019-03-05 12:37:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 12:37:35 --> Could not find the language line "student1"
ERROR - 2019-03-05 12:37:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 12:50:45 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:50:52 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:51:00 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:51:08 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:51:15 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:51:21 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:51:26 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:53:03 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:55:26 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:56:18 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:58:30 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 12:59:05 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 13:28:47 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 13:28:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-03-05 13:29:31 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 13:29:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-03-05 13:30:14 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 13:30:14 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-03-05 13:30:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-03-05 13:30:32 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 13:30:32 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-03-05 13:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-03-05 13:30:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-03-05 13:30:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-03-05 14:33:10 --> Could not find the language line "class1"
ERROR - 2019-03-05 14:33:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentCreate.php 65
ERROR - 2019-03-05 14:33:40 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:33:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 14:33:42 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:33:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\disablestudents.php 38
ERROR - 2019-03-05 14:33:42 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\rhsmemorial\application\views\student\disablestudents.php 93
ERROR - 2019-03-05 14:33:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\admissionReport.php 106
ERROR - 2019-03-05 14:35:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentCreate.php 65
ERROR - 2019-03-05 14:35:46 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:35:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 14:47:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentCreate.php 65
ERROR - 2019-03-05 14:52:22 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:52:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\disablestudents.php 38
ERROR - 2019-03-05 14:52:22 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\rhsmemorial\application\views\student\disablestudents.php 93
ERROR - 2019-03-05 14:56:06 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:56:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\disablestudents.php 38
ERROR - 2019-03-05 14:56:06 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\rhsmemorial\application\views\student\disablestudents.php 93
ERROR - 2019-03-05 14:56:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentCreate.php 65
ERROR - 2019-03-05 14:56:59 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:56:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentSearch.php 38
ERROR - 2019-03-05 14:57:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\admissionReport.php 106
ERROR - 2019-03-05 14:57:31 --> Could not find the language line "student1"
ERROR - 2019-03-05 14:57:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\exportstudents.php 45
ERROR - 2019-03-05 14:57:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-03-05 14:57:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentReport.php 30
ERROR - 2019-03-05 14:57:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\guardianReport.php 106
ERROR - 2019-03-05 14:57:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\logindetailreport.php 106
ERROR - 2019-03-05 14:57:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\admissionReport.php 106
ERROR - 2019-03-05 14:58:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\logindetailreport.php 106
ERROR - 2019-03-05 15:00:14 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:00:14 --> Could not find the language line "back"
ERROR - 2019-03-05 15:10:41 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:10:41 --> Could not find the language line "back"
ERROR - 2019-03-05 15:11:10 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ',' or ';' C:\xampp\htdocs\rhsmemorial\application\views\studentfee\studentAddfee.php 357
ERROR - 2019-03-05 15:11:20 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ',' or ';' C:\xampp\htdocs\rhsmemorial\application\views\studentfee\studentAddfee.php 357
ERROR - 2019-03-05 15:11:29 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\rhsmemorial\application\views\studentfee\studentAddfee.php 358
ERROR - 2019-03-05 15:12:07 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:12:07 --> Could not find the language line "back"
ERROR - 2019-03-05 15:12:21 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:12:21 --> Could not find the language line "back"
ERROR - 2019-03-05 15:12:38 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:12:38 --> Could not find the language line "back"
ERROR - 2019-03-05 15:13:34 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\rhsmemorial\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-05 15:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-05 15:13:43 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\rhsmemorial\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-05 15:13:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-05 15:18:25 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ',' or ';' C:\xampp\htdocs\rhsmemorial\application\views\admin\feegroup\feegroupList.php 104
ERROR - 2019-03-05 15:27:33 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:27:34 --> Could not find the language line "student_fee"
ERROR - 2019-03-05 15:27:40 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:27:47 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:27:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\stuattendence\attendenceList.php 125
ERROR - 2019-03-05 15:27:48 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:28:36 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:28:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\stuattendence\classattendencereport.php 41
ERROR - 2019-03-05 15:28:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\stuattendence\attendencereport.php 113
ERROR - 2019-03-05 15:28:47 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:28:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\stuattendence\attendenceList.php 125
ERROR - 2019-03-05 15:29:26 --> Could not find the language line "setting1"
ERROR - 2019-03-05 15:29:26 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:26 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:26 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:27 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:28 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:29 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:30 --> Could not find the language line "add/edit"
ERROR - 2019-03-05 15:29:31 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 167
ERROR - 2019-03-05 15:29:31 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 168
ERROR - 2019-03-05 15:29:31 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 169
ERROR - 2019-03-05 15:32:35 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 169
ERROR - 2019-03-05 15:32:35 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 170
ERROR - 2019-03-05 15:32:35 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 171
ERROR - 2019-03-05 15:32:55 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 169
ERROR - 2019-03-05 15:32:55 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 170
ERROR - 2019-03-05 15:32:55 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 171
ERROR - 2019-03-05 15:33:06 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 169
ERROR - 2019-03-05 15:33:06 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 170
ERROR - 2019-03-05 15:33:06 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 171
ERROR - 2019-03-05 15:33:12 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 169
ERROR - 2019-03-05 15:33:12 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 170
ERROR - 2019-03-05 15:33:12 --> Severity: Notice --> Undefined variable: sibling C:\xampp\htdocs\rhsmemorial\application\views\admin\users\userList.php 171
ERROR - 2019-03-05 15:33:38 --> Could not find the language line "filter_by_name1"
ERROR - 2019-03-05 15:33:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\studentReport.php 30
ERROR - 2019-03-05 15:33:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\student\guardianReport.php 106
ERROR - 2019-03-05 15:33:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\admissionReport.php 106
ERROR - 2019-03-05 15:33:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\users\logindetailreport.php 106
ERROR - 2019-03-05 15:33:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\route\studentroutedetails.php 105
ERROR - 2019-03-05 15:33:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-03-05 15:33:45 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:33:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\stuattendence\classattendencereport.php 41
ERROR - 2019-03-05 15:34:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\staffattendance\attendancereport.php 41
ERROR - 2019-03-05 15:34:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\homework\homework_evaluation.php 40
ERROR - 2019-03-05 15:34:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\mark\markList.php 67
ERROR - 2019-03-05 15:36:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-03-05 15:36:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-03-05 15:37:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\route\studentroutedetails.php 105
ERROR - 2019-03-05 15:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\book\getall.php 56
ERROR - 2019-03-05 15:39:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\member\studentSearch.php 32
ERROR - 2019-03-05 15:39:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\homework\homeworklist.php 40
ERROR - 2019-03-05 15:39:49 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\homework\homework_evaluation.php 40
ERROR - 2019-03-05 15:44:12 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:44:14 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:44:14 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:44:16 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:44:18 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:44:19 --> Could not find the language line "by_date1"
ERROR - 2019-03-05 15:47:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\staffattendance\attendancereport.php 41
ERROR - 2019-03-05 15:47:56 --> Could not find the language line "clear"
ERROR - 2019-03-05 15:47:56 --> Could not find the language line "clear"
ERROR - 2019-03-05 15:47:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\payroll\stafflist.php 81
ERROR - 2019-03-05 15:47:59 --> Could not find the language line "Name"
ERROR - 2019-03-05 15:48:36 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 15:49:08 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 15:49:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableList.php 63
ERROR - 2019-03-05 15:49:09 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 15:49:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\stdtransfer\stdtransfer.php 33
ERROR - 2019-03-05 15:49:09 --> Could not find the language line "array_search(needle, haystack)"
ERROR - 2019-03-05 15:49:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-03-05 15:49:19 --> Could not find the language line "student_fees1"
ERROR - 2019-03-05 15:49:19 --> Severity: Notice --> Undefined variable: sectionlist C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-03-05 15:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\timetable\timetableCreate.php 54
ERROR - 2019-03-05 15:49:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-03-05 15:53:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\teacher\viewassignTeacher.php 52
ERROR - 2019-03-05 15:56:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\teacher\assignTeacher.php 45
ERROR - 2019-03-05 16:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\marksmanager\gradeScaleForSubject.php 43
ERROR - 2019-03-05 16:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\rhsmemorial\application\views\admin\marksmanager\gradeScaleForSubject.php 118
ERROR - 2019-03-05 16:00:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\exam_schedule\examList.php 37
ERROR - 2019-03-05 16:00:14 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\mark\markList.php 67
ERROR - 2019-03-05 17:44:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\rhsmemorial\application\views\admin\payroll\stafflist.php 81
ERROR - 2019-03-05 17:44:36 --> Could not find the language line "Name"
