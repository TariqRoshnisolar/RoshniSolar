<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-01 06:51:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\uvsil\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-05-01 06:51:21 --> Unable to connect to the database
ERROR - 2019-05-01 07:37:13 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/trigenterp/public_html/uvsil/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-05-01 07:37:13 --> Unable to connect to the database
ERROR - 2019-05-01 07:41:16 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 58
ERROR - 2019-05-01 07:41:16 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 101
ERROR - 2019-05-01 07:41:16 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 229
ERROR - 2019-05-01 09:03:48 --> Severity: error --> Exception: /home/trigenterp/public_html/uvsil/application/models/Cms_menuitems_model.php exists, but doesn't declare class Cms_menuitems_model /home/trigenterp/public_html/uvsil/system/core/Loader.php 336
ERROR - 2019-05-01 09:04:25 --> Severity: Error --> Call to undefined method Cms_menuitems_model::getSubMenu() /home/trigenterp/public_html/uvsil/application/controllers/Welcome.php 61
ERROR - 2019-05-01 09:04:57 --> Severity: Error --> Call to undefined method Cms_menuitems_model::getMenus() /home/trigenterp/public_html/uvsil/application/core/MY_Controller.php 188
ERROR - 2019-05-01 09:04:58 --> Severity: Error --> Call to undefined method Cms_menuitems_model::getMenus() /home/trigenterp/public_html/uvsil/application/core/MY_Controller.php 188
ERROR - 2019-05-01 09:04:58 --> Severity: Error --> Call to undefined method Cms_menuitems_model::getMenus() /home/trigenterp/public_html/uvsil/application/core/MY_Controller.php 188
ERROR - 2019-05-01 09:21:13 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 58
ERROR - 2019-05-01 09:21:13 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 101
ERROR - 2019-05-01 09:21:13 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 229
ERROR - 2019-05-01 09:24:32 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 101
ERROR - 2019-05-01 09:24:32 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 229
ERROR - 2019-05-01 09:25:28 --> Severity: Notice --> Undefined index: is_homepage /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 229
ERROR - 2019-05-01 15:26:42 --> Severity: Notice --> Undefined variable: order /home/trigenterp/public_html/uvsil/application/controllers/admin/front/Menus.php 181
ERROR - 2019-05-01 15:26:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/controllers/admin/front/Menus.php 181
ERROR - 2019-05-01 15:26:42 --> Could not find the language line "update_batch() called with no data"
ERROR - 2019-05-01 15:35:40 --> Severity: Error --> Cannot use object of type stdClass as array /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 195
ERROR - 2019-05-01 15:35:59 --> Severity: Error --> Cannot use object of type stdClass as array /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 197
ERROR - 2019-05-01 15:39:22 --> Severity: Error --> Cannot use object of type stdClass as array /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 197
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:18 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:44:53 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:47:47 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 199
ERROR - 2019-05-01 15:50:49 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 203
ERROR - 2019-05-01 15:57:26 --> Severity: Notice --> Undefined index: id /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 217
ERROR - 2019-05-01 15:57:26 --> Severity: Notice --> Undefined index: menu /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 219
ERROR - 2019-05-01 15:57:26 --> Severity: Notice --> Undefined index: slug /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 222
ERROR - 2019-05-01 15:57:26 --> Severity: Notice --> Undefined index: id /home/trigenterp/public_html/uvsil/application/views/admin/front/menus/additem.php 223
ERROR - 2019-05-01 10:55:05 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 142
ERROR - 2019-05-01 10:59:39 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 94
ERROR - 2019-05-01 10:59:58 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 137
ERROR - 2019-05-01 11:00:00 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 137
ERROR - 2019-05-01 11:00:30 --> Severity: Notice --> Undefined variable: csubmenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 90
ERROR - 2019-05-01 11:00:30 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Notice --> Undefined variable: csubmenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 90
ERROR - 2019-05-01 11:00:34 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Notice --> Undefined index: submenus /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 11:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/trigenterp/public_html/uvsil/application/views/themes/default/header.php 100
ERROR - 2019-05-01 16:43:05 --> Severity: Warning --> unlink(): No such file or directory /home/trigenterp/public_html/uvsil/application/controllers/admin/Frontcms.php 77
