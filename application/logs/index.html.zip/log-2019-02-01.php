<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-01 12:46:10 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 57
ERROR - 2019-02-01 12:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 57
ERROR - 2019-02-01 12:51:52 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:52:07 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 59
ERROR - 2019-02-01 12:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 59
ERROR - 2019-02-01 12:52:31 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:55:05 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:57:33 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 61
ERROR - 2019-02-01 12:58:14 --> Severity: Notice --> Undefined index: wing_id C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 63
ERROR - 2019-02-01 13:20:32 --> Severity: Notice --> Undefined property: stdClass::$wingname C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 140
ERROR - 2019-02-01 13:20:32 --> Severity: Notice --> Undefined property: stdClass::$wingname C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 140
ERROR - 2019-02-01 13:20:32 --> Severity: Notice --> Undefined property: stdClass::$wingname C:\xampp\htdocs\smartschool\application\views\class\classEdit.php 140
ERROR - 2019-02-01 13:49:56 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smartschool`.`fee_groups_classes`, CONSTRAINT `fee_groups_classes_class_sections` FOREIGN KEY (`class`) REFERENCES `class_sections` (`id`)) - Invalid query: DELETE FROM `class_sections`
WHERE `class_id` = '7'
AND `section_id` IN('2', '3')
ERROR - 2019-02-01 13:52:34 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smartschool`.`fee_groups_classes`, CONSTRAINT `fee_groups_classes_class_sections` FOREIGN KEY (`class`) REFERENCES `class_sections` (`id`)) - Invalid query: DELETE FROM `class_sections`
WHERE `class_id` = '7'
AND `section_id` IN('3')
ERROR - 2019-02-01 15:35:29 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\admin\staff\staffcreate.php 90
ERROR - 2019-02-01 15:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\staff\staffcreate.php 90
ERROR - 2019-02-01 15:36:26 --> Severity: Notice --> Undefined variable: winglist C:\xampp\htdocs\smartschool\application\views\admin\staff\staffcreate.php 90
ERROR - 2019-02-01 15:36:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\staff\staffcreate.php 90
ERROR - 2019-02-01 15:49:03 --> Could not find the language line "detail"
ERROR - 2019-02-01 15:51:34 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:02:45 --> Query error: Unknown column 'staff.is_active' in 'where clause' - Invalid query: SELECT `staff`.`name`, `staff`.`surname`, `staff`.`employee_id`, `staff_leave_request`.*, `leave_types`.`type`
FROM `staff_leave_request`
JOIN `staff` ON `staff`.`id` = `staff_leave_request`.`staff_id`
JOIN `leave_types` ON `leave_types`.`id` = `staff_leave_request`.`leave_type_id`
WHERE `staff_leave_request`.`staff_id` = '1'
AND `staff`.`is_active` = '1'
ORDER BY `staff_leave_request`.`id` DESC
ERROR - 2019-02-01 16:07:51 --> Query error: Unknown column 'staff.is_deleted' in 'where clause' - Invalid query: SELECT `staff`.*, `staff_designation`.`designation` as `designation`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
WHERE `staff`.`id` = '1'
AND `staff`.`is_deleted` =0
ERROR - 2019-02-01 16:08:15 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:08:38 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:09:27 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:11:44 --> Query error: Unknown column 'wings.wingname' in 'field list' - Invalid query: SELECT `staff`.*, `wings`.`wingname`, `staff_designation`.`designation` as `designation`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '8'
AND `staff`.`is_active` = 1
ERROR - 2019-02-01 16:12:02 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:20:04 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:20:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-02-01 16:20:14 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-02-01 16:20:14 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:26:51 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-02-01 16:26:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-02-01 16:26:51 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:27:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-02-01 16:27:14 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-02-01 16:27:14 --> Could not find the language line "detail"
ERROR - 2019-02-01 16:27:57 --> Could not find the language line "detail"
