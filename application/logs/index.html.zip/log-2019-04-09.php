<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-09 06:06:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-04-09 06:06:48 --> Unable to connect to the database
ERROR - 2019-04-09 06:06:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-04-09 06:06:55 --> Unable to connect to the database
ERROR - 2019-04-09 10:05:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:05:13 --> Could not find the language line "back"
ERROR - 2019-04-09 06:51:50 --> Severity: Parsing Error --> syntax error, unexpected ''UNION ALL'' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 169
ERROR - 2019-04-09 10:23:01 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:23:01 --> Could not find the language line "back"
ERROR - 2019-04-09 10:23:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 169
ERROR - 2019-04-09 10:23:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'UNION ALL' at line 1 - Invalid query:  UNION ALL 
ERROR - 2019-04-09 10:30:21 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:30:21 --> Could not find the language line "back"
ERROR - 2019-04-09 10:30:59 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-04-09 10:30:59 --> Query error:  - Invalid query: 
ERROR - 2019-04-09 10:31:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:31:23 --> Could not find the language line "back"
ERROR - 2019-04-09 10:35:25 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:35:25 --> Could not find the language line "back"
ERROR - 2019-04-09 10:35:55 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:35:55 --> Could not find the language line "back"
ERROR - 2019-04-09 07:09:56 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 175
ERROR - 2019-04-09 10:40:24 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:40:24 --> Could not find the language line "back"
ERROR - 2019-04-09 10:43:35 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 10:43:35 --> Could not find the language line "back"
ERROR - 2019-04-09 10:43:41 --> Query error: Operand should contain 1 column(s) - Invalid query: select 
                   (select fee_head.id as feehead, fee_head.name as feeheadname from fee_head where fee_head.is_deleted=0 and fee_head.is_hostel=1), hostel_rooms.cost_per_bed*4 as amount
                   from hostel_rooms
                   where hostel_rooms.id = 1
                  
ERROR - 2019-04-09 10:54:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\create.php 61
ERROR - 2019-04-09 11:28:53 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:28:53 --> Could not find the language line "back"
ERROR - 2019-04-09 11:34:30 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:34:30 --> Could not find the language line "back"
ERROR - 2019-04-09 11:50:31 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:50:31 --> Could not find the language line "back"
ERROR - 2019-04-09 11:50:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1)' at line 2 - Invalid query: select fee_head.id as feehead, fee_head.name as feeheadname, feetype.type as feetypename, pay_schedule.name as payschedule
          (SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1) As amount from fee_head 
          left join feetype on (feetype.id = fee_head.feetype and feetype.is_deleted=0)
          left join pay_schedule on (pay_schedule.id = fee_head.payschedule and pay_schedule.is_deleted=0)
          where fee_head.is_deleted=0 and fee_head.is_hostel=1
ERROR - 2019-04-09 11:51:38 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:51:38 --> Could not find the language line "back"
ERROR - 2019-04-09 11:51:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1)' at line 2 - Invalid query: select fee_head.id as feehead, fee_head.name as feeheadname, feetype.type as feetypename
          (SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1) As amount from fee_head 
          left join feetype on (feetype.id = fee_head.feetype and feetype.is_deleted=0)

          where fee_head.is_deleted=0 and fee_head.is_hostel=1
ERROR - 2019-04-09 11:52:45 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:52:45 --> Could not find the language line "back"
ERROR - 2019-04-09 11:52:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1)' at line 2 - Invalid query: select fee_head.id as feehead, fee_head.name as feeheadname
          (SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1) As amount from fee_head 

          where fee_head.is_deleted=0 and fee_head.is_hostel=1
ERROR - 2019-04-09 11:53:53 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:53:53 --> Could not find the language line "back"
ERROR - 2019-04-09 11:54:14 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:54:14 --> Could not find the language line "back"
ERROR - 2019-04-09 11:54:34 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:54:34 --> Could not find the language line "back"
ERROR - 2019-04-09 11:56:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:56:23 --> Could not find the language line "back"
ERROR - 2019-04-09 11:56:47 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:56:47 --> Could not find the language line "back"
ERROR - 2019-04-09 11:58:10 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:58:10 --> Could not find the language line "back"
ERROR - 2019-04-09 11:58:41 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:58:41 --> Could not find the language line "back"
ERROR - 2019-04-09 11:59:52 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 11:59:52 --> Could not find the language line "back"
ERROR - 2019-04-09 11:59:58 --> Query error: Unknown column 'feetype.name' in 'field list' - Invalid query: select fee_head.id as feehead, fee_head.name as feeheadname, pay_schedule.name as payschedule, feetype.name as feetype, (SELECT hostel_rooms.cost_per_bed*4 from hostel_rooms where hostel_rooms.id = 1) As amount from fee_head 
          left join feetype on (feetype.id=fee_head.feetype and feetype.is_deleted=0) 
          left join pay_schedule on (pay_schedule.id=fee_head.payschedule and pay_schedule.is_deleted=0) 
          where fee_head.is_deleted=0 and fee_head.is_hostel=1
ERROR - 2019-04-09 12:00:36 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:00:36 --> Could not find the language line "back"
ERROR - 2019-04-09 12:00:59 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:00:59 --> Could not find the language line "back"
ERROR - 2019-04-09 12:02:17 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:02:17 --> Could not find the language line "back"
ERROR - 2019-04-09 12:08:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:08:23 --> Could not find the language line "back"
ERROR - 2019-04-09 12:13:02 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:13:02 --> Could not find the language line "back"
ERROR - 2019-04-09 12:13:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:13:23 --> Could not find the language line "back"
ERROR - 2019-04-09 08:51:26 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\smartschool\application\controllers\Studentfee.php 330
ERROR - 2019-04-09 12:21:48 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:21:48 --> Could not find the language line "back"
ERROR - 2019-04-09 12:22:35 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:22:35 --> Could not find the language line "back"
ERROR - 2019-04-09 12:23:39 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:23:39 --> Could not find the language line "back"
ERROR - 2019-04-09 12:24:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-09 12:24:13 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-09 12:24:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-09 12:24:13 --> Could not find the language line "back"
ERROR - 2019-04-09 12:24:13 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-09 12:24:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-09 13:04:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 132
ERROR - 2019-04-09 13:06:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 132
ERROR - 2019-04-09 13:07:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 132
ERROR - 2019-04-09 13:07:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 133
ERROR - 2019-04-09 13:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 133
ERROR - 2019-04-09 14:31:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\users\logindetailreport.php 106
