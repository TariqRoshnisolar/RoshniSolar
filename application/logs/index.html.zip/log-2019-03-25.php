<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-25 10:32:01 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 10:32:01 --> Could not find the language line "back"
ERROR - 2019-03-25 11:01:16 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:01:16 --> Could not find the language line "back"
ERROR - 2019-03-25 11:03:02 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:03:02 --> Could not find the language line "back"
ERROR - 2019-03-25 11:12:52 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:12:52 --> Could not find the language line "back"
ERROR - 2019-03-25 11:23:41 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:23:41 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-25 11:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-25 11:23:41 --> Could not find the language line "back"
ERROR - 2019-03-25 11:23:41 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-25 11:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-25 11:24:20 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:24:20 --> Could not find the language line "back"
ERROR - 2019-03-25 11:26:40 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:26:40 --> Could not find the language line "back"
ERROR - 2019-03-25 11:47:36 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:47:36 --> Could not find the language line "back"
ERROR - 2019-03-25 11:47:45 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:47:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:49:25 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:49:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:50:03 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:50:34 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:50:55 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:51:40 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:51:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:52:30 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:52:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:55:14 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:55:29 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 11:56:53 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 11:56:53 --> Could not find the language line "back"
ERROR - 2019-03-25 12:48:30 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 12:48:30 --> Could not find the language line "back"
ERROR - 2019-03-25 12:51:25 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 12:51:25 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-25 12:51:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-25 12:51:25 --> Could not find the language line "back"
ERROR - 2019-03-25 12:51:25 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-25 12:51:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-25 12:52:40 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 12:52:40 --> Could not find the language line "back"
ERROR - 2019-03-25 12:54:24 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:54:57 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:55:19 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:55:29 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:58:44 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:59:03 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:13:40 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:13:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:15:08 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:15:16 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:15:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:16:09 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:31:39 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:34:56 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:35:16 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:36:54 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:37:34 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 13:37:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:31:01 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:31:54 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:32:14 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:32:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:32:33 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:32:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:32:43 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:02 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:09 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:17 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:30 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:45:38 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:45:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:45:48 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:45:58 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:13 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:19 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:25 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:31 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-03-25 14:49:15 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 14:49:15 --> Could not find the language line "back"
ERROR - 2019-03-25 15:00:12 --> Query error: Unknown column 'assign_fee_amount_group.totalamt' in 'field list' - Invalid query: select ins.*, assign_fee_amount_group.totalamt from feeinstallment ins where ins.id not in (select stufee.installment from stu_fee_detail stufee where stufee.student='1' and stufee.yearsession='14' and stufee.is_deleted=0) and ins.is_deleted=0 order by ins.type
ERROR - 2019-03-25 15:01:21 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:01:21 --> Could not find the language line "back"
ERROR - 2019-03-25 15:01:21 --> Severity: Notice --> Undefined index: totalamt C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 953
ERROR - 2019-03-25 15:01:21 --> Severity: Notice --> Undefined index: totalamt C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 953
ERROR - 2019-03-25 15:01:21 --> Severity: Notice --> Undefined index: totalamt C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 953
ERROR - 2019-03-25 15:10:40 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:10:40 --> Could not find the language line "back"
ERROR - 2019-03-25 15:10:40 --> Severity: Notice --> Undefined index: totalamt C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 953
ERROR - 2019-03-25 15:10:40 --> Severity: Notice --> Undefined index: totalamt C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 953
ERROR - 2019-03-25 15:10:40 --> Severity: Notice --> Undefined index: totalamt C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 953
ERROR - 2019-03-25 15:16:55 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:16:55 --> Could not find the language line "back"
ERROR - 2019-03-25 15:22:24 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:22:24 --> Could not find the language line "back"
ERROR - 2019-03-25 15:23:04 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:23:04 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-25 15:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 98
ERROR - 2019-03-25 15:23:04 --> Could not find the language line "back"
ERROR - 2019-03-25 15:23:04 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-25 15:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 183
ERROR - 2019-03-25 15:26:42 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:26:42 --> Could not find the language line "back"
ERROR - 2019-03-25 15:31:43 --> Could not find the language line "student_fee"
ERROR - 2019-03-25 15:31:43 --> Could not find the language line "back"
