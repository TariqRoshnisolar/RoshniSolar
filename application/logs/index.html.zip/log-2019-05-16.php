<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-16 04:00:33 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 04:37:19 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 05:35:55 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 05:36:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 05:36:30 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 05:38:11 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 05:45:42 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 06:01:18 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 06:18:19 --> Severity: Notice --> Undefined variable: base_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:18:22 --> Severity: Notice --> Undefined variable: base_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:18:29 --> Severity: Notice --> Undefined variable: base_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:18:57 --> Severity: Notice --> Undefined variable: base_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:19:16 --> Severity: Notice --> Undefined variable: site_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:19:19 --> Severity: Notice --> Undefined variable: site_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:19:26 --> Severity: Notice --> Undefined variable: site_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:19:27 --> Severity: Notice --> Undefined variable: site_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:19:28 --> Severity: Notice --> Undefined variable: site_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:19:31 --> Severity: Notice --> Undefined variable: site_url /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 14
ERROR - 2019-05-16 06:20:41 --> Severity: Error --> Call to undefined function /backend/themes/default/() /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 6
ERROR - 2019-05-16 06:21:36 --> Severity: Error --> Call to undefined function /backend/themes/default/() /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 6
ERROR - 2019-05-16 06:21:43 --> Severity: Error --> Call to undefined function /backend/themes/default/() /home/o2ixr95i7zue/public_html/application/views/themes/default/header.php 6
ERROR - 2019-05-16 06:36:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/o2ixr95i7zue/public_html/application/controllers/Contact.php 83
ERROR - 2019-05-16 06:58:46 --> Severity: Parsing Error --> syntax error, unexpected '<' /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 175
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 12
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 15
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 18
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 25
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 145
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 146
ERROR - 2019-05-16 08:02:11 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 147
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 12
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 15
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 18
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 25
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 145
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 146
ERROR - 2019-05-16 08:02:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 147
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 12
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 15
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 18
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 25
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 145
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 146
ERROR - 2019-05-16 08:02:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/index.php 147
ERROR - 2019-05-16 11:56:27 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/payment.php 9
ERROR - 2019-05-16 11:56:27 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/payment.php 12
ERROR - 2019-05-16 11:56:27 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/payment.php 12
ERROR - 2019-05-16 11:57:41 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 11:57:41 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/details.php 12
ERROR - 2019-05-16 11:57:41 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/details.php 12
ERROR - 2019-05-16 11:57:55 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 11:57:55 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 11:57:55 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:03:40 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:03:40 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:03:40 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:03:45 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 12:03:45 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:03:45 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:04:21 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:04:21 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:21 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:24 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:04:24 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:24 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:26 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:04:26 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:26 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:49 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:04:49 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:49 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:04:58 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 12:04:58 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/details.php 12
ERROR - 2019-05-16 12:04:58 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/details.php 12
ERROR - 2019-05-16 12:05:03 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 12:05:03 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:03 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:05 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 12:05:05 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:05 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:16 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 12:05:16 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:16 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:27 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:05:27 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:05:27 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:05:28 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 12:05:28 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:28 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:05:31 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:05:31 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:05:31 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:05:43 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 12:05:43 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/details.php 12
ERROR - 2019-05-16 12:05:43 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/details.php 12
ERROR - 2019-05-16 12:06:23 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/payment.php 4
ERROR - 2019-05-16 12:06:23 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/payment.php 4
ERROR - 2019-05-16 12:06:23 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/payment.php 4
ERROR - 2019-05-16 12:06:23 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/payment.php 4
ERROR - 2019-05-16 12:06:23 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/payment.php 9
ERROR - 2019-05-16 12:06:23 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/payment.php 12
ERROR - 2019-05-16 12:06:23 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/payment.php 12
ERROR - 2019-05-16 12:06:24 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:06:24 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:06:24 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/index.php 13
ERROR - 2019-05-16 12:10:18 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 8
ERROR - 2019-05-16 12:10:18 --> Severity: Notice --> Undefined variable: front_setting /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:10:18 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/views/form/doc_upload.php 11
ERROR - 2019-05-16 12:13:26 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/payment.php 9
ERROR - 2019-05-16 12:16:46 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 12:21:56 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 12:30:51 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:31:03 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:32:37 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:49:08 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:50:24 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:50:29 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:52:33 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:55:16 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 12:57:00 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 12:58:38 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 13:01:43 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 13:02:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 13:03:49 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 13:18:34 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 13:23:47 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 13:24:51 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 13:26:17 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 13:52:33 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 14:19:19 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 14:22:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 14:30:28 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 14:32:38 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 14:38:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 14:48:21 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:09:48 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:10:58 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:14:00 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 15:26:38 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:33:38 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:33:56 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:35:26 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 15:39:01 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:40:46 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 15:41:21 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:42:47 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 15:55:32 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:55:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:56:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 15:56:46 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 15:57:23 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 16:01:30 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 16:04:03 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 16:12:01 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 16:56:31 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 16:56:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 17:11:38 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:13:16 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:13:26 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:13:36 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:14:58 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:15:08 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:15:08 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:17:22 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 17:17:36 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 17:17:47 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 18:58:41 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 18:59:48 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 19:12:40 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 19:12:55 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 19:15:58 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 19:16:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 19:16:54 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 19:17:51 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 19:18:39 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 20:39:22 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
ERROR - 2019-05-16 20:44:04 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/details.php 9
ERROR - 2019-05-16 21:49:05 --> Severity: Warning --> Illegal string offset 'title' /home/o2ixr95i7zue/public_html/application/views/form/index.php 10
