<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-31 12:17:02 --> Could not find the language line "student_fees1"
ERROR - 2019-01-31 12:17:02 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\stdtransfer\stdtransfer.php 33
ERROR - 2019-01-31 12:17:02 --> Could not find the language line "array_search(needle, haystack)"
ERROR - 2019-01-31 12:17:15 --> Could not find the language line "student_fees1"
ERROR - 2019-01-31 12:17:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\stdtransfer\stdtransfer.php 33
ERROR - 2019-01-31 12:17:15 --> Could not find the language line "array_search(needle, haystack)"
ERROR - 2019-01-31 12:47:33 --> Severity: Notice --> Undefined property: Wing::$wing_model C:\xampp\htdocs\smartschool\application\controllers\Wing.php 32
ERROR - 2019-01-31 12:47:33 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\Wing.php 32
ERROR - 2019-01-31 12:50:25 --> Severity: Notice --> Undefined variable: departmenttype C:\xampp\htdocs\smartschool\application\views\class\wingType.php 67
ERROR - 2019-01-31 12:50:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\class\wingType.php 67
ERROR - 2019-01-31 12:52:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 73
ERROR - 2019-01-31 12:52:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 74
ERROR - 2019-01-31 12:52:20 --> Could not find the language line ""
ERROR - 2019-01-31 12:52:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 78
ERROR - 2019-01-31 12:52:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 83
ERROR - 2019-01-31 12:52:38 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 74
ERROR - 2019-01-31 12:52:38 --> Could not find the language line ""
ERROR - 2019-01-31 12:52:38 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 78
ERROR - 2019-01-31 12:52:38 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smartschool\application\views\class\wingType.php 83
