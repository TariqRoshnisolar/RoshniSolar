<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-23 11:58:46 --> Could not find the language line "student_fee"
ERROR - 2019-03-23 11:58:46 --> Could not find the language line "back"
ERROR - 2019-03-23 12:08:03 --> Could not find the language line "student_fee"
ERROR - 2019-03-23 12:08:03 --> Could not find the language line "back"
ERROR - 2019-03-23 12:09:50 --> Could not find the language line "student_fee"
ERROR - 2019-03-23 12:09:50 --> Could not find the language line "back"
ERROR - 2019-03-23 12:11:59 --> Could not find the language line "student_fee"
ERROR - 2019-03-23 12:11:59 --> Could not find the language line "back"
