<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-29 12:18:55 --> Could not find the language line "student_fees1"
ERROR - 2019-01-29 12:18:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-29 12:19:26 --> Could not find the language line "student_fees1"
ERROR - 2019-01-29 12:19:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-29 12:19:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-29 12:21:55 --> Could not find the language line "student_fees1"
ERROR - 2019-01-29 12:21:59 --> Could not find the language line "student_fees1"
ERROR - 2019-01-29 12:21:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-29 12:22:12 --> Could not find the language line "student_fees1"
ERROR - 2019-01-29 12:22:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\viewassignTeacher.php 38
ERROR - 2019-01-29 12:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-29 12:22:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-29 12:23:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-29 12:23:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\teacher\assignTeacher.php 31
ERROR - 2019-01-29 12:34:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-01-29 13:08:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: role_name C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 32
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 37
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 38
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 44
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 47
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 53
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: message C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 57
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: attach_file C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 60
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: publish_date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 71
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 72
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smartschool\application\libraries\Customlib.php 551
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: created_by C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 74
ERROR - 2019-01-29 13:08:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 79
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: visible_student C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 87
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: visible_parent C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 90
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-29 13:08:48 --> Severity: Notice --> Undefined index: visible_teacher C:\xampp\htdocs\smartschool\application\views\admin\notification\notificationList.php 98
ERROR - 2019-01-29 13:36:26 --> Severity: Notice --> Undefined variable: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 42
ERROR - 2019-01-29 13:41:43 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 64
ERROR - 2019-01-29 13:42:55 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 63
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
ERROR - 2019-01-29 16:12:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectToClass.php 81
