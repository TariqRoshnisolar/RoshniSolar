<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:07:51 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 79
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:23 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: posttitle /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:08:58 --> Severity: Notice --> Undefined index: postname /home/o2ixr95i7zue/public_html/application/views/form/details.php 83
ERROR - 2019-05-25 13:18:20 --> Severity: Compile Error --> Cannot redeclare Form_master_model::getjobstates() /home/o2ixr95i7zue/public_html/application/models/Form_master_model.php 35
ERROR - 2019-05-25 13:24:50 --> Severity: Compile Error --> Cannot redeclare Form_master_model::getreligions() /home/o2ixr95i7zue/public_html/application/models/Form_master_model.php 57
ERROR - 2019-05-25 10:28:44 --> Severity: Notice --> Undefined variable: present_state /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Registration.php 91
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1561
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> sort() expects parameter 1 to be array, null given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1562
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1574
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1579
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1574
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1579
ERROR - 2019-05-25 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1590
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1561
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> sort() expects parameter 1 to be array, null given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1562
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1574
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1579
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1574
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1579
ERROR - 2019-05-25 10:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1590
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1561
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> sort() expects parameter 1 to be array, null given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1562
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1574
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1579
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> array_diff(): Argument #1 is not an array /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1567
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1574
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1579
ERROR - 2019-05-25 10:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/system/database/DB_query_builder.php 1590
ERROR - 2019-05-25 10:40:40 --> Severity: Error --> Call to undefined function data() /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Registration.php 74
