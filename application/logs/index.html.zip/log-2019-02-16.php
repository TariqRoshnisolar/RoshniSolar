<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-16 13:04:03 --> Severity: Notice --> Undefined variable: subjectlist C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectgrouping.php 198
