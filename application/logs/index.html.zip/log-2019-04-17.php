<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-17 10:34:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:34:24 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:34:24 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:34:24 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:34:24 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:41:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:41:03 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:41:03 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:41:03 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:42:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:42:59 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:42:59 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:42:59 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:43:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:43:36 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:43:36 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:43:36 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:51:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:51:28 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:51:28 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:51:28 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:52:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:52:43 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:52:43 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:52:43 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:53:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:53:13 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:53:13 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:53:13 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:55:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:55:15 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:55:15 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:55:15 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:55:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:55:46 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:55:46 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:55:46 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 10:56:34 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 10:56:34 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 10:56:34 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 10:56:34 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:00:48 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:00:48 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:00:48 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:00:48 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:21:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 07:59:47 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 130
ERROR - 2019-04-17 11:29:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:30:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:30:05 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:30:05 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:30:05 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:30:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\application\controllers\admin\Feediscount.php 158
ERROR - 2019-04-17 11:30:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:30:42 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:30:42 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:30:42 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:32:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:32:54 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:32:54 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:32:54 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:34:07 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:34:07 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:34:07 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:34:07 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:34:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:34:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:34:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:34:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:35:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:35:22 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:35:22 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:35:22 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:37:14 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:37:14 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:37:14 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:37:14 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:37:28 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\application\controllers\admin\Feediscount.php 156
ERROR - 2019-04-17 11:37:28 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\application\controllers\admin\Feediscount.php 157
ERROR - 2019-04-17 11:37:28 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\application\controllers\admin\Feediscount.php 156
ERROR - 2019-04-17 11:37:28 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\application\controllers\admin\Feediscount.php 157
ERROR - 2019-04-17 11:38:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:38:19 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:38:19 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:38:19 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:39:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:39:54 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:39:54 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:39:54 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:41:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:41:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:41:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:41:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:41:58 --> Query error: Unknown column 'consession_id' in 'field list' - Invalid query: INSERT INTO `student_consessions` (`consession_id`, `created_at`, `created_by`, `student_id`) VALUES ('17','2019-04-17','0','1'), ('7','2019-04-17','0','1'), ('7','2019-04-17','0','2')
ERROR - 2019-04-17 11:44:27 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:44:27 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:44:27 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:44:27 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:44:44 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 129
ERROR - 2019-04-17 11:44:44 --> Severity: Notice --> Undefined index: concession_id C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 129
ERROR - 2019-04-17 11:44:44 --> Severity: Notice --> Undefined index: created_at C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 129
ERROR - 2019-04-17 11:44:44 --> Severity: Notice --> Undefined index: created_by C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 129
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1561
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> sort() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1562
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> ksort() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1574
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1579
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> ksort() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1574
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1579
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> ksort() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1574
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1579
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1567
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> ksort() expects parameter 1 to be array, null given C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1574
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1579
ERROR - 2019-04-17 11:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 1590
ERROR - 2019-04-17 11:47:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:47:16 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:47:16 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:47:16 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:47:32 --> Severity: Notice --> Undefined variable: student_consession_record C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 130
ERROR - 2019-04-17 11:47:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:47:57 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:47:57 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:47:57 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:48:50 --> Query error: Unknown column 'consession_id' in 'field list' - Invalid query: INSERT INTO `student_consessions` (`consession_id`, `created_at`, `created_by`, `student_id`) VALUES ('17','2019-04-17','0','1'), ('7','2019-04-17','0','1'), ('17','2019-04-17','0','2')
ERROR - 2019-04-17 11:52:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 38
ERROR - 2019-04-17 11:52:06 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 117
ERROR - 2019-04-17 11:52:06 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 119
ERROR - 2019-04-17 11:52:06 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:57:51 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 11:57:51 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 11:57:51 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:57:51 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 11:58:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 11:58:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 11:58:18 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 11:58:18 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 11:58:18 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 11:59:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:00:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:00:13 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:00:13 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:00:13 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:00:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:00:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:00:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:00:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:00:21 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:08:07 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:08:07 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:08:07 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:08:07 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:08:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:11:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:11:09 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:11:09 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:11:09 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:11:31 --> Severity: Notice --> Undefined index: updated_at C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 132
ERROR - 2019-04-17 12:11:31 --> Severity: Notice --> Undefined index: updated_by C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 132
ERROR - 2019-04-17 12:11:31 --> Severity: Notice --> Undefined index: updated_at C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 132
ERROR - 2019-04-17 12:11:31 --> Severity: Notice --> Undefined index: updated_by C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 132
ERROR - 2019-04-17 12:11:31 --> Severity: Notice --> Undefined index: updated_at C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 132
ERROR - 2019-04-17 12:11:31 --> Severity: Notice --> Undefined index: updated_by C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 132
ERROR - 2019-04-17 12:12:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:12:03 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:12:03 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:12:03 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:12:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:12:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:12:53 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:12:53 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:12:53 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:40:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:40:01 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:40:01 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:40:01 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:40:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:40:15 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:40:15 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:40:15 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:40:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:40:23 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:40:23 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:40:23 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:46:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 12:46:31 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 12:46:31 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 12:46:31 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 12:59:25 --> Severity: Error --> Call to undefined function searchStudentDiscountformatData() C:\xampp\htdocs\smartschool\application\models\Feediscount_model.php 178
ERROR - 2019-04-17 09:33:32 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\smartschool\application\helpers\custom_helper.php 3
ERROR - 2019-04-17 13:08:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 13:08:08 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 13:08:08 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 13:08:08 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 13:08:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 13:08:53 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 13:08:53 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 13:08:53 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 13:09:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 13:09:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 13:09:22 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 13:09:22 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 13:09:22 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 13:09:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 13:09:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 13:09:57 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 13:09:57 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 13:09:57 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 13:10:41 --> Query error: Unknown column 'fees_discounts.code' in 'field list' - Invalid query: SELECT `student_fees_discounts`.`id`, `student_fees_discounts`.`student_session_id`, `student_fees_discounts`.`status`, `student_fees_discounts`.`payment_id`, `student_fees_discounts`.`description` as `student_fees_discount_description`, `student_fees_discounts`.`fees_discount_id`, `fees_discounts`.`name`, `fees_discounts`.`code`, `fees_discounts`.`amount`, `fees_discounts`.`description`, `fees_discounts`.`session_id`
FROM `student_fees_discounts`
JOIN `fees_discounts` ON `fees_discounts`.`id` = `student_fees_discounts`.`fees_discount_id`
WHERE `student_fees_discounts`.`student_session_id` = '1'
ORDER BY `student_fees_discounts`.`id`
ERROR - 2019-04-17 13:11:52 --> Query error: Unknown column 'fees_discounts.code' in 'field list' - Invalid query: SELECT `student_fees_discounts`.`id`, `student_fees_discounts`.`student_session_id`, `student_fees_discounts`.`status`, `student_fees_discounts`.`payment_id`, `student_fees_discounts`.`description` as `student_fees_discount_description`, `student_fees_discounts`.`fees_discount_id`, `fees_discounts`.`name`, `fees_discounts`.`code`, `fees_discounts`.`amount`, `fees_discounts`.`description`, `fees_discounts`.`session_id`
FROM `student_fees_discounts`
JOIN `fees_discounts` ON `fees_discounts`.`id` = `student_fees_discounts`.`fees_discount_id`
WHERE `student_fees_discounts`.`student_session_id` = '2'
ORDER BY `student_fees_discounts`.`id`
ERROR - 2019-04-17 13:13:01 --> Severity: Error --> Call to undefined method Feediscount_model::getStudentFeesDiscount() C:\xampp\htdocs\smartschool\application\controllers\Studentfee.php 268
ERROR - 2019-04-17 13:13:55 --> Severity: Notice --> Undefined variable: student_discount_fee C:\xampp\htdocs\smartschool\application\controllers\Studentfee.php 270
ERROR - 2019-04-17 13:13:55 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\controllers\Studentfee.php 271
ERROR - 2019-04-17 13:13:56 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 13:13:56 --> Could not find the language line "back"
ERROR - 2019-04-17 13:13:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 13:14:11 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 13:14:11 --> Could not find the language line "back"
ERROR - 2019-04-17 13:14:11 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 13:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 14:49:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:49:14 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:49:14 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 14:49:14 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 14:49:14 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 14:49:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:49:38 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:49:38 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 14:49:38 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 14:49:38 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 14:50:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:50:49 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:50:49 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 14:50:49 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 14:50:49 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 14:50:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:51:02 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:51:02 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 14:51:02 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 14:51:02 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 14:51:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:51:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 14:51:18 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 14:51:18 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 14:51:18 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 15:06:27 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 15:06:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 15:06:30 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 15:06:30 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 15:06:30 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 15:07:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 15:07:06 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 15:07:06 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 15:07:06 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 15:10:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'and assign_fee_amount_group.feetype=1 and ins.is_deleted=0 order by ins.type' at line 1 - Invalid query: select ins.*, assign_fee_amount_group.totalamt from feeinstallment ins left join assign_fee_amount_group on (assign_fee_amount_group.installment=ins.id and assign_fee_amount_group.is_deleted=0) where ins.id not in (select stufee.installment from stu_fee_detail stufee where stufee.student='7' and stufee.yearsession='14' and stufee.is_deleted=0) and assign_fee_amount_group.feegroup= and assign_fee_amount_group.feetype=1 and ins.is_deleted=0 order by ins.type
ERROR - 2019-04-17 15:10:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'and assign_fee_amount_group.feetype=1 and ins.is_deleted=0 order by ins.type' at line 1 - Invalid query: select ins.*, assign_fee_amount_group.totalamt from feeinstallment ins left join assign_fee_amount_group on (assign_fee_amount_group.installment=ins.id and assign_fee_amount_group.is_deleted=0) where ins.id not in (select stufee.installment from stu_fee_detail stufee where stufee.student='7' and stufee.yearsession='14' and stufee.is_deleted=0) and assign_fee_amount_group.feegroup= and assign_fee_amount_group.feetype=1 and ins.is_deleted=0 order by ins.type
ERROR - 2019-04-17 15:11:13 --> Query error: Unknown column 'fees_discounts.amount' in 'field list' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `fees_discounts`.`amount` as `concession`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule`
FROM `assign_fee_amount_group` as `group`
LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id`
LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head`
LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype`
LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule`
WHERE `group`.`is_deleted` =0
AND `amounts`.`is_deleted` =0
AND `head`.`is_deleted` =0
AND `head`.`is_hostel` =0
AND `feetype`.`is_deleted` =0
AND `pay_schedule`.`is_deleted` =0
AND `group`.`feetype` = 1
AND `group`.`feegroup` = '2'
AND `group`.`installment` = '2'
AND `head`.`status` = 1
ERROR - 2019-04-17 16:09:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 16:11:24 --> Query error: Not unique table/alias: 'head' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule`
FROM `assign_fee_amount_group` as `group`
LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id`
LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head`
LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head`
LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype`
LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule`
WHERE `group`.`is_deleted` =0
AND `amounts`.`is_deleted` =0
AND `head`.`is_deleted` =0
AND `head`.`is_hostel` =0
AND `feetype`.`is_deleted` =0
AND `pay_schedule`.`is_deleted` =0
AND `group`.`feetype` = 1
AND `group`.`feegroup` = '1'
AND `group`.`installment` = '2'
AND `head`.`status` = 1
ERROR - 2019-04-17 12:48:46 --> Severity: Parsing Error --> syntax error, unexpected 'feetype' (T_STRING) C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 145
ERROR - 2019-04-17 12:49:27 --> Severity: Parsing Error --> syntax error, unexpected 'feetype' (T_STRING) C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 145
ERROR - 2019-04-17 12:49:28 --> Severity: Parsing Error --> syntax error, unexpected 'feetype' (T_STRING) C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 145
ERROR - 2019-04-17 12:50:08 --> Severity: Parsing Error --> syntax error, unexpected 'feegroup' (T_STRING) C:\xampp\htdocs\smartschool\application\models\Assignamountgroup_model.php 147
ERROR - 2019-04-17 16:20:51 --> Query error: Unknown column '$feetype' in 'where clause' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule` FROM `assign_fee_amount_group` as `group` LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id` LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head` LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype` LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule` WHERE `group`.`is_deleted` =0 AND `amounts`.`is_deleted` =0 AND `head`.`is_deleted` =0 AND `head`.`is_hostel` =0 AND `feetype`.`is_deleted` =0 AND `pay_schedule`.`is_deleted` =0 AND `group`.`feetype` = $feetype AND `group`.`feegroup` = $feegroup AND `group`.`installment` = $installment_id AND `head`.`status` = 1
ERROR - 2019-04-17 16:21:15 --> Query error: Unknown column '$feegroup' in 'where clause' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule` FROM `assign_fee_amount_group` as `group` LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id` LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head` LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype` LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule` WHERE `group`.`is_deleted` =0 AND `amounts`.`is_deleted` =0 AND `head`.`is_deleted` =0 AND `head`.`is_hostel` =0 AND `feetype`.`is_deleted` =0 AND `pay_schedule`.`is_deleted` =0 AND `group`.`feetype` = "$feetype" AND `group`.`feegroup` = $feegroup AND `group`.`installment` = $installment_id AND `head`.`status` = 1
ERROR - 2019-04-17 16:21:21 --> Query error: Unknown column '$installment_id' in 'where clause' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule` FROM `assign_fee_amount_group` as `group` LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id` LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head` LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype` LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule` WHERE `group`.`is_deleted` =0 AND `amounts`.`is_deleted` =0 AND `head`.`is_deleted` =0 AND `head`.`is_hostel` =0 AND `feetype`.`is_deleted` =0 AND `pay_schedule`.`is_deleted` =0 AND `group`.`feetype` = "$feetype" AND `group`.`feegroup` = "$feegroup" AND `group`.`installment` = $installment_id AND `head`.`status` = 1
ERROR - 2019-04-17 16:22:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '" AND `head`.`status` = 1' at line 1 - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule` FROM `assign_fee_amount_group` as `group` LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id` LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head` LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype` LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule` WHERE `group`.`is_deleted` =0 AND `amounts`.`is_deleted` =0 AND `head`.`is_deleted` =0 AND `head`.`is_hostel` =0 AND `feetype`.`is_deleted` =0 AND `pay_schedule`.`is_deleted` =0 AND `group`.`feetype` = "$feetype" AND `group`.`feegroup` = "$feegroup" AND `group`.`installment` = $installment_id" AND `head`.`status` = 1
ERROR - 2019-04-17 16:23:23 --> Query error: Unknown column 'heads.payschedule' in 'on clause' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule` FROM `assign_fee_amount_group` as `group` LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id` LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head` LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype` LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`heads`.`payschedule` WHERE `group`.`is_deleted` =0 AND `amounts`.`is_deleted` =0 AND `head`.`is_deleted` =0 AND `head`.`is_hostel` =0 AND `feetype`.`is_deleted` =0 AND `pay_schedule`.`is_deleted` =0 AND `group`.`feetype` = '1' AND `group`.`feegroup` = '2' AND `group`.`installment` = '3' AND `head`.`status` = 1
ERROR - 2019-04-17 16:27:08 --> Query error: Unknown column 'fee_head.id' in 'on clause' - Invalid query: SELECT `amounts`.`fee_head` as `feehead`, `amounts`.`amount`, fees_discount.amount as concession , `head`.`name` as `feeheadname`, `feetype`.`type` as `feetypename`, `pay_schedule`.`name` as `payschedule` FROM `assign_fee_amount_group` as `group` LEFT JOIN `fee_amount_group` as `amounts` ON `amounts`.`assign_id`=`group`.`id` LEFT JOIN `fee_head` as `head` ON `head`.`id`=`amounts`.`fee_head` LEFT JOIN (select fees_discounts.feehead_id, fees_discounts.amount from fees_discounts inner join student_consessions on (student_consessions.concession_id=fees_discounts.id and student_consessions.is_deleted=0) where fees_discounts.is_deleted=0 and student_consessions.student_id=2) fees_discount ON (fee_head.id=fees_discount.feehead_id) LEFT JOIN `feetype` ON `feetype`.`id`=`group`.`feetype` LEFT JOIN `pay_schedule` ON `pay_schedule`.`id`=`head`.`payschedule` WHERE `group`.`is_deleted` =0 AND `amounts`.`is_deleted` =0 AND `head`.`is_deleted` =0 AND `head`.`is_hostel` =0 AND `feetype`.`is_deleted` =0 AND `pay_schedule`.`is_deleted` =0 AND `group`.`feetype` = '1' AND `group`.`feegroup` = '2' AND `group`.`installment` = '3' AND `head`.`status` = 1
ERROR - 2019-04-17 16:28:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 16:28:50 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 16:28:50 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 16:28:50 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 16:29:37 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:29:37 --> Could not find the language line "back"
ERROR - 2019-04-17 16:29:37 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:29:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:33:18 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:33:18 --> Could not find the language line "back"
ERROR - 2019-04-17 16:33:18 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:33:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:33:40 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:33:40 --> Could not find the language line "back"
ERROR - 2019-04-17 16:33:40 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:34:45 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:34:45 --> Could not find the language line "back"
ERROR - 2019-04-17 16:34:45 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:34:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:35:10 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:35:10 --> Could not find the language line "back"
ERROR - 2019-04-17 16:35:10 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:35:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:38:14 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 16:38:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 16:38:20 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 120
ERROR - 2019-04-17 16:38:20 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 122
ERROR - 2019-04-17 16:38:20 --> Severity: Notice --> Undefined variable: feediscountList C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
ERROR - 2019-04-17 16:38:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 41
ERROR - 2019-04-17 16:38:40 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:38:40 --> Could not find the language line "back"
ERROR - 2019-04-17 16:38:40 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:39:59 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting ',' or ';' C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1038
ERROR - 2019-04-17 16:40:18 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:40:18 --> Could not find the language line "back"
ERROR - 2019-04-17 16:40:18 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:40:29 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:40:29 --> Could not find the language line "back"
ERROR - 2019-04-17 16:40:29 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:44:41 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:44:41 --> Could not find the language line "back"
ERROR - 2019-04-17 16:44:41 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:48:03 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:48:03 --> Could not find the language line "back"
ERROR - 2019-04-17 16:48:03 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:48:42 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:48:42 --> Could not find the language line "back"
ERROR - 2019-04-17 16:48:42 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:48:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:49:39 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:49:39 --> Could not find the language line "back"
ERROR - 2019-04-17 16:49:39 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:49:59 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:49:59 --> Could not find the language line "back"
ERROR - 2019-04-17 16:49:59 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:53:09 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:53:09 --> Could not find the language line "back"
ERROR - 2019-04-17 16:53:09 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:55:10 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:55:10 --> Could not find the language line "back"
ERROR - 2019-04-17 16:55:10 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:57:03 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:57:03 --> Could not find the language line "back"
ERROR - 2019-04-17 16:57:03 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:57:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:59:44 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:59:44 --> Could not find the language line "back"
ERROR - 2019-04-17 16:59:44 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:59:58 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 16:59:58 --> Could not find the language line "back"
ERROR - 2019-04-17 16:59:58 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 16:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 17:00:13 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 17:00:13 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:00:13 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:00:13 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:00:13 --> Could not find the language line "back"
ERROR - 2019-04-17 17:00:13 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-17 17:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-17 17:00:28 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 17:00:28 --> Could not find the language line "back"
ERROR - 2019-04-17 17:00:28 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 17:00:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-17 17:01:23 --> Could not find the language line "student_fee"
ERROR - 2019-04-17 17:01:23 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:01:23 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:01:23 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-17 17:01:23 --> Could not find the language line "back"
ERROR - 2019-04-17 17:01:23 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-17 17:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
