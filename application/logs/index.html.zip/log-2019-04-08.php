<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 09:58:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-08 10:00:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-04-08 10:25:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-04-08 10:35:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-04-08 10:35:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\create.php 61
ERROR - 2019-04-08 10:36:10 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\create.php 61
ERROR - 2019-04-08 10:41:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\create.php 61
ERROR - 2019-04-08 10:42:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\create.php 61
ERROR - 2019-04-08 10:43:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-04-08 10:51:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-04-08 10:52:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-04-08 10:52:15 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentCreate.php 65
ERROR - 2019-04-08 10:52:19 --> Could not find the language line "student1"
ERROR - 2019-04-08 10:52:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-08 10:52:23 --> Could not find the language line "student1"
ERROR - 2019-04-08 10:52:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-08 10:52:29 --> Could not find the language line "student1"
ERROR - 2019-04-08 10:52:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentEdit.php 60
ERROR - 2019-04-08 10:52:51 --> Could not find the language line "student1"
ERROR - 2019-04-08 10:52:51 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-04-08 10:53:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-08 10:53:58 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 10:53:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 10:57:01 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 10:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:49:55 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:49:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:51:23 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:51:45 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:51:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:59:46 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 11:59:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 12:01:25 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 12:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 12:03:17 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 12:03:17 --> Could not find the language line "back"
ERROR - 2019-04-08 12:06:41 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 12:06:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 12:34:25 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 12:34:25 --> Could not find the language line "back"
ERROR - 2019-04-08 12:42:19 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 12:42:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:01:05 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:01:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:02:01 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:02:24 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:07:22 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:07:50 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 13:07:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:01:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 271
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 271
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 271
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 271
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 271
ERROR - 2019-04-08 15:01:24 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 271
ERROR - 2019-04-08 15:02:47 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:02:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:04:47 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:04:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:04:59 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:05:06 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:06:24 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:07:25 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:07:42 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:07:50 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:07:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:08:03 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 269
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 270
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 272
ERROR - 2019-04-08 15:13:47 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:13:47 --> Severity: Notice --> Undefined variable: feeheadlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 260
ERROR - 2019-04-08 15:13:47 --> Severity: Notice --> Undefined variable: feeheadlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 262
ERROR - 2019-04-08 15:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 262
ERROR - 2019-04-08 15:14:10 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:14:22 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:14:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:16:38 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:17:58 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:17:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:18:05 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:18:12 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:18:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:20:15 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:20:21 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:20:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:20:27 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:35:16 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 15:36:53 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 189
ERROR - 2019-04-08 15:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 189
ERROR - 2019-04-08 15:41:56 --> Severity: Notice --> Undefined variable: feetype C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 15:41:56 --> Severity: Notice --> Undefined variable: feetype C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 15:41:56 --> Severity: Notice --> Undefined variable: feetype C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 15:41:56 --> Severity: Notice --> Undefined variable: feetype C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 15:41:56 --> Severity: Notice --> Undefined variable: feetype C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 15:41:56 --> Severity: Notice --> Undefined variable: feetype C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Notice --> Undefined index: fee_groups C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 15:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 144
ERROR - 2019-04-08 16:03:43 --> Severity: Error --> Call to undefined function check_if_head_not_used_anywhere_else() C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 59
ERROR - 2019-04-08 16:04:03 --> Severity: Error --> Call to undefined function check_if_head_not_used_anywhere_else() C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 73
ERROR - 2019-04-08 16:07:52 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\smartschool\application\views\admin\studentfee\hostelfeetostudent.php 85
ERROR - 2019-04-08 16:18:25 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 16:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 16:18:45 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 16:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-08 17:08:41 --> Severity: Notice --> Undefined index: is_hotel C:\xampp\htdocs\smartschool\application\views\admin\studentfee\assignamountgroup.php 161
ERROR - 2019-04-08 17:08:41 --> Severity: Notice --> Undefined index: is_hotel C:\xampp\htdocs\smartschool\application\views\admin\studentfee\assignamountgroup.php 161
ERROR - 2019-04-08 17:08:41 --> Severity: Notice --> Undefined index: is_hotel C:\xampp\htdocs\smartschool\application\views\admin\studentfee\assignamountgroup.php 161
ERROR - 2019-04-08 17:13:52 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:13:52 --> Could not find the language line "back"
ERROR - 2019-04-08 17:18:14 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:18:14 --> Severity: Notice --> Undefined index: hostel_room_id C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 298
ERROR - 2019-04-08 17:18:14 --> Severity: Notice --> Undefined index: hostel_room_id C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 298
ERROR - 2019-04-08 17:18:14 --> Severity: Notice --> Undefined index: hostel_room_id C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 298
ERROR - 2019-04-08 17:18:14 --> Could not find the language line "back"
ERROR - 2019-04-08 17:18:50 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:18:50 --> Could not find the language line "back"
ERROR - 2019-04-08 17:20:02 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:20:02 --> Could not find the language line "back"
ERROR - 2019-04-08 17:20:02 --> Severity: Notice --> Undefined index: hostel_room_id C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 355
ERROR - 2019-04-08 17:22:25 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:22:25 --> Could not find the language line "back"
ERROR - 2019-04-08 17:22:25 --> Severity: Notice --> Undefined index: hostel_room_id C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 355
ERROR - 2019-04-08 17:23:12 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:23:12 --> Could not find the language line "back"
ERROR - 2019-04-08 17:23:28 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:23:28 --> Could not find the language line "back"
ERROR - 2019-04-08 17:23:40 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:23:40 --> Could not find the language line "back"
ERROR - 2019-04-08 17:24:44 --> Could not find the language line "student_fee"
ERROR - 2019-04-08 17:24:44 --> Could not find the language line "back"
