<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-18 10:51:06 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:51:47 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:52:04 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:52:14 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:52:18 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:52:29 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:53:48 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:54:10 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:54:13 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:54:40 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:54:57 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:54:59 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 10:56:24 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 11:06:37 --> Could not find the language line "by_date1"
ERROR - 2019-02-18 07:41:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\smartschool\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-02-18 07:41:42 --> Unable to connect to the database
ERROR - 2019-02-18 07:42:15 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\smartschool\application\models\Visitors_model.php 3
ERROR - 2019-02-18 17:56:00 --> Could not find the language line "detail"
ERROR - 2019-02-18 17:57:42 --> Could not find the language line "setting1"
