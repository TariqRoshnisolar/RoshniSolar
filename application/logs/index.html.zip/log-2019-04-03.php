<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-03 10:04:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostel\createhostel.php 56
ERROR - 2019-04-03 10:04:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\hostelroom\studenthosteldetails.php 105
ERROR - 2019-04-03 10:06:32 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:06:32 --> Could not find the language line "back"
ERROR - 2019-04-03 10:09:48 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:09:48 --> Could not find the language line "back"
ERROR - 2019-04-03 10:12:31 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:12:31 --> Could not find the language line "back"
ERROR - 2019-04-03 10:14:03 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:14:03 --> Could not find the language line "back"
ERROR - 2019-04-03 10:14:04 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:14:04 --> Could not find the language line "back"
ERROR - 2019-04-03 10:14:19 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:14:19 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:19 --> Could not find the language line "back"
ERROR - 2019-04-03 10:14:19 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-03 10:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-03 10:14:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:14:46 --> Could not find the language line "back"
ERROR - 2019-04-03 10:14:53 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:14:53 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:53 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:53 --> Severity: Notice --> Undefined variable: studentlistbysection C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 119
ERROR - 2019-04-03 10:14:53 --> Could not find the language line "back"
ERROR - 2019-04-03 10:14:53 --> Severity: Notice --> Undefined variable: categorylist C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-03 10:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\feesubmitsuccess.php 204
ERROR - 2019-04-03 10:38:00 --> Could not find the language line "filter_by_class"
ERROR - 2019-04-03 10:38:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\studentfee\reportByClass.php 28
ERROR - 2019-04-03 10:38:09 --> Could not find the language line "filter_by_class"
ERROR - 2019-04-03 10:38:09 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\studentfee\reportByClass.php 28
ERROR - 2019-04-03 10:38:09 --> Could not find the language line "dob"
ERROR - 2019-04-03 10:38:09 --> Could not find the language line "balanace_description"
ERROR - 2019-04-03 10:38:09 --> Could not find the language line "dob"
ERROR - 2019-04-03 10:38:09 --> Could not find the language line "balanace_description"
ERROR - 2019-04-03 10:39:19 --> Could not find the language line "example"
ERROR - 2019-04-03 10:40:49 --> Could not find the language line "student1"
ERROR - 2019-04-03 10:40:49 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\studentfee\reportByName.php 34
ERROR - 2019-04-03 10:40:57 --> Could not find the language line "student1"
ERROR - 2019-04-03 10:40:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\studentfee\reportByName.php 34
ERROR - 2019-04-03 10:41:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\studentfee\studentSearchFee.php 75
ERROR - 2019-04-03 10:51:24 --> Could not find the language line "student_fee"
ERROR - 2019-04-03 10:51:24 --> Could not find the language line "back"
ERROR - 2019-04-03 12:43:31 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 72
ERROR - 2019-04-03 12:43:31 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 72
ERROR - 2019-04-03 12:43:31 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 72
ERROR - 2019-04-03 12:43:31 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 72
ERROR - 2019-04-03 12:43:31 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 72
ERROR - 2019-04-03 12:46:13 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 73
ERROR - 2019-04-03 12:46:13 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 73
ERROR - 2019-04-03 12:46:13 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 73
ERROR - 2019-04-03 12:46:13 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 73
ERROR - 2019-04-03 12:46:13 --> Severity: Notice --> Undefined index: installment C:\xampp\htdocs\smartschool\application\views\studentfee\studentFeeReport.php 73
