<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-29 12:46:13 --> Severity: Notice --> Undefined property: Notice::$book_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Notice.php 98
ERROR - 2019-04-29 12:46:13 --> Severity: Error --> Call to a member function listbook() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Notice.php 98
ERROR - 2019-04-29 12:46:14 --> Severity: Notice --> Undefined property: Notice::$book_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Notice.php 98
ERROR - 2019-04-29 12:46:14 --> Severity: Error --> Call to a member function listbook() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Notice.php 98
ERROR - 2019-04-29 12:46:15 --> Severity: Notice --> Undefined property: Notice::$book_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Notice.php 98
ERROR - 2019-04-29 12:46:15 --> Severity: Error --> Call to a member function listbook() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Notice.php 98
ERROR - 2019-04-29 10:09:47 --> Severity: Notice --> Undefined variable: banner_notice_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 128
ERROR - 2019-04-29 10:09:51 --> Severity: Notice --> Undefined variable: banner_notice_value C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 128
ERROR - 2019-04-29 11:56:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 95
ERROR - 2019-04-29 11:56:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 95
ERROR - 2019-04-29 11:56:52 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 98
ERROR - 2019-04-29 11:56:52 --> Severity: Notice --> Undefined index: from_date C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 98
ERROR - 2019-04-29 11:56:56 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 98
ERROR - 2019-04-29 11:56:56 --> Severity: Notice --> Undefined index: from_date C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 98
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:15 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 11:59:18 --> Severity: Notice --> Undefined index: update_type C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 97
ERROR - 2019-04-29 15:52:22 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\uvsil\application\views\admin\front\updates\edit.php 199
ERROR - 2019-04-29 15:52:43 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\uvsil\application\views\admin\front\updates\edit.php 200
ERROR - 2019-04-29 15:52:45 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\uvsil\application\views\admin\front\updates\edit.php 200
ERROR - 2019-04-29 15:52:58 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\uvsil\application\views\admin\front\updates\edit.php 201
ERROR - 2019-04-29 15:58:03 --> Severity: Notice --> Undefined property: Branches::$caste_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 37
ERROR - 2019-04-29 15:58:03 --> Severity: Error --> Call to a member function getalldata() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 37
ERROR - 2019-04-29 16:01:36 --> Severity: Notice --> Undefined property: Branches::$caste_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 37
ERROR - 2019-04-29 16:01:36 --> Severity: Error --> Call to a member function getalldata() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 37
ERROR - 2019-04-29 16:01:57 --> Severity: Notice --> Undefined variable: vehroute_result C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 39
ERROR - 2019-04-29 16:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:02:09 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:02:44 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:02:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:05:22 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:05:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:07:34 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:07:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:08:09 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:08:37 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:08:46 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 16:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 81
ERROR - 2019-04-29 12:43:49 --> Severity: error --> Exception: C:\xampp\htdocs\uvsil\application\models/Branch_model.php exists, but doesn't declare class Branch_model C:\xampp\htdocs\uvsil\system\core\Loader.php 336
ERROR - 2019-04-29 16:14:18 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 86
ERROR - 2019-04-29 16:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 86
ERROR - 2019-04-29 16:14:32 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:17:29 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:17:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:18:40 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:18:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:21:42 --> Severity: Notice --> Undefined variable: vehroutelist C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 85
ERROR - 2019-04-29 16:24:37 --> Severity: Notice --> Undefined variable: vehroute C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 104
ERROR - 2019-04-29 16:24:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 104
ERROR - 2019-04-29 16:24:37 --> Severity: Notice --> Undefined variable: vehroute C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 111
ERROR - 2019-04-29 16:24:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\admin\front\branch\index.php 111
ERROR - 2019-04-29 16:38:59 --> Severity: Warning --> Missing argument 1 for Branches::edit() C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 46
ERROR - 2019-04-29 16:38:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 53
ERROR - 2019-04-29 16:38:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 55
ERROR - 2019-04-29 16:38:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 71
ERROR - 2019-04-29 16:39:58 --> Severity: Warning --> Missing argument 1 for Branches::edit() C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 46
ERROR - 2019-04-29 16:39:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 53
ERROR - 2019-04-29 16:39:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 55
ERROR - 2019-04-29 16:39:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 71
ERROR - 2019-04-29 16:40:51 --> Severity: Warning --> Missing argument 1 for Branches::edit() C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 46
ERROR - 2019-04-29 16:40:51 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 53
ERROR - 2019-04-29 16:40:51 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 55
ERROR - 2019-04-29 16:42:00 --> Severity: Warning --> Missing argument 1 for Branches::edit() C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 46
ERROR - 2019-04-29 16:42:00 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 53
ERROR - 2019-04-29 16:42:00 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\uvsil\application\controllers\admin\front\Branches.php 55
ERROR - 2019-04-29 14:07:32 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 237
ERROR - 2019-04-29 14:07:36 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 237
ERROR - 2019-04-29 14:08:01 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 239
ERROR - 2019-04-29 14:08:04 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 239
ERROR - 2019-04-29 14:09:34 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 239
ERROR - 2019-04-29 14:09:37 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\uvsil\application\views\themes\default\layout.php 239
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Undefined variable: partner C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
ERROR - 2019-04-29 14:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 15
