<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-24 14:23:14 --> Severity: Notice --> Undefined property: Studentidcardtemplates::$Student_id_card_template_model C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 23
ERROR - 2019-04-24 14:23:14 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 23
ERROR - 2019-04-24 14:27:04 --> Severity: Notice --> Undefined variable: template C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentcertificatetemplates.php 31
ERROR - 2019-04-24 14:46:56 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentcertificatetemplates.php 239
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Undefined variable: editidcard C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 39
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 31
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 42
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 46
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 51
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 56
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 61
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 66
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 71
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 76
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 81
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 88
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 95
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 102
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 109
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 116
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 123
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 130
ERROR - 2019-04-24 15:19:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 137
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Undefined variable: editidcard C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 39
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 31
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 42
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 46
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 51
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 56
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 61
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 66
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 71
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 76
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 81
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 88
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 95
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 102
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 109
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 116
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 123
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 130
ERROR - 2019-04-24 15:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 137
ERROR - 2019-04-24 15:40:57 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 31
ERROR - 2019-04-24 15:41:41 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardtemplatesedit.php 31
ERROR - 2019-04-24 16:12:03 --> Severity: Notice --> Undefined property: Studentidcardtemplates::$Student_id_card_template_model C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 100
ERROR - 2019-04-24 16:12:03 --> Severity: Error --> Call to a member function edit() on null C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 100
ERROR - 2019-04-24 16:12:19 --> Severity: Warning --> Missing argument 1 for studentidcard::edit() C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 178
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 184
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 185
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 31
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 31
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 42
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 42
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 46
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 46
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 51
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 51
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 56
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 56
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 61
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 61
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 66
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 66
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 71
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 71
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 76
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 76
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 81
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 81
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 88
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 88
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 95
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 95
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 102
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 102
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 109
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 109
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 116
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 116
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 123
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 123
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 130
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 130
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 137
ERROR - 2019-04-24 16:12:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\views\admin\certificate\studentidcardedit.php 137
ERROR - 2019-04-24 16:28:32 --> Severity: Notice --> Undefined index: sign_img C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcardtemplates.php 69
