<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-26 10:02:11 --> Could not find the language line "student_fee"
ERROR - 2019-04-26 10:02:11 --> Could not find the language line "back"
ERROR - 2019-04-26 10:02:11 --> Severity: Notice --> Undefined variable: student_due_fee C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-26 10:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\studentfee\studentAddfee.php 1172
ERROR - 2019-04-26 09:04:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:05:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:05:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:05:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Teacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:07:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:08:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:08:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:09:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:10:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:10:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:10:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:11:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:11:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:13:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:14:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:15:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:15:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:15:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:15:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:15:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:15:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:17:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:17:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:18:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:19:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:19:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:19:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:19:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:19:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:19:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:21:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:22:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 345
ERROR - 2019-04-26 09:24:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 345
ERROR - 2019-04-26 09:24:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 345
ERROR - 2019-04-26 09:24:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 345
ERROR - 2019-04-26 09:24:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 345
ERROR - 2019-04-26 09:24:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:24:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:27:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:28:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Complaint_Model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:28:34 --> Severity: Notice --> Undefined property: Welcome::$cms_program_model C:\xampp\htdocs\uvsil\application\controllers\Welcome.php 18
ERROR - 2019-04-26 09:28:34 --> Severity: Error --> Call to a member function getNoticeByDate() on null C:\xampp\htdocs\uvsil\application\controllers\Welcome.php 18
ERROR - 2019-04-26 09:28:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Session_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:29:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Class_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:29:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Classsection_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:29:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Langpharses_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:29:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Paymentsetting_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:30:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Income_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:30:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Itemstore_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:30:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Itemstock_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 09:31:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:02:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Staff_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:02:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Staff_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:02:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:03:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Leaverequest_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:03:10 --> Severity: Notice --> Undefined property: Admin::$studentfeemaster_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 169
ERROR - 2019-04-26 13:03:10 --> Severity: Error --> Call to a member function getDepositAmountBetweenDate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 169
ERROR - 2019-04-26 13:03:40 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 174
ERROR - 2019-04-26 13:03:40 --> Severity: Notice --> Undefined property: Admin::$expense_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 175
ERROR - 2019-04-26 13:03:40 --> Severity: Error --> Call to a member function getTotalExpenseBwdate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 175
ERROR - 2019-04-26 13:03:56 --> Severity: Notice --> Undefined property: Admin::$expense_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 175
ERROR - 2019-04-26 13:03:56 --> Severity: Error --> Call to a member function getTotalExpenseBwdate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 175
ERROR - 2019-04-26 13:04:03 --> Severity: Notice --> Undefined property: Admin::$studentsession_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 182
ERROR - 2019-04-26 13:04:03 --> Severity: Error --> Call to a member function getTotalStudentBySession() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 182
ERROR - 2019-04-26 13:04:09 --> Severity: Notice --> Undefined property: Admin::$stuattendence_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 186
ERROR - 2019-04-26 13:04:09 --> Severity: Error --> Call to a member function studentpresentattendance() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 186
ERROR - 2019-04-26 13:04:19 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 189
ERROR - 2019-04-26 13:04:19 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 192
ERROR - 2019-04-26 13:04:19 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 196
ERROR - 2019-04-26 13:04:19 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 199
ERROR - 2019-04-26 13:04:19 --> Severity: Notice --> Undefined property: Admin::$staff_model C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:04:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 13:04:19 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:04:31 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 189
ERROR - 2019-04-26 13:04:31 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 192
ERROR - 2019-04-26 13:04:31 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 196
ERROR - 2019-04-26 13:04:31 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 199
ERROR - 2019-04-26 13:04:31 --> Severity: Notice --> Undefined property: Admin::$staff_model C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:04:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 13:04:31 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:04:45 --> Severity: Notice --> Undefined property: Admin::$staff_model C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:04:45 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:05:16 --> Severity: Notice --> Undefined index: role_id C:\xampp\htdocs\uvsil\application\models\Role_model.php 21
ERROR - 2019-04-26 13:05:16 --> Severity: Notice --> Undefined property: Admin::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 193
ERROR - 2019-04-26 13:05:16 --> Severity: Error --> Call to a member function staffpresentattendancebyrole() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 193
ERROR - 2019-04-26 13:05:49 --> Severity: Notice --> Undefined property: Admin::$staff_model C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:05:49 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\libraries\Customlib.php 722
ERROR - 2019-04-26 13:06:02 --> Severity: Notice --> Undefined property: Admin::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 193
ERROR - 2019-04-26 13:06:02 --> Severity: Error --> Call to a member function staffpresentattendancebyrole() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 193
ERROR - 2019-04-26 13:06:20 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 195
ERROR - 2019-04-26 13:06:20 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 198
ERROR - 2019-04-26 13:06:20 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 202
ERROR - 2019-04-26 13:06:20 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 205
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 195
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 198
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 202
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 205
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 195
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 198
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 202
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 205
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 195
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: present_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 198
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 202
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 205
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 224
ERROR - 2019-04-26 13:06:21 --> Severity: Notice --> Undefined property: Admin::$expense_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 242
ERROR - 2019-04-26 13:06:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 13:06:21 --> Severity: Error --> Call to a member function getTotalExpenseBwdate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 242
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 196
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 199
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 196
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 199
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 196
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 199
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 196
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: absent_count C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 199
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 218
ERROR - 2019-04-26 13:06:31 --> Severity: Notice --> Undefined property: Admin::$expense_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 236
ERROR - 2019-04-26 13:06:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 13:06:31 --> Severity: Error --> Call to a member function getTotalExpenseBwdate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 236
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 212
ERROR - 2019-04-26 13:06:36 --> Severity: Notice --> Undefined property: Admin::$expense_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 230
ERROR - 2019-04-26 13:06:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 13:06:36 --> Severity: Error --> Call to a member function getTotalExpenseBwdate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 230
ERROR - 2019-04-26 13:06:51 --> Severity: Notice --> Undefined property: Admin::$expense_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 217
ERROR - 2019-04-26 13:06:51 --> Severity: Error --> Call to a member function getTotalExpenseBwdate() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 217
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined variable: getDepositeAmount C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 241
ERROR - 2019-04-26 13:07:00 --> Severity: Notice --> Undefined property: Admin::$studentfee_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 264
ERROR - 2019-04-26 13:07:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 13:07:00 --> Severity: Error --> Call to a member function getTodayStudentFees() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 264
ERROR - 2019-04-26 13:07:13 --> Severity: Notice --> Undefined property: Admin::$studentfee_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 257
ERROR - 2019-04-26 13:07:13 --> Severity: Error --> Call to a member function getTodayStudentFees() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 257
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined variable: student_fee_history C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 257
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1798
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1799
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:24 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1798
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1799
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: present_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1822
ERROR - 2019-04-26 13:07:44 --> Severity: Notice --> Undefined index: absent_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1823
ERROR - 2019-04-26 13:09:37 --> Severity: Notice --> Undefined variable: count_roles C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 173
ERROR - 2019-04-26 13:09:37 --> Severity: Notice --> Undefined variable: month_collection C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1768
ERROR - 2019-04-26 13:09:37 --> Severity: Notice --> Undefined variable: month_expense C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1782
ERROR - 2019-04-26 13:09:37 --> Severity: Notice --> Undefined variable: total_students C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1797
ERROR - 2019-04-26 13:09:37 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1798
ERROR - 2019-04-26 13:09:37 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1799
ERROR - 2019-04-26 13:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1813
ERROR - 2019-04-26 13:10:03 --> Severity: Notice --> Undefined variable: month_collection C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1768
ERROR - 2019-04-26 13:10:03 --> Severity: Notice --> Undefined variable: month_expense C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1782
ERROR - 2019-04-26 13:10:03 --> Severity: Notice --> Undefined variable: total_students C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1797
ERROR - 2019-04-26 13:10:03 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1798
ERROR - 2019-04-26 13:10:03 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1799
ERROR - 2019-04-26 13:10:03 --> Severity: Notice --> Undefined variable: roles C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1813
ERROR - 2019-04-26 13:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1813
ERROR - 2019-04-26 13:11:06 --> Severity: Notice --> Undefined variable: month_collection C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1768
ERROR - 2019-04-26 13:11:06 --> Severity: Notice --> Undefined variable: month_expense C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1782
ERROR - 2019-04-26 13:11:06 --> Severity: Notice --> Undefined variable: total_students C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1797
ERROR - 2019-04-26 13:11:06 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1798
ERROR - 2019-04-26 13:11:06 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1799
ERROR - 2019-04-26 13:11:06 --> Severity: Notice --> Undefined variable: roles C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1813
ERROR - 2019-04-26 13:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1813
ERROR - 2019-04-26 13:12:21 --> Severity: Notice --> Undefined variable: month_collection C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1750
ERROR - 2019-04-26 13:12:21 --> Severity: Notice --> Undefined variable: month_expense C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1764
ERROR - 2019-04-26 13:12:21 --> Severity: Notice --> Undefined variable: total_students C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1779
ERROR - 2019-04-26 13:12:21 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1780
ERROR - 2019-04-26 13:12:21 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1781
ERROR - 2019-04-26 13:12:21 --> Severity: Notice --> Undefined variable: roles C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1795
ERROR - 2019-04-26 13:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1795
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: div_col C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1210
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1725
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: month_collection C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1731
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1731
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1739
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: month_expense C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1745
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1745
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1754
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: total_students C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1760
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1761
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1762
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1774
ERROR - 2019-04-26 13:13:19 --> Severity: Notice --> Undefined variable: roles C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1776
ERROR - 2019-04-26 13:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1776
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1725
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: month_collection C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1731
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1731
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1739
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: month_expense C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1745
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1745
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1754
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: total_students C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1760
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: present_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1761
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: absent_stu_count C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1762
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: div_rol C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1774
ERROR - 2019-04-26 13:13:41 --> Severity: Notice --> Undefined variable: roles C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1776
ERROR - 2019-04-26 13:13:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1776
ERROR - 2019-04-26 13:31:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Studentfeemaster_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:31:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Studentfeemaster_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:31:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Studentfeemaster_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:32:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Studentfeemaster_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:32:18 --> Severity: Notice --> Undefined property: Staff::$wing_model C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 355
ERROR - 2019-04-26 13:32:18 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 355
ERROR - 2019-04-26 13:36:22 --> Severity: Notice --> Undefined property: Schsettings::$session_model C:\xampp\htdocs\uvsil\application\controllers\Schsettings.php 28
ERROR - 2019-04-26 13:36:22 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\Schsettings.php 28
ERROR - 2019-04-26 13:36:23 --> Severity: Notice --> Undefined property: Sessions::$session_model C:\xampp\htdocs\uvsil\application\controllers\Sessions.php 20
ERROR - 2019-04-26 13:36:23 --> Severity: Error --> Call to a member function getAllSession() on null C:\xampp\htdocs\uvsil\application\controllers\Sessions.php 20
ERROR - 2019-04-26 13:36:26 --> Severity: Notice --> Undefined property: Paymentsettings::$paymentsetting_model C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:36:26 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "setting1"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:36:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:37:45 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 13:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 13:37:52 --> Severity: Notice --> Undefined property: Sessions::$session_model C:\xampp\htdocs\uvsil\application\controllers\Sessions.php 20
ERROR - 2019-04-26 13:37:52 --> Severity: Error --> Call to a member function getAllSession() on null C:\xampp\htdocs\uvsil\application\controllers\Sessions.php 20
ERROR - 2019-04-26 13:38:30 --> Severity: Notice --> Undefined property: Paymentsettings::$paymentsetting_model C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:38:30 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:40:08 --> Severity: Notice --> Undefined property: Paymentsettings::$paymentsetting_model C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:40:08 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:40:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:40:31 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 13:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 13:41:58 --> Severity: Notice --> Undefined property: Paymentsettings::$paymentsetting_model C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:41:58 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Paymentsettings.php 20
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "setting1"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:33 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "setting1"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:41 --> Could not find the language line "add/edit"
ERROR - 2019-04-26 13:43:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:44:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:44:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Staffattendancemodel C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:45:20 --> Severity: Notice --> Undefined property: Staff::$timeline_model C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 126
ERROR - 2019-04-26 13:45:20 --> Severity: Error --> Call to a member function getStaffTimeline() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 126
ERROR - 2019-04-26 13:45:32 --> Severity: Notice --> Undefined variable: timeline_list C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 126
ERROR - 2019-04-26 13:45:32 --> Severity: Notice --> Undefined property: Staff::$leaverequest_model C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 128
ERROR - 2019-04-26 13:45:32 --> Severity: Error --> Call to a member function staff_leave_request() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 128
ERROR - 2019-04-26 13:45:37 --> Severity: Notice --> Undefined property: Staff::$leaverequest_model C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 127
ERROR - 2019-04-26 13:45:37 --> Severity: Error --> Call to a member function staff_leave_request() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 127
ERROR - 2019-04-26 13:45:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Payroll_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 13:46:21 --> Severity: Notice --> Undefined property: Staff::$payroll_model C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 128
ERROR - 2019-04-26 13:46:21 --> Severity: Error --> Call to a member function getSalaryDetails() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 128
ERROR - 2019-04-26 13:46:29 --> Severity: Notice --> Undefined property: Staff::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 128
ERROR - 2019-04-26 13:46:29 --> Severity: Error --> Call to a member function getStaffAttendanceType() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 128
ERROR - 2019-04-26 13:46:38 --> Severity: Notice --> Undefined variable: staff_leaves C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 138
ERROR - 2019-04-26 13:46:38 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 142
ERROR - 2019-04-26 13:46:38 --> Severity: Notice --> Undefined property: Staff::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 147
ERROR - 2019-04-26 13:46:38 --> Severity: Error --> Call to a member function attendanceYearCount() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 147
ERROR - 2019-04-26 13:46:46 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 142
ERROR - 2019-04-26 13:46:46 --> Severity: Notice --> Undefined property: Staff::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 147
ERROR - 2019-04-26 13:46:46 --> Severity: Error --> Call to a member function attendanceYearCount() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 147
ERROR - 2019-04-26 13:46:53 --> Severity: Notice --> Undefined property: Staff::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 146
ERROR - 2019-04-26 13:46:53 --> Severity: Error --> Call to a member function attendanceYearCount() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 146
ERROR - 2019-04-26 13:47:01 --> Severity: Notice --> Undefined property: Staff::$staffattendancemodel C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 172
ERROR - 2019-04-26 13:47:01 --> Severity: Error --> Call to a member function searchStaffattendance() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 172
ERROR - 2019-04-26 13:47:10 --> Severity: Notice --> Undefined variable: res C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 189
ERROR - 2019-04-26 13:47:11 --> Could not find the language line "detail"
ERROR - 2019-04-26 13:47:11 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 436
ERROR - 2019-04-26 13:47:11 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 436
ERROR - 2019-04-26 13:47:11 --> Severity: Notice --> Undefined variable: yearlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 735
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 735
ERROR - 2019-04-26 13:47:11 --> Severity: Notice --> Undefined variable: attendencetypeslist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 754
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 754
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:12 --> Severity: Notice --> Undefined variable: staff_leaves C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 860
ERROR - 2019-04-26 13:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 860
ERROR - 2019-04-26 13:47:37 --> Could not find the language line "detail"
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 436
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 436
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: yearlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 735
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 735
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: attendencetypeslist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 754
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 754
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:37 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:38 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:39 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 803
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 807
ERROR - 2019-04-26 13:47:40 --> Severity: Notice --> Undefined variable: staff_leaves C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 860
ERROR - 2019-04-26 13:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 860
ERROR - 2019-04-26 13:48:52 --> Could not find the language line "detail"
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 431
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 431
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: yearlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 730
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 730
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: attendencetypeslist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 749
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 749
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:52 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:53 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:54 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 798
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: resultlist C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 802
ERROR - 2019-04-26 13:48:55 --> Severity: Notice --> Undefined variable: staff_leaves C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 855
ERROR - 2019-04-26 13:48:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 855
ERROR - 2019-04-26 13:50:53 --> Could not find the language line "detail"
ERROR - 2019-04-26 13:51:02 --> Severity: Notice --> Undefined property: Staff::$wing_model C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 620
ERROR - 2019-04-26 13:51:02 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 620
ERROR - 2019-04-26 14:31:29 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:32:25 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:32:31 --> Could not find the language line "detail"
ERROR - 2019-04-26 11:07:46 --> Query error: Table 'uvsil.sessions' doesn't exist - Invalid query: SELECT `sch_settings`.`id`, `sch_settings`.`lang_id`, `sch_settings`.`class_teacher`, `sch_settings`.`is_rtl`, `sch_settings`.`cron_secret_key`, `sch_settings`.`timezone`, `sch_settings`.`name`, `sch_settings`.`email`, `sch_settings`.`phone`, `languages`.`language`, `sch_settings`.`address`, `sch_settings`.`dise_code`, `sch_settings`.`date_format`, `sch_settings`.`currency`, `sch_settings`.`currency_symbol`, `sch_settings`.`start_month`, `sch_settings`.`session_id`, `sch_settings`.`fee_due_days`, `sch_settings`.`image`, `sch_settings`.`theme`, `sessions`.`session`
FROM `sch_settings`
JOIN `sessions` ON `sessions`.`id` = `sch_settings`.`session_id`
JOIN `languages` ON `languages`.`id` = `sch_settings`.`lang_id`
ORDER BY `sch_settings`.`id`
ERROR - 2019-04-26 11:08:21 --> Query error: Table 'uvsil.sessions' doesn't exist - Invalid query: SELECT `sch_settings`.`id`, `sch_settings`.`lang_id`, `sch_settings`.`class_teacher`, `sch_settings`.`is_rtl`, `sch_settings`.`cron_secret_key`, `sch_settings`.`timezone`, `sch_settings`.`name`, `sch_settings`.`email`, `sch_settings`.`phone`, `languages`.`language`, `sch_settings`.`address`, `sch_settings`.`dise_code`, `sch_settings`.`date_format`, `sch_settings`.`currency`, `sch_settings`.`currency_symbol`, `sch_settings`.`start_month`, `sch_settings`.`session_id`, `sch_settings`.`fee_due_days`, `sch_settings`.`image`, `sch_settings`.`theme`, `sessions`.`session`
FROM `sch_settings`
JOIN `sessions` ON `sessions`.`id` = `sch_settings`.`session_id`
JOIN `languages` ON `languages`.`id` = `sch_settings`.`lang_id`
ORDER BY `sch_settings`.`id`
ERROR - 2019-04-26 11:09:18 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:18 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 102
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 11:09:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 97
ERROR - 2019-04-26 14:39:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 14:39:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 14:39:19 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 33
ERROR - 2019-04-26 14:39:19 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 34
ERROR - 2019-04-26 14:39:19 --> Query error: Table 'uvsil.staff_designation' doesn't exist - Invalid query: SELECT `staff`.*, `wings`.`wing` as `wingname`, `staff_designation`.`designation` as `designation`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '3'
ERROR - 2019-04-26 14:39:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 91
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 11:10:26 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 86
ERROR - 2019-04-26 14:40:26 --> Query error: Table 'uvsil.staff_designation' doesn't exist - Invalid query: SELECT `staff`.*, `wings`.`wing` as `wingname`, `staff_designation`.`designation` as `designation`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '3'
ERROR - 2019-04-26 14:40:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 90
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:51 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:52 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 11:10:52 --> Severity: Notice --> Undefined index: session_id C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:40:52 --> Query error: Table 'uvsil.staff_designation' doesn't exist - Invalid query: SELECT `staff`.*, `wings`.`wing` as `wingname`, `staff_designation`.`designation` as `designation`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '3'
ERROR - 2019-04-26 14:40:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 11:11:08 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Admin_model.php 10
ERROR - 2019-04-26 11:11:48 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Messages_model.php 10
ERROR - 2019-04-26 11:12:00 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Cms_program_model.php 10
ERROR - 2019-04-26 11:12:17 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Cms_menu_model.php 10
ERROR - 2019-04-26 11:12:26 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Cms_media_model.php 10
ERROR - 2019-04-26 11:12:35 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Cms_page_model.php 10
ERROR - 2019-04-26 11:12:43 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Cms_menuitems_model.php 10
ERROR - 2019-04-26 11:12:53 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Cms_page_content_model.php 10
ERROR - 2019-04-26 11:13:03 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Role_model.php 10
ERROR - 2019-04-26 11:13:11 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSession() C:\xampp\htdocs\uvsil\application\models\Userpermission_model.php 10
ERROR - 2019-04-26 14:43:20 --> Query error: Table 'uvsil.staff_designation' doesn't exist - Invalid query: SELECT `staff`.*, `wings`.`wing` as `wingname`, `staff_designation`.`designation` as `designation`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '3'
ERROR - 2019-04-26 14:44:10 --> Query error: Table 'uvsil.department' doesn't exist - Invalid query: SELECT `staff`.*, `wings`.`wing` as `wingname`, `staff_roles`.`role_id`, `department`.`department_name` as `department`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '3'
ERROR - 2019-04-26 14:44:29 --> Query error: Table 'uvsil.wings' doesn't exist - Invalid query: SELECT `staff`.*, `wings`.`wing` as `wingname`, `staff_roles`.`role_id`, `roles`.`name` as `user_type`
FROM `staff`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id`
LEFT JOIN `wings` ON `wings`.`id` = `staff`.`wing`
WHERE `staff`.`id` = '3'
ERROR - 2019-04-26 14:44:39 --> Query error: Table 'uvsil.staff_payslip' doesn't exist - Invalid query: SELECT *
FROM `staff_payslip`
WHERE `staff_id` = '3'
ERROR - 2019-04-26 14:44:58 --> Severity: Error --> Call to undefined method Staff_model::getStaffPayroll() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 126
ERROR - 2019-04-26 14:45:26 --> Query error: Table 'uvsil.staff_leave_details' doesn't exist - Invalid query: SELECT `staff_leave_details`.*, `leave_types`.`type`
FROM `staff_leave_details`
JOIN `leave_types` ON `staff_leave_details`.`leave_type_id` = `leave_types`.`id`
WHERE `staff_id` = '3'
ERROR - 2019-04-26 14:45:36 --> Severity: Notice --> Undefined variable: alloted_leavetype C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 129
ERROR - 2019-04-26 14:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 129
ERROR - 2019-04-26 14:45:36 --> Severity: Notice --> Undefined variable: staff_payroll C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 140
ERROR - 2019-04-26 14:45:36 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:45:36 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:45:36 --> Query error: Table 'uvsil.staff_attendance' doesn't exist - Invalid query: SELECT count(*) as attendence
FROM `staff_attendance`
WHERE `staff_id` = '3'
AND year(date) = '2019'
AND `staff_attendance_type_id` = 1
ERROR - 2019-04-26 14:45:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\uvsil\system\core\Exceptions.php:271) C:\xampp\htdocs\uvsil\system\core\Common.php 570
ERROR - 2019-04-26 14:45:48 --> Severity: Notice --> Undefined variable: staff_payroll C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 129
ERROR - 2019-04-26 14:45:48 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:45:48 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:45:48 --> Query error: Table 'uvsil.staff_attendance' doesn't exist - Invalid query: SELECT count(*) as attendence
FROM `staff_attendance`
WHERE `staff_id` = '3'
AND year(date) = '2019'
AND `staff_attendance_type_id` = 1
ERROR - 2019-04-26 14:45:58 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:45:58 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\uvsil\application\models\Setting_model.php 85
ERROR - 2019-04-26 14:45:58 --> Query error: Table 'uvsil.staff_attendance' doesn't exist - Invalid query: SELECT count(*) as attendence
FROM `staff_attendance`
WHERE `staff_id` = '3'
AND year(date) = '2019'
AND `staff_attendance_type_id` = 1
ERROR - 2019-04-26 14:46:18 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSessionName() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 133
ERROR - 2019-04-26 14:46:29 --> Severity: Notice --> Undefined variable: session_current C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 134
ERROR - 2019-04-26 14:46:29 --> Severity: Notice --> Undefined variable: session_current C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 135
ERROR - 2019-04-26 14:46:29 --> Severity: Notice --> Undefined variable: session_current C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 136
ERROR - 2019-04-26 14:46:29 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSessionName() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 164
ERROR - 2019-04-26 14:46:40 --> Severity: Notice --> Undefined variable: session_current C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 135
ERROR - 2019-04-26 14:46:40 --> Severity: Notice --> Undefined variable: session_current C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 136
ERROR - 2019-04-26 14:46:40 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSessionName() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 164
ERROR - 2019-04-26 14:46:49 --> Severity: Error --> Call to undefined method Setting_model::getCurrentSessionName() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 163
ERROR - 2019-04-26 14:47:04 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 163
ERROR - 2019-04-26 14:47:04 --> Query error: Table 'uvsil.staff_attendance' doesn't exist - Invalid query: SELECT count(*) as attendence
FROM `staff_attendance`
WHERE `staff_id` = '3'
AND year(date) = '2019'
AND `staff_attendance_type_id` = 1
ERROR - 2019-04-26 14:47:16 --> Severity: Notice --> Undefined variable: start_year C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 163
ERROR - 2019-04-26 14:47:16 --> Severity: Notice --> Undefined variable: start_year C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 166
ERROR - 2019-04-26 14:47:16 --> Query error: Table 'uvsil.staff_attendance' doesn't exist - Invalid query: SELECT count(*) as attendence
FROM `staff_attendance`
WHERE `staff_id` = '3'
AND year(date) = '2019'
AND `staff_attendance_type_id` = 1
ERROR - 2019-04-26 14:47:28 --> Severity: Notice --> Undefined variable: start_year C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 163
ERROR - 2019-04-26 14:47:28 --> Query error: Table 'uvsil.staff_attendance' doesn't exist - Invalid query: SELECT count(*) as attendence
FROM `staff_attendance`
WHERE `staff_id` = '3'
AND year(date) = '2019'
AND `staff_attendance_type_id` = 1
ERROR - 2019-04-26 14:47:37 --> Severity: Notice --> Undefined variable: countAttendance C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 163
ERROR - 2019-04-26 14:47:37 --> Severity: Notice --> Undefined index: wingname C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 108
ERROR - 2019-04-26 14:47:37 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:47:58 --> Severity: Notice --> Undefined index: wingname C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 108
ERROR - 2019-04-26 14:47:58 --> Severity: Notice --> Undefined variable: contract_type C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 120
ERROR - 2019-04-26 14:47:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 120
ERROR - 2019-04-26 14:47:58 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:48:27 --> Severity: Notice --> Undefined index: wingname C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 108
ERROR - 2019-04-26 14:48:27 --> Severity: Notice --> Undefined variable: contract_type C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 120
ERROR - 2019-04-26 14:48:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 120
ERROR - 2019-04-26 14:48:27 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:48:59 --> Severity: Notice --> Undefined variable: contract_type C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 118
ERROR - 2019-04-26 14:48:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given C:\xampp\htdocs\uvsil\application\views\admin\staff\staffprofile.php 118
ERROR - 2019-04-26 14:48:59 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:49:37 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:49:50 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:49:57 --> Query error: Table 'uvsil.staff_payroll' doesn't exist - Invalid query: SELECT *
FROM `staff_payroll`
ORDER BY `id`
ERROR - 2019-04-26 14:51:46 --> Severity: Error --> Call to undefined method Staff_model::getPayroll() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 574
ERROR - 2019-04-26 14:52:15 --> Severity: Error --> Call to undefined method Staff_model::getLeaveDetails() C:\xampp\htdocs\uvsil\application\controllers\admin\Staff.php 596
ERROR - 2019-04-26 14:52:27 --> Severity: Notice --> Undefined variable: getStaffRole C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 44
ERROR - 2019-04-26 14:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 44
ERROR - 2019-04-26 14:52:27 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 63
ERROR - 2019-04-26 14:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 63
ERROR - 2019-04-26 14:52:27 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 81
ERROR - 2019-04-26 14:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 81
ERROR - 2019-04-26 14:52:27 --> Severity: Notice --> Undefined variable: leavetypeList C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 382
ERROR - 2019-04-26 14:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\staff\staffedit.php 382
ERROR - 2019-04-26 14:52:35 --> Query error: Table 'uvsil.staff_designation' doesn't exist - Invalid query: SELECT `staff`.*, `staff_designation`.`designation` as `designation`, `department`.`department_name` as `department`,`roles`.`name` as user_type  FROM `staff` LEFT JOIN `staff_designation` ON `staff_designation`.`id` = `staff`.`designation` LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id` LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id` LEFT JOIN `department` ON `department`.`id` = `staff`.`department` WHERE  `staff`.`is_active` = '1' and (`staff`.`name` LIKE '%%' ESCAPE '!' OR `staff`.`surname` LIKE '%%' ESCAPE '!' OR `staff`.`employee_id` LIKE '%%' ESCAPE '!' OR `staff`.`local_address` LIKE '%%' ESCAPE '!'  OR `staff`.`contact_no` LIKE '%%' ESCAPE '!' OR `staff`.`email` LIKE '%%' ESCAPE '!')
ERROR - 2019-04-26 14:56:18 --> Query error: Unknown column 'department.department_name' in 'field list' - Invalid query: SELECT `staff`.*, `department`.`department_name` as `department`,`roles`.`name` as user_type  FROM `staff` LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id` LEFT JOIN `roles` ON `staff_roles`.`role_id` = `roles`.`id` WHERE  `staff`.`is_active` = '1' and (`staff`.`name` LIKE '%%' ESCAPE '!' OR `staff`.`surname` LIKE '%%' ESCAPE '!' OR `staff`.`employee_id` LIKE '%%' ESCAPE '!' OR `staff`.`local_address` LIKE '%%' ESCAPE '!'  OR `staff`.`contact_no` LIKE '%%' ESCAPE '!' OR `staff`.`email` LIKE '%%' ESCAPE '!')
ERROR - 2019-04-26 14:56:42 --> Could not find the language line "detail"
ERROR - 2019-04-26 14:56:46 --> Severity: Notice --> Undefined index: current_session C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 78
ERROR - 2019-04-26 14:56:46 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 14:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 14:56:53 --> Severity: Notice --> Undefined index: current_session C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 78
ERROR - 2019-04-26 14:56:53 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 14:56:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 242
ERROR - 2019-04-26 14:57:37 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 14:57:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 14:57:58 --> Query error: Table 'uvsil.send_notification' doesn't exist - Invalid query: select send_notification.* from send_notification INNER JOIN notification_roles on notification_roles.send_notification_id = send_notification.id left JOIN read_notification on read_notification.staff_id='0' and read_notification.notification_id = send_notification.id WHERE send_notification.created_id !='0' and send_notification.visible_staff='yes' and read_notification.id IS NULL and notification_roles.role_id='7' order by send_notification.id desc
ERROR - 2019-04-26 14:58:02 --> Query error: Table 'uvsil.send_notification' doesn't exist - Invalid query: select send_notification.* from send_notification INNER JOIN notification_roles on notification_roles.send_notification_id = send_notification.id left JOIN read_notification on read_notification.staff_id='0' and read_notification.notification_id = send_notification.id WHERE send_notification.created_id !='0' and send_notification.visible_staff='yes' and read_notification.id IS NULL and notification_roles.role_id='7' order by send_notification.id desc
ERROR - 2019-04-26 11:28:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:29:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:30:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:30:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:30:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:31:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:31:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:31:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:31:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:32:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:32:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:32:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 11:32:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\uvsil\system\core\Loader.php 344
ERROR - 2019-04-26 15:02:37 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 15:02:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 15:02:43 --> Severity: Notice --> Undefined property: Admin::$notification_model C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 140
ERROR - 2019-04-26 15:02:43 --> Severity: Error --> Call to a member function getUnreadStaffNotification() on null C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 140
ERROR - 2019-04-26 15:03:03 --> Severity: Notice --> Undefined variable: input C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 141
ERROR - 2019-04-26 15:03:03 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 141
ERROR - 2019-04-26 15:03:03 --> Query error: Table 'uvsil.expenses' doesn't exist - Invalid query: SELECT SUM(amount) as amount FROM expenses where date='2019-04-01'
ERROR - 2019-04-26 15:03:11 --> Severity: Notice --> Undefined variable: a C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 140
ERROR - 2019-04-26 15:03:11 --> Severity: Notice --> Undefined variable: b C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 141
ERROR - 2019-04-26 15:03:11 --> Severity: Notice --> Undefined variable: b C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 144
ERROR - 2019-04-26 15:03:11 --> Query error: Table 'uvsil.expenses' doesn't exist - Invalid query: SELECT SUM(amount) as amount FROM expenses where date='2019-04-01'
ERROR - 2019-04-26 15:03:17 --> Severity: Notice --> Undefined variable: Current_year C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 153
ERROR - 2019-04-26 15:03:17 --> Severity: Notice --> Undefined variable: Next_year C:\xampp\htdocs\uvsil\application\controllers\admin\Admin.php 154
ERROR - 2019-04-26 15:03:17 --> Query error: Table 'uvsil.expenses' doesn't exist - Invalid query: SELECT SUM(amount) as amount FROM expenses where date='2019-04-01'
ERROR - 2019-04-26 15:03:47 --> Severity: Notice --> Undefined variable: notifications C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1195
ERROR - 2019-04-26 15:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\admin\dashboard.php 1195
ERROR - 2019-04-26 11:35:51 --> Query error: Table 'uvsil.sessions' doesn't exist - Invalid query: SELECT `sch_settings`.`id`, `sch_settings`.`lang_id`, `sch_settings`.`is_rtl`, `sch_settings`.`timezone`, `sch_settings`.`name`, `sch_settings`.`email`, `sch_settings`.`phone`, `languages`.`language`, `sch_settings`.`address`, `sch_settings`.`dise_code`, `sch_settings`.`date_format`, `sch_settings`.`currency`, `sch_settings`.`image` as `logo`, `sch_settings`.`currency_symbol`, `sch_settings`.`start_month`, `sch_settings`.`session_id`, `sch_settings`.`image`, `sch_settings`.`theme`, `sessions`.`session`
FROM `sch_settings`
JOIN `sessions` ON `sessions`.`id` = `sch_settings`.`session_id`
JOIN `languages` ON `languages`.`id` = `sch_settings`.`lang_id`
ORDER BY `sch_settings`.`id`
ERROR - 2019-04-26 12:25:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\uvsil\application\controllers\Welcome.php 29
ERROR - 2019-04-26 12:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\controllers\Welcome.php 29
ERROR - 2019-04-26 12:25:15 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\uvsil\application\controllers\Welcome.php 29
ERROR - 2019-04-26 12:25:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\uvsil\application\controllers\Welcome.php 29
ERROR - 2019-04-26 15:56:34 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 15:56:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 15:56:45 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 15:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:07:15 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:07:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:08:28 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:15:37 --> Severity: Notice --> Undefined variable: sessionlist C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:15:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\uvsil\application\views\setting\settingList.php 237
ERROR - 2019-04-26 16:16:18 --> Severity: Notice --> Undefined property: Page::$book_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Page.php 109
ERROR - 2019-04-26 16:16:18 --> Severity: Error --> Call to a member function listbook() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Page.php 109
ERROR - 2019-04-26 16:17:39 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\uvsil\application\controllers\admin\Frontcms.php 69
ERROR - 2019-04-26 12:50:10 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 8
ERROR - 2019-04-26 12:50:10 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 13
ERROR - 2019-04-26 12:50:10 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 18
ERROR - 2019-04-26 12:50:10 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 23
ERROR - 2019-04-26 12:50:17 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 8
ERROR - 2019-04-26 12:50:17 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 13
ERROR - 2019-04-26 12:50:17 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 18
ERROR - 2019-04-26 12:50:17 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 23
ERROR - 2019-04-26 12:56:28 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 8
ERROR - 2019-04-26 12:56:28 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 13
ERROR - 2019-04-26 12:56:28 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 18
ERROR - 2019-04-26 12:56:28 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\header.php 23
ERROR - 2019-04-26 13:01:24 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\home_slider.php 4
ERROR - 2019-04-26 13:01:24 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\home_slider.php 4
ERROR - 2019-04-26 13:01:24 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\home_slider.php 4
ERROR - 2019-04-26 13:01:30 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\home_slider.php 4
ERROR - 2019-04-26 13:01:30 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\home_slider.php 4
ERROR - 2019-04-26 13:01:30 --> Severity: Notice --> Undefined variable: base_assets_url C:\xampp\htdocs\uvsil\application\views\themes\default\home_slider.php 4
ERROR - 2019-04-26 17:02:45 --> Severity: Notice --> Undefined property: Page::$book_model C:\xampp\htdocs\uvsil\application\controllers\admin\front\Page.php 109
ERROR - 2019-04-26 17:02:45 --> Severity: Error --> Call to a member function listbook() on null C:\xampp\htdocs\uvsil\application\controllers\admin\front\Page.php 109
ERROR - 2019-04-26 17:03:40 --> Severity: Notice --> Undefined variable: listbook C:\xampp\htdocs\uvsil\application\controllers\admin\front\Page.php 109
