<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-27 11:19:43 --> Severity: Notice --> Undefined property: Gradescaleforsubject::$mm_gradescaleforsubject_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Gradescaleforsubject.php 85
ERROR - 2019-02-27 11:19:44 --> Severity: Error --> Call to a member function checkalreadyexist() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Gradescaleforsubject.php 85
ERROR - 2019-02-27 17:07:14 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:14 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:14 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:14 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:58 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:58 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:58 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:07:58 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:08:19 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:08:19 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:08:19 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
ERROR - 2019-02-27 17:08:19 --> Severity: Notice --> Undefined index: subject C:\xampp\htdocs\smartschool\application\views\admin\marksmanager\subjectWiseMarksEntry.php 60
