<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-22 17:45:34 --> Severity: Notice --> Undefined index: sign_img C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 280
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 356
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 392
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 397
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 398
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 404
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 410
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 410
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 424
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 429
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 434
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 439
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 444
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 449
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 454
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 459
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 464
ERROR - 2019-04-22 17:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smartschool\application\controllers\admin\Studentidcard.php 475
