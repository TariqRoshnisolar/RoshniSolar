<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-22 13:22:45 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 13:25:53 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 13:25:58 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 13:26:11 --> Error
ERROR - 2019-01-22 13:27:26 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 13:27:37 --> Error
ERROR - 2019-01-22 14:23:45 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 14:26:13 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 14:43:28 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 14:49:17 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 14:49:32 --> Error
ERROR - 2019-01-22 14:49:32 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 14:50:39 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 14:50:52 --> Error
ERROR - 2019-01-22 14:57:12 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:01:51 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 10:40:16 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\smartschool\application\helpers\customerrorhandle_helper.php 6
ERROR - 2019-01-22 10:40:16 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\smartschool\application\helpers\customerrorhandle_helper.php 6
ERROR - 2019-01-22 10:40:16 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\smartschool\application\helpers\customerrorhandle_helper.php 6
ERROR - 2019-01-22 10:40:16 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\smartschool\application\helpers\customerrorhandle_helper.php 6
ERROR - 2019-01-22 15:10:41 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:11:17 --> Severity: Notice --> Undefined variable: e C:\xampp\htdocs\smartschool\application\helpers\customerrorhandle_helper.php 7
ERROR - 2019-01-22 15:11:17 --> Severity: Error --> Call to a member function getMessage() on null C:\xampp\htdocs\smartschool\application\helpers\customerrorhandle_helper.php 7
ERROR - 2019-01-22 15:11:53 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:12:15 --> Error
ERROR - 2019-01-22 15:12:28 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:37:13 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:42:31 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:42:45 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:43:58 --> errordb
ERROR - 2019-01-22 15:44:06 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:44:19 --> errordb
ERROR - 2019-01-22 15:48:56 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:48:58 --> Could not find the language line "student_fee1"
ERROR - 2019-01-22 15:48:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examList.php 36
ERROR - 2019-01-22 16:34:32 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\smartschool\application\views\layout\header.php 826
ERROR - 2019-01-22 16:35:45 --> Severity: Parsing Error --> syntax error, unexpected 'base_url' (T_STRING) C:\xampp\htdocs\smartschool\application\views\layout\header.php 830
ERROR - 2019-01-22 16:51:17 --> Could not find the language line "form_validation_subjectcodeuniquetest"
ERROR - 2019-01-22 17:54:31 --> Severity: Notice --> Undefined property: Defineremarkstype::$mm_remarkstype_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineremarkstype.php 23
ERROR - 2019-01-22 17:54:31 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineremarkstype.php 23
