<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-22 08:56:15 --> Non-existent class: Smsgateway
ERROR - 2019-05-22 09:15:43 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:15:43 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:17:15 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:17:15 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:17:43 --> Severity: Warning --> Missing argument 1 for Smsgateway::sendotp() /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 16
ERROR - 2019-05-22 09:17:43 --> Severity: Warning --> Missing argument 2 for Smsgateway::sendotp() /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 16
ERROR - 2019-05-22 09:17:43 --> Severity: Notice --> Undefined property: Smsgateway::$input /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 18
ERROR - 2019-05-22 09:17:43 --> Severity: Error --> Call to a member function method() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 18
ERROR - 2019-05-22 09:18:13 --> Severity: Notice --> Undefined property: Smsgateway::$input /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 18
ERROR - 2019-05-22 09:18:13 --> Severity: Error --> Call to a member function method() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 18
ERROR - 2019-05-22 09:19:32 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:19:32 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:19:43 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:19:43 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 9
ERROR - 2019-05-22 09:22:00 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:22:00 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:22:25 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:22:25 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:23:23 --> Severity: Notice --> Undefined property: Smsgateway::$input /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 19
ERROR - 2019-05-22 09:23:23 --> Severity: Error --> Call to a member function method() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 19
ERROR - 2019-05-22 09:24:51 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:24:51 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:25:44 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:25:44 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:26:33 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 52
ERROR - 2019-05-22 09:26:33 --> Severity: Error --> Call to a member function helper() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 52
ERROR - 2019-05-22 09:27:50 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:27:50 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:30:20 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:30:20 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:30:25 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:30:25 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:30:48 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:30:48 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:31:27 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:31:27 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:31:31 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:31:31 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:34:18 --> Severity: Notice --> Undefined property: Smsservice::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 10
ERROR - 2019-05-22 09:34:18 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 10
ERROR - 2019-05-22 09:35:17 --> Severity: Notice --> Undefined property: Smsservice::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 40
ERROR - 2019-05-22 09:35:17 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 40
ERROR - 2019-05-22 09:35:19 --> Severity: Notice --> Undefined property: Smsservice::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 40
ERROR - 2019-05-22 09:35:19 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 40
ERROR - 2019-05-22 09:35:34 --> Severity: Notice --> Undefined property: Smsservice::$input /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 14
ERROR - 2019-05-22 09:35:34 --> Severity: Error --> Call to a member function method() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsservice.php 14
ERROR - 2019-05-22 09:37:03 --> Severity: Warning --> Missing argument 1 for Msgnineone::__construct(), called in /home/o2ixr95i7zue/public_html/system/core/Loader.php on line 1279 and defined /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 15
ERROR - 2019-05-22 09:37:03 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 18
ERROR - 2019-05-22 09:37:03 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 19
ERROR - 2019-05-22 09:37:34 --> Severity: Warning --> Missing argument 1 for Msgnineone::__construct(), called in /home/o2ixr95i7zue/public_html/system/core/Loader.php on line 1279 and defined /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 15
ERROR - 2019-05-22 09:37:34 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 18
ERROR - 2019-05-22 09:37:34 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 19
ERROR - 2019-05-22 09:37:45 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 11
ERROR - 2019-05-22 09:37:45 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 11
ERROR - 2019-05-22 09:38:23 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 11
ERROR - 2019-05-22 09:38:23 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 11
ERROR - 2019-05-22 09:38:37 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:38:37 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:39:29 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:39:29 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:40:39 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:40:39 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:41:31 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:41:31 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:42:05 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:42:05 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:43:15 --> Severity: Warning --> Missing argument 1 for Msgnineone::__construct(), called in /home/o2ixr95i7zue/public_html/system/core/Loader.php on line 1279 and defined /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 15
ERROR - 2019-05-22 09:43:15 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 18
ERROR - 2019-05-22 09:43:15 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 19
ERROR - 2019-05-22 09:43:32 --> Severity: Warning --> Missing argument 1 for Msgnineone::__construct(), called in /home/o2ixr95i7zue/public_html/system/core/Loader.php on line 1279 and defined /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 15
ERROR - 2019-05-22 09:43:32 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 18
ERROR - 2019-05-22 09:43:32 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 19
ERROR - 2019-05-22 09:44:09 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 18
ERROR - 2019-05-22 09:44:09 --> Severity: Notice --> Undefined variable: array /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 19
ERROR - 2019-05-22 09:44:33 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:44:33 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:44:39 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:44:39 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:44:44 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:44:44 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:45:40 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:45:40 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:47:07 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:47:07 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 53
ERROR - 2019-05-22 09:57:37 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 09:57:37 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/Smsgateway.php 10
ERROR - 2019-05-22 10:03:30 --> Severity: Notice --> Undefined property: Smsgateway::$input /home/o2ixr95i7zue/public_html/application/controllers/user/Smsgateway.php 19
ERROR - 2019-05-22 10:03:30 --> Severity: Error --> Call to a member function method() on null /home/o2ixr95i7zue/public_html/application/controllers/user/Smsgateway.php 19
ERROR - 2019-05-22 10:03:53 --> Severity: Notice --> Undefined property: Smsgateway::$load /home/o2ixr95i7zue/public_html/application/controllers/user/Smsgateway.php 10
ERROR - 2019-05-22 10:03:53 --> Severity: Error --> Call to a member function library() on null /home/o2ixr95i7zue/public_html/application/controllers/user/Smsgateway.php 10
ERROR - 2019-05-22 10:08:04 --> Severity: Error --> Call to undefined function sentotptomobile() /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 25
ERROR - 2019-05-22 10:09:12 --> Severity: Error --> Call to undefined function sendotptomobile() /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 25
ERROR - 2019-05-22 10:09:47 --> Severity: Notice --> Undefined variable: contactno /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 127
ERROR - 2019-05-22 10:13:56 --> Severity: Notice --> Array to string conversion /home/o2ixr95i7zue/public_html/application/libraries/Msgnineone.php 134
ERROR - 2019-05-22 10:30:00 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 41
ERROR - 2019-05-22 10:42:41 --> Severity: Notice --> Undefined variable: email /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 28
ERROR - 2019-05-22 11:52:16 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:17 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:19 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:23 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:27 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:33 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:41 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:42 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:54 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 11:52:55 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 32
ERROR - 2019-05-22 12:01:52 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 866
ERROR - 2019-05-22 12:04:48 --> Severity: Parsing Error --> syntax error, unexpected 'class' (T_CLASS), expecting variable (T_VARIABLE) /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Registration.php 21
