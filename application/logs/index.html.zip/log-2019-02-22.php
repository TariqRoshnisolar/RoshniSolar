<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-22 10:30:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examList.php 37
ERROR - 2019-02-22 10:30:51 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examList.php 37
ERROR - 2019-02-22 10:31:02 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\exam_schedule\examCreate.php 73
ERROR - 2019-02-22 10:32:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\mark\markList.php 67
ERROR - 2019-02-22 10:32:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\mark\markCreate.php 62
ERROR - 2019-02-22 16:45:22 --> Severity: Notice --> Undefined property: Defineexamforstudent::$mm_examforstudent_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 97
ERROR - 2019-02-22 16:45:22 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 97
ERROR - 2019-02-22 16:46:44 --> Severity: Notice --> Undefined property: Defineexamforstudent::$mm_examforstudent_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 97
ERROR - 2019-02-22 16:46:44 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 97
ERROR - 2019-02-22 16:50:47 --> Severity: Notice --> Undefined property: Defineexamforstudent::$mm_examforstudent_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 16:50:47 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 16:58:16 --> Severity: Notice --> Undefined property: Defineexamforstudent::$mm_examforstudent_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 16:58:16 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 16:59:43 --> Severity: Notice --> Undefined property: Defineexamforstudent::$mm_examforstudent_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 16:59:43 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 17:02:37 --> Severity: Notice --> Undefined property: Defineexamforstudent::$mm_examforstudent_model C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
ERROR - 2019-02-22 17:02:37 --> Severity: Error --> Call to a member function add() on null C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Defineexamforstudent.php 98
