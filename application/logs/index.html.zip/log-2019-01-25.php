<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-25 11:56:13 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 11:56:30 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 11:56:34 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:13:00 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:40:12 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:44:15 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:44:22 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:46:55 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:47:39 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:50:17 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:50:39 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:50:42 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 12:52:24 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 13:17:59 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 13:20:20 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 13:20:24 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 13:20:56 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 13:20:59 --> Could not find the language line "by_date1"
ERROR - 2019-01-25 13:39:14 --> Severity: Notice --> Undefined index: data C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 253
ERROR - 2019-01-25 13:39:16 --> Severity: Warning --> mysqli_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:39:16 --> Severity: Warning --> mysqli_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:39:16 --> Severity: Warning --> mysqli_error() expects parameter 1 to be mysqli, boolean given C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:41:24 --> Severity: Notice --> Undefined index: data C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 253
ERROR - 2019-01-25 13:41:26 --> Severity: Warning --> mysqli_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:41:26 --> Severity: Warning --> mysqli_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:41:26 --> Severity: Warning --> mysqli_error() expects parameter 1 to be mysqli, boolean given C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:42:44 --> Severity: Notice --> Undefined index: data C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 253
ERROR - 2019-01-25 13:42:46 --> Severity: Warning --> mysqli_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:42:46 --> Severity: Warning --> mysqli_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
ERROR - 2019-01-25 13:42:46 --> Severity: Warning --> mysqli_error() expects parameter 1 to be mysqli, boolean given C:\xampp\htdocs\smartschool\application\controllers\admin\Composesms.php 255
