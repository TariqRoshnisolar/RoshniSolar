<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-15 13:01:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 13:01:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 13:02:02 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 13:02:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 13:27:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 14:53:55 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 14:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 14:54:02 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 14:54:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 14:54:49 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 14:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 15:00:47 --> Severity: Notice --> Undefined variable: feeheadlist C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 41
ERROR - 2019-04-15 15:22:04 --> Severity: Notice --> Undefined variable: classsectionlist C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 15:22:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\views\admin\studentfee\feehead.php 189
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:24:09 --> Severity: Notice --> Undefined index: fee_group_name C:\xampp\htdocs\smartschool\application\controllers\admin\Feeheadtohostel.php 42
ERROR - 2019-04-15 15:33:46 --> Could not find the language line "student_fee"
ERROR - 2019-04-15 15:33:47 --> Could not find the language line "back"
ERROR - 2019-04-15 17:00:22 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 125
ERROR - 2019-04-15 17:00:22 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 138
ERROR - 2019-04-15 17:00:48 --> Query error: Unknown column 'description' in 'field list' - Invalid query: INSERT INTO `fees_discounts` (`name`, `feehead_id`, `amount`, `description`, `session_id`) VALUES ('Tuition Fee', '2', '100.00', NULL, '14')
ERROR - 2019-04-15 17:02:28 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 125
ERROR - 2019-04-15 17:02:28 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 138
ERROR - 2019-04-15 17:02:28 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 125
ERROR - 2019-04-15 17:02:28 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 138
ERROR - 2019-04-15 17:05:37 --> Severity: Notice --> Undefined index: fee_head C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 124
ERROR - 2019-04-15 17:05:37 --> Severity: Notice --> Undefined index: fee_head C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountList.php 124
ERROR - 2019-04-15 17:11:06 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `fees_discounts`.`id`, `fees_discounts`.`name`, `fees_discounts`.`amount`, `fee_head`.`name` as `fee_head`
FROM `fees_discounts`
INNER JOIN `fee_head` ON `fee_head`.`id`=`fees_discounts`.`feehead_id` and `fee_head`.`is_deleted`=0
WHERE `id` = '2'
ERROR - 2019-04-15 17:13:08 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 38
ERROR - 2019-04-15 17:13:08 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 48
ERROR - 2019-04-15 17:13:08 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 112
ERROR - 2019-04-15 17:13:08 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 125
ERROR - 2019-04-15 17:18:31 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 45
ERROR - 2019-04-15 17:18:47 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 56
ERROR - 2019-04-15 17:18:47 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 66
ERROR - 2019-04-15 17:18:47 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 130
ERROR - 2019-04-15 17:18:47 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 143
ERROR - 2019-04-15 17:19:16 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 56
ERROR - 2019-04-15 17:19:16 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 66
ERROR - 2019-04-15 17:19:16 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 130
ERROR - 2019-04-15 17:19:16 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 143
ERROR - 2019-04-15 17:22:00 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 56
ERROR - 2019-04-15 17:22:00 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 66
ERROR - 2019-04-15 17:24:04 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 56
ERROR - 2019-04-15 17:24:04 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 66
ERROR - 2019-04-15 17:25:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 17:30:39 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 56
ERROR - 2019-04-15 17:30:39 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 66
ERROR - 2019-04-15 17:36:35 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 56
ERROR - 2019-04-15 17:36:35 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\smartschool\application\views\admin\feediscount\feediscountEdit.php 66
ERROR - 2019-04-15 17:38:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 17:38:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 30
ERROR - 2019-04-15 17:38:31 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\smartschool\application\views\admin\feediscount\assign.php 125
