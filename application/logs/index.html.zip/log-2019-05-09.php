<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-09 05:03:38 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/trigenterp/public_html/uvsil/system/libraries/Email.php 2055
ERROR - 2019-05-09 05:03:38 --> Severity: Warning --> fsockopen(): unable to connect to mail.trigent.com:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/trigenterp/public_html/uvsil/system/libraries/Email.php 2055
ERROR - 2019-05-09 05:08:32 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/trigenterp/public_html/uvsil/system/libraries/Email.php 2055
ERROR - 2019-05-09 05:08:32 --> Severity: Warning --> fsockopen(): unable to connect to ssl://mail.trigent.com:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/trigenterp/public_html/uvsil/system/libraries/Email.php 2055
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: fname /home/trigenterp/public_html/uvsil/application/views/send.php 2
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: lname /home/trigenterp/public_html/uvsil/application/views/send.php 3
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: email /home/trigenterp/public_html/uvsil/application/views/send.php 4
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: phone /home/trigenterp/public_html/uvsil/application/views/send.php 5
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: company /home/trigenterp/public_html/uvsil/application/views/send.php 6
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: country /home/trigenterp/public_html/uvsil/application/views/send.php 7
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: state /home/trigenterp/public_html/uvsil/application/views/send.php 8
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: city /home/trigenterp/public_html/uvsil/application/views/send.php 9
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: message /home/trigenterp/public_html/uvsil/application/views/send.php 10
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined variable: company /home/trigenterp/public_html/uvsil/application/views/send.php 56
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 94
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 95
ERROR - 2019-05-09 05:14:57 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 96
ERROR - 2019-05-09 05:17:40 --> Severity: Notice --> Undefined variable: company /home/trigenterp/public_html/uvsil/application/views/send.php 56
ERROR - 2019-05-09 05:17:40 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 94
ERROR - 2019-05-09 05:17:40 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 95
ERROR - 2019-05-09 05:17:40 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 96
ERROR - 2019-05-09 05:18:39 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 94
ERROR - 2019-05-09 05:18:39 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 95
ERROR - 2019-05-09 05:18:39 --> Severity: Notice --> Undefined index: fileatt /home/trigenterp/public_html/uvsil/application/views/send.php 96
ERROR - 2019-05-09 07:22:57 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 862
ERROR - 2019-05-09 07:23:06 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 862
ERROR - 2019-05-09 07:56:39 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:56:39 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:56:39 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:56:57 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:56:57 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:56:57 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:15 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:15 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:15 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:37 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:37 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:37 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:40 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:40 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:57:40 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:58:26 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:58:26 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:58:26 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:58:54 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:58:54 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:58:54 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:59:18 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:59:18 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 07:59:18 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:00:18 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:00:18 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:00:18 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:01:13 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:01:13 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:01:13 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:03:59 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:03:59 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:03:59 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:02 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:02 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:02 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:22 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:22 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:22 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:27 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:27 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:04:27 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:05:36 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:05:36 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:05:36 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:05:39 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:05:39 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:05:39 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:06:36 --> Severity: Notice --> Undefined variable: url /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:06:36 --> Severity: Notice --> Undefined variable: key /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
ERROR - 2019-05-09 08:06:36 --> Severity: Notice --> Undefined variable: menu /home/trigenterp/public_html/uvsil/application/views/themes/default/layout.php 173
