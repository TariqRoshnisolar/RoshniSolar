<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-03 00:13:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:13:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:14:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:14:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:30:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:30:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:30:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:30:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:30:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:30:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:38:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:38:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:59:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:59:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 00:59:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 00:59:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 01:02:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 01:02:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 01:03:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 01:03:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 01:41:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 01:41:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 02:12:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 02:12:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 06:13:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 06:13:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:06:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:06:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:06:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:06:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:07:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:07:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:30:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:30:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:31:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:31:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:32:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:32:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:32:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:32:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:33:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:33:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:34:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:34:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:34:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:34:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:35:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:35:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:57:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:57:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:59:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:59:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:59:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 07:59:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:00:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:00:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:00:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:00:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:10:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:10:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:19:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:19:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:20:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:20:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:20:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:20:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:20:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:20:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:21:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:21:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:23:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:23:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:38:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:38:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:38:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:38:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:39:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:39:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:50:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:50:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 08:50:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 08:50:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 03:30:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/o2ixr95i7zue/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-06-03 03:30:19 --> Unable to connect to the database
ERROR - 2019-06-03 03:30:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/o2ixr95i7zue/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-06-03 03:30:21 --> Unable to connect to the database
ERROR - 2019-06-03 09:01:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:01:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:04:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:04:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:05:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:05:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:09:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:09:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:26:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:26:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:39:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:39:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:40:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:40:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:40:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:40:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:49:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:49:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:55:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:55:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:56:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:56:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:58:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:58:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 09:58:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 09:58:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:01:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:01:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:02:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:02:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:07:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:07:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:07:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:07:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:07:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:07:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:09:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:09:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:09:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:09:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:09:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:09:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:09:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:09:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:10:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:10:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:11:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:11:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:11:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:11:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:12:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:12:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:13:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:13:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:13:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:13:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:14:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:14:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:15:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:15:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:18:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:18:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:18:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:18:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:20:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:20:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:21:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:21:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:23:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:23:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:23:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:23:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:25:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:25:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:26:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:26:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:27:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:27:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:28:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:28:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:29:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:29:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:29:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:29:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:32:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:32:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:32:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:32:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:33:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:33:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:39:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:39:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:46:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:46:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:47:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:47:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:47:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:47:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:50:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:50:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:50:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:50:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:51:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:51:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:52:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:52:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:53:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:53:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:55:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:55:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 10:59:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 10:59:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:05:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:05:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:07:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:07:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:07:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:07:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:17:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:17:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:21:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:21:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:23:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Classteacher_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 344
ERROR - 2019-06-03 11:24:38 --> Query error: Table 'uvsil_new.department' doesn't exist - Invalid query: SELECT `staff`.*, `roles`.`id` as `role_id`, `roles`.`name` as `role`
FROM `staff`
LEFT JOIN `staff_roles` ON `staff_roles`.`staff_id` = `staff`.`id`
LEFT JOIN `roles` ON `roles`.`id` = `staff_roles`.`role_id`
LEFT JOIN `department` ON `department`.`id` = `staff`.`department`
ORDER BY `staff`.`id`
ERROR - 2019-06-03 11:24:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:24:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:25:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:25:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:26:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:26:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:26:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:26:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:27:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:27:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:29:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:29:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:29:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:29:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:29:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:29:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:30:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:30:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:32:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:32:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:35:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:35:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:36:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:36:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:36:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:36:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:36:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:36:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:38:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:38:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:38:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:38:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:40:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:40:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:40:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:40:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:40:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:40:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:40:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:40:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:41:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:41:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:42:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:42:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:45:21 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 11:45:21 --> Severity: Notice --> Undefined variable: classlist /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 26
ERROR - 2019-06-03 11:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 26
ERROR - 2019-06-03 11:45:21 --> Severity: Notice --> Undefined variable: categorylist /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 11:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 11:45:21 --> Severity: Notice --> Undefined variable: genderList /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 11:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 11:45:21 --> Severity: Notice --> Undefined variable: RTEstatusList /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 83
ERROR - 2019-06-03 11:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 83
ERROR - 2019-06-03 11:46:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:46:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:46:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:46:42 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:48:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:48:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:51:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:51:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:52:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:52:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:52:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:52:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:57:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:57:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:57:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:57:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:57:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:57:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:57:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:57:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:58:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:58:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:58:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:58:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 11:58:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 11:58:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:04:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:04:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:04:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:04:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:10:14 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:12:07 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:13:01 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:13:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:13:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:14:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:17:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:17:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:19:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:19:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:21:06 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:21:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:22:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:22:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:22:32 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:26:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:26:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:26:36 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 52
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 53
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 62
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 63
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 64
ERROR - 2019-06-03 12:26:36 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:26:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:26:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:26:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:26:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:27:21 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: section /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 55
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: admission_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 56
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 58
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 65
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 66
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 67
ERROR - 2019-06-03 12:27:21 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 68
ERROR - 2019-06-03 12:27:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:28:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:28:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:28:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:28:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:29:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:29:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:31:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:31:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:32:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:32:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:33:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:33:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:34:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:34:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:34:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:34:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:05:47 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting variable (T_VARIABLE) or ${ (T_DOLLAR_OPEN_CURLY_BRACES) or {$ (T_CURLY_OPEN) /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 154
ERROR - 2019-06-03 12:37:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:37:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:37:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:37:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:08:17 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 156
ERROR - 2019-06-03 12:38:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:38:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:39:11 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:39:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:39:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:39:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:39:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:40:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:40:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:40:37 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 12:40:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:40:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:41:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:41:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 07:11:05 --> Severity: error --> Exception: /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php exists, but doesn't declare class Regstration_model /home/o2ixr95i7zue/public_html/system/core/Loader.php 336
ERROR - 2019-06-03 07:11:07 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 151
ERROR - 2019-06-03 12:41:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:41:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:41:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:41:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:46:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:46:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:47:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:47:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:52:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:52:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 12:53:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 12:53:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:05:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:05:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:08:00 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 75
ERROR - 2019-06-03 13:08:13 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 13:08:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:08:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:08:27 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: firstname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: lastname /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 78
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined offset: 2 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined offset: 1 /home/o2ixr95i7zue/public_html/application/libraries/Customlib.php 549
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: mobileno /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 85
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: samagra_id /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 86
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: adhar_no /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 87
ERROR - 2019-06-03 13:08:27 --> Severity: Notice --> Undefined index: rte /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 88
ERROR - 2019-06-03 13:13:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:13:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:14:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:14:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:14:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:14:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:15:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:15:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:17:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:17:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:25:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:25:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:25:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:25:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:29:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:29:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:29:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:29:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:30:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:30:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:32:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:32:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:33:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:33:12 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:33:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:33:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:34:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:34:02 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:34:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:34:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:39:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:39:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:39:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:39:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:39:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:39:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:39:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:39:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:40:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:40:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:40:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:40:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:41:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:41:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:43:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:43:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:44:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:44:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:54:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:54:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:54:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:54:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:55:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:55:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:55:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:55:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:55:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:55:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:55:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:55:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:56:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:56:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 13:57:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 13:57:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:03:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:03:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:04:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:04:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:05:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:05:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:06:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:06:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:11:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:11:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:12:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:12:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:14:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:14:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:14:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:14:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:16:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:16:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:16:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:16:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:18:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:18:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:20:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:20:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:20:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:20:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:20:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:20:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:21:24 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:22:51 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:23:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:23:00 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:23:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:23:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:23:27 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:25:12 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:26:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:26:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:28:49 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:32:58 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:36:18 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:37:15 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:38:05 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:40:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:40:32 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:40:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:40:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:40:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:40:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:41:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:41:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:41:49 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:42:24 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:43:15 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:45:00 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:45:36 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:46:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:46:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:46:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:48:25 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:49:12 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:50:15 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:51:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:51:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:51:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:51:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:52:00 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:52:40 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:53:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:53:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:54:46 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:55:38 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:57:08 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 14:57:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 14:57:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 14:59:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:01:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:01:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:01:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:01:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:03:12 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:03:42 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:04:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:04:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:06:49 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:07:58 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:10:23 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:20:11 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:22:44 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:24:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:24:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:25:29 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:28:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:28:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:30:07 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:31:22 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:32:07 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:34:43 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:35:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:35:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:36:22 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:36:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:36:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:37:39 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:37:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:37:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:37:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:37:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:38:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:38:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:38:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:38:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:38:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:39:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:39:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:40:46 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:41:07 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:42:30 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:43:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:43:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:43:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:43:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:43:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:43:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:43:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:43:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:43:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:43:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:44:39 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:45:45 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:47:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:47:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:48:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:48:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:49:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:49:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:49:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 15:49:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 15:50:35 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:54:40 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:55:26 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:56:11 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:56:12 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:56:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:58:03 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 15:59:27 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:00:35 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:01:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:01:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:01:45 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:03:33 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:04:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:06:21 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:08:56 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:10:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:10:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:10:52 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:11:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:11:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:12:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:12:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:12:31 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:13:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:13:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:14:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:14:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:14:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:14:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:15:44 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:16:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:16:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:16:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:16:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:18:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:18:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:18:33 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:18:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:18:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:20:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:20:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:20:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:20:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:21:00 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:21:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:21:09 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:23:28 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:24:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:24:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:24:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:24:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:24:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:24:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:24:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:24:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:25:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:25:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:25:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:25:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:27:48 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:29:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:29:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:30:55 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:34:04 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:34:52 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:36:33 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:39:54 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:40:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:40:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:42:18 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:44:27 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:45:40 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:47:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:47:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:47:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 16:47:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 16:48:04 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:51:20 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:52:36 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 208
ERROR - 2019-06-03 16:52:47 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:55:34 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:56:20 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:58:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 16:58:46 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:01:22 --> Severity: Parsing Error --> syntax error, unexpected ''. '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 230
ERROR - 2019-06-03 17:01:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:01:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:02:44 --> Severity: Parsing Error --> syntax error, unexpected ''. '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 230
ERROR - 2019-06-03 17:02:53 --> Severity: Parsing Error --> syntax error, unexpected ''. '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 239
ERROR - 2019-06-03 17:02:57 --> Severity: Parsing Error --> syntax error, unexpected ''. '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/o2ixr95i7zue/public_html/application/views/admin/candicateregistration/registrationreport.php 239
ERROR - 2019-06-03 17:03:09 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:04:46 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:06:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:06:01 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:06:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:06:21 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:06:40 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:07:10 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:08:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:08:13 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:08:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:08:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:08:21 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:10:14 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:25:42 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:29:00 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:30:42 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:31:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:31:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:31:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:31:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:35:16 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:36:36 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:37:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:37:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:38:13 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:39:56 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:41:36 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:43:13 --> Could not find the language line "filter_by_name1"
ERROR - 2019-06-03 17:47:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:47:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:48:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:48:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:48:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:48:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:48:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:48:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:49:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:49:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 17:54:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 17:54:14 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:01:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:01:59 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:02:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:02:26 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:02:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:02:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:03:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:03:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:03:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:03:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:05:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:05:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:05:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:05:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:07:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:07:25 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:07:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:07:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:07:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:07:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:08:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:08:10 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:12:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:12:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:21:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:21:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:22:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:22:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:30:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:30:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:50:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:50:29 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 18:58:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 18:58:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:03:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:03:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:03:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:03:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:05:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:05:47 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:25:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:25:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:26:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:26:44 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:29:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:29:38 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:35:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:35:08 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:36:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:36:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:44:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:44:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 19:52:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 19:52:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:27:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:27:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:27:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:27:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:29:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:29:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:37:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:37:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:37:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:37:51 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:42:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:42:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:43:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:43:39 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:49:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:49:18 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:49:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:49:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:59:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:59:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 20:59:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 20:59:57 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:01:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:01:05 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:02:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:02:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:11:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:11:31 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:13:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:13:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:14:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:14:03 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:14:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:14:36 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:14:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:14:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:19:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:19:49 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:30:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:30:06 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:31:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:31:54 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:33:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:33:28 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:40:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:40:58 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:42:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:42:20 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:42:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:42:23 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:43:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:43:33 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:43:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:43:40 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:47:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:47:07 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:47:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:47:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:51:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:51:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 21:56:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 21:56:35 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:06:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:06:53 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:06:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:06:56 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:07:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:07:55 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:09:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:09:27 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:11:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:11:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:12:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:12:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:12:51 --> Query error: Unknown column 'riyaantony14' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=riyaantony14 and user_credentials.password=md5('riyamca14')
ERROR - 2019-06-03 22:12:54 --> Query error: Unknown column 'riyaantony14' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=riyaantony14 and user_credentials.password=md5('riyamca14')
ERROR - 2019-06-03 22:13:12 --> Query error: Unknown column 'riyaantony14' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=riyaantony14 and user_credentials.password=md5('riyamca14')
ERROR - 2019-06-03 22:13:22 --> Query error: Unknown column 'riyaantony14' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=riyaantony14 and user_credentials.password=md5('riyamca14')
ERROR - 2019-06-03 22:13:37 --> Query error: Unknown column 'riyaantony14' in 'where clause' - Invalid query: SELECT users_info.id, users_info.application_no, users_info.f_name, users_info.m_name, users_info.l_name, users_info.phone_no, users_info.is_mobile_varified, users_info.email_id, users_info.is_email_varified, users_info.registration_step FROM users_info INNER JOIN user_credentials ON (user_credentials.user_id=users_info.id and user_credentials.is_deleted=0) WHERE users_info.is_deleted=0 and user_credentials.phone_no=riyaantony14 and user_credentials.password=md5('riyamca14')
ERROR - 2019-06-03 22:21:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:21:43 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:22:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:22:17 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:26:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:26:11 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:31:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:31:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:39:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:39:15 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:39:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:39:45 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:39:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:39:50 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:40:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:40:37 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:44:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:44:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:44:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:44:19 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:44:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:44:22 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 22:52:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 22:52:04 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:29:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:29:16 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:38:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:38:30 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:38:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:38:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:39:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:39:24 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:39:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:39:46 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:40:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:40:34 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:40:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:40:48 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
ERROR - 2019-06-03 23:40:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 59
ERROR - 2019-06-03 23:40:52 --> Severity: Notice --> Undefined variable: update /home/o2ixr95i7zue/public_html/application/views/form/index.php 61
