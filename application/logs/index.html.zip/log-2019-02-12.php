<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-12 13:14:27 --> Could not find the language line "student1"
ERROR - 2019-02-12 13:14:27 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
ERROR - 2019-02-12 13:14:35 --> Could not find the language line "student1"
ERROR - 2019-02-12 13:14:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smartschool\application\views\student\studentSearch.php 38
