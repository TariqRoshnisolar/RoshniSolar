<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-02 10:36:28 --> Could not find the language line "student_fee"
ERROR - 2019-04-02 10:36:28 --> Could not find the language line "back"
ERROR - 2019-04-02 10:39:14 --> Could not find the language line "student_fee"
ERROR - 2019-04-02 10:39:14 --> Could not find the language line "back"
