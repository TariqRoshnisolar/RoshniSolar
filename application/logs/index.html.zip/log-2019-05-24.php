<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-24 06:04:57 --> Severity: Warning --> Illegal string offset 'type' /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 62
ERROR - 2019-05-24 06:05:32 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 62
ERROR - 2019-05-24 06:07:32 --> Severity: Warning --> Missing argument 1 for Sms::sendSMS(), called in /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php on line 77 and defined /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 104
ERROR - 2019-05-24 06:07:32 --> Severity: Warning --> Missing argument 2 for Sms::sendSMS(), called in /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php on line 77 and defined /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 104
ERROR - 2019-05-24 06:07:32 --> Severity: Notice --> Undefined variable: contactno /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 106
ERROR - 2019-05-24 06:32:02 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 34
ERROR - 2019-05-24 06:32:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 34
ERROR - 2019-05-24 06:32:05 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/o2ixr95i7zue/public_html/application/models/Regstration_model.php 34
ERROR - 2019-05-24 07:03:09 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO user_credentials (user_id, phone_no, password, created_at, created_by) VALUES('164', '9968033748', md5('GjyVNXwJ'), '2019-05-24 07:03:09', 'user')
ERROR - 2019-05-24 07:12:58 --> Severity: Parsing Error --> syntax error, unexpected '$password' (T_VARIABLE) /home/o2ixr95i7zue/public_html/application/controllers/user/registration/Sms.php 83
ERROR - 2019-05-24 13:15:11 --> Severity: Warning --> Missing argument 1 for displayerror(), called in /home/o2ixr95i7zue/public_html/application/controllers/Form.php on line 109 and defined /home/o2ixr95i7zue/public_html/application/helpers/customerrorhandle_helper.php 6
ERROR - 2019-05-24 13:15:11 --> Severity: Notice --> Undefined variable: e /home/o2ixr95i7zue/public_html/application/helpers/customerrorhandle_helper.php 7
ERROR - 2019-05-24 13:15:11 --> Severity: Error --> Call to a member function getMessage() on null /home/o2ixr95i7zue/public_html/application/helpers/customerrorhandle_helper.php 7
ERROR - 2019-05-24 08:10:29 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/controllers/Form.php 199
ERROR - 2019-05-24 08:13:16 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/o2ixr95i7zue/public_html/application/controllers/Form.php 60
ERROR - 2019-05-24 08:14:20 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/o2ixr95i7zue/public_html/application/controllers/Form.php 70
ERROR - 2019-05-24 08:33:25 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting function (T_FUNCTION) /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 8
ERROR - 2019-05-24 08:34:35 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting function (T_FUNCTION) /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 8
ERROR - 2019-05-24 08:34:42 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting function (T_FUNCTION) /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 8
ERROR - 2019-05-24 08:34:51 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting function (T_FUNCTION) /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 8
ERROR - 2019-05-24 08:36:24 --> Severity: Notice --> Undefined variable: CI /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 24
ERROR - 2019-05-24 08:36:24 --> Severity: Error --> Call to a member function is_user_login() on null /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 24
ERROR - 2019-05-24 08:38:33 --> Severity: Error --> Call to undefined method Form::is_user_login() /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 26
ERROR - 2019-05-24 14:11:43 --> Severity: Notice --> Undefined variable: login_user_data /home/o2ixr95i7zue/public_html/application/views/form/header.php 217
ERROR - 2019-05-24 08:42:19 --> Severity: Parsing Error --> syntax error, unexpected ''pa' (T_ENCAPSED_AND_WHITESPACE) /home/o2ixr95i7zue/public_html/application/controllers/Form.php 182
ERROR - 2019-05-24 14:12:21 --> Severity: Notice --> Undefined variable: login_user_data /home/o2ixr95i7zue/public_html/application/controllers/Form.php 89
ERROR - 2019-05-24 08:43:17 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) /home/o2ixr95i7zue/public_html/application/controllers/Form.php 48
ERROR - 2019-05-24 14:13:48 --> Severity: Notice --> Undefined variable: login_user_data /home/o2ixr95i7zue/public_html/application/controllers/Form.php 89
ERROR - 2019-05-24 14:39:45 --> Severity: Notice --> Undefined variable: login_user_data /home/o2ixr95i7zue/public_html/application/views/form/header.php 217
ERROR - 2019-05-24 14:41:24 --> Severity: Notice --> Undefined variable: login_user_data /home/o2ixr95i7zue/public_html/application/views/form/header.php 217
ERROR - 2019-05-24 09:22:41 --> Severity: Notice --> Undefined variable: CI /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 17
ERROR - 2019-05-24 09:22:41 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 17
ERROR - 2019-05-24 09:22:41 --> Severity: Error --> Call to a member function userdata() on null /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 17
ERROR - 2019-05-24 09:23:49 --> Severity: Notice --> Undefined variable: CI /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 17
ERROR - 2019-05-24 09:23:49 --> Severity: Notice --> Trying to get property of non-object /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 17
ERROR - 2019-05-24 09:23:49 --> Severity: Error --> Call to a member function userdata() on null /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 17
ERROR - 2019-05-24 09:24:10 --> Severity: Error --> Call to undefined method Form::is_user_login() /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 27
ERROR - 2019-05-24 15:05:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:05:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:05:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:05:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:05:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:05:51 --> Severity: Error --> Using $this when not in object context /home/o2ixr95i7zue/public_html/application/helpers/custom_helper.php 46
ERROR - 2019-05-24 15:08:09 --> Severity: Notice --> Undefined property: User_authentication::$session /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 37
ERROR - 2019-05-24 15:08:09 --> Severity: Error --> Call to a member function sess_destroy() on null /home/o2ixr95i7zue/public_html/application/libraries/User_authentication.php 37
ERROR - 2019-05-24 09:38:51 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:38:58 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:39:17 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:39:43 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:39:49 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:40:01 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:40:06 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 15:11:03 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:11:03 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:11:03 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:11:03 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:11:03 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 09:41:41 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 09:41:47 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/o2ixr95i7zue/public_html/application/views/themes/default/layout.php 1086
ERROR - 2019-05-24 15:11:48 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:11:48 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:11:48 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:11:48 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:11:48 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:12:08 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:12:08 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:12:08 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:12:08 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:12:08 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:13:35 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:13:35 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:13:35 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:13:35 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:13:35 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:14:20 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:14:20 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:14:20 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:14:20 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:14:20 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:17:50 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:17:50 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:17:50 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:17:50 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:17:50 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:18:32 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:18:32 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:18:32 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:18:32 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:18:32 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:20:29 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:20:29 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:20:29 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:20:29 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:20:29 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:21:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:21:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:21:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:21:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:21:15 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:22:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:22:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:22:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:22:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:22:26 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:24:06 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:24:06 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:24:06 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:24:06 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 839
ERROR - 2019-05-24 15:24:06 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 841
ERROR - 2019-05-24 15:28:30 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:28:30 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:28:30 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:28:33 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:28:33 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:28:33 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:28:47 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 637
ERROR - 2019-05-24 15:28:47 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 639
ERROR - 2019-05-24 15:28:47 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/details.php 641
ERROR - 2019-05-24 15:43:33 --> Severity: Notice --> Undefined variable: login_user_data /home/o2ixr95i7zue/public_html/application/views/form/header.php 231
ERROR - 2019-05-24 16:23:01 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given /home/o2ixr95i7zue/public_html/application/controllers/Form.php 92
ERROR - 2019-05-24 17:01:53 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:02:09 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:02:46 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:02:50 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:02:56 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:12:14 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:20:33 --> Severity: Notice --> Undefined variable: page /home/o2ixr95i7zue/public_html/application/views/form/header.php 235
ERROR - 2019-05-24 17:28:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/preview.php 43
ERROR - 2019-05-24 17:28:14 --> Severity: Notice --> Undefined variable: base_assets_url /home/o2ixr95i7zue/public_html/application/views/form/preview.php 49
