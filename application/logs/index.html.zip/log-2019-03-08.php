<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-08 11:40:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'where mss.student_id=1
                and mss.is_deleted=0 and mss.subject_id ' at line 17 - Invalid query: select msc.subject as subject_id, subjects.name as subject_name, examforsubject.maxmarks
                from mm_subjecttoclass msc 
                left join examforsubject
                on (examforsubject.subject_id = msc.subject and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=msc.subject and subjects.is_active='yes')
                where examforsubject.classsection_id = 1
                and msc.classsection=1
                and msc.is_deleted=0 and msc.subject not in (1)UNION ALL
                select mss.subject_id, subjects.name as subject_name, examforsubject.maxmarks 
                from mm_subjecttostudent mss 
                left join examforsubject
                on (examforsubject.subject_id = mss.subject_id and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=mss.subject_id and subjects.is_active='yes')
                where examforsubject.classsection_id = 1
                where mss.student_id=1
                and mss.is_deleted=0 and mss.subject_id not in (1)
ERROR - 2019-03-08 11:44:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ALL
                select mss.subject_id, subjects.name as subject_name, examf' at line 9 - Invalid query: select msc.subject as subject_id, subjects.name as subject_name, examforsubject.maxmarks
                from mm_subjecttoclass msc 
                left join examforsubject
                on (examforsubject.subject_id = msc.subject and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=msc.subject and subjects.is_active='yes')
                where examforsubject.classsection_id = 1
                and msc.classsection=1
                and msc.is_deleted=0UNION ALL
                select mss.subject_id, subjects.name as subject_name, examforsubject.maxmarks 
                from mm_subjecttostudent mss 
                left join examforsubject
                on (examforsubject.subject_id = mss.subject_id and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=mss.subject_id and subjects.is_active='yes')
                where examforsubject.classsection_id = 1
                and mss.student_id=5
                and mss.is_deleted=0
ERROR - 2019-03-08 11:48:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ALL
                select mss.subject_id, subjects.name as subject_name, examf' at line 9 - Invalid query: select msc.subject as subject_id, subjects.name as subject_name, examforsubject.maxmarks
                from mm_subjecttoclass msc 
                left join examforsubject
                on (examforsubject.subject_id = msc.subject and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=msc.subject and subjects.is_active='yes')
                where examforsubject.classsection_id = 1
                and msc.classsection=1
                and msc.is_deleted=0UNION ALL
                select mss.subject_id, subjects.name as subject_name, examforsubject.maxmarks 
                from mm_subjecttostudent mss 
                left join examforsubject
                on (examforsubject.subject_id = mss.subject_id and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=mss.subject_id and subjects.is_active='yes')
                where examforsubject.classsection_id = 1
                and mss.student_id=5
                and mss.is_deleted=0
ERROR - 2019-03-08 15:05:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smartschool\system\database\DB_query_builder.php 683
ERROR - 2019-03-08 15:05:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `student_marks_entry` SET `is_deleted` = 1
WHERE `classsection_id` = '2'
AND `student_id` = `Array`
AND `term_id` = '7'
AND `exam_id` = '13'
ERROR - 2019-03-08 15:10:38 --> Severity: Notice --> Undefined variable: studentdata2 C:\xampp\htdocs\smartschool\application\models\Mm_studentwisemarksentry_model.php 71
ERROR - 2019-03-08 15:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\models\Mm_studentwisemarksentry_model.php 71
ERROR - 2019-03-08 15:10:38 --> Severity: Notice --> Undefined variable: studentdata2 C:\xampp\htdocs\smartschool\application\models\Mm_studentwisemarksentry_model.php 71
ERROR - 2019-03-08 15:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\models\Mm_studentwisemarksentry_model.php 71
ERROR - 2019-03-08 15:28:34 --> Severity: Notice --> Undefined variable: studentdata C:\xampp\htdocs\smartschool\application\controllers\admin\marksmanager\Subjectwisemarksentry.php 150
ERROR - 2019-03-08 15:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smartschool\application\models\Mm_subjectwisemarksentry_model.php 213
ERROR - 2019-03-08 15:28:34 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2019-03-08 15:42:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0
                from mm_subjecttoclass msc 
                left join examfo' at line 1 - Invalid query: select msc.subject as subject_id, subjects.name as subject_name, examforsubject.maxmarks, is_subject_optional as 0
                from mm_subjecttoclass msc 
                left join examforsubject
                on (examforsubject.subject_id = msc.subject and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=msc.subject and subjects.is_active='yes')
                where examforsubject.classsection_id = 2
                and msc.classsection=2
                and msc.is_deleted=0 and msc.subject not in (1,4) UNION ALL
                select mss.subject_id, subjects.name as subject_name, examforsubject.maxmarks, is_subject_optional as 1 
                from mm_subjecttostudent mss 
                left join examforsubject
                on (examforsubject.subject_id = mss.subject_id and examforsubject.is_deleted=0)
                left join subjects
                on (subjects.id=mss.subject_id and subjects.is_active='yes')
                where examforsubject.classsection_id = 2
                and mss.student_id=2
                and mss.is_deleted=0 and mss.subject_id not in (1,4)
ERROR - 2019-03-08 16:07:58 --> Query error: Unknown column 'sme.is_subject_optional' in 'field list' - Invalid query: select sme.subject_id, subjects.name as subject_name, efs.maxmarks, sme.marks, sme.grade, sme.is_subject_optional
                from student_marks_entry sme
                left join examforsubject efs
                on (efs.term_id = sme.term_id and efs.exam_id = sme.exam_id and efs.subject_id = sme.subject_id and efs.classsection_id = sme.classsection_id and efs.is_deleted = 0)
                left join subjects 
                on (subjects.id=sme.subject_id and subjects.is_active='yes')
                where sme.student_id = 2
                and sme.term_id = 7
                and sme.exam_id = 13
                and sme.is_deleted = 0;
                
