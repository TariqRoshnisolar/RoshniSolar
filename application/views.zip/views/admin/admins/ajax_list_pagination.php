<div class="col-12">
	<?php echo $this->admin_ajax_pagination->create_links();?>
</div>