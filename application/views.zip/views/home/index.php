<form method="post" action="./index.aspx" id="form1">
	<div class="aspNetHidden">
		<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
		<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
		<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="vM2G2MgoiQ7heReISEwxY7gyGAQOxQSgoUmaCUIdSuihfrxU8bpb04eb+tmT2eZnuNc38TzxgRIbna3qfRwOWv4VN9HblFtooDADtOv79aH3fmEcKI53dJcKHFFOm1M8snULi0z8BY/l77AzxbRr1MyqR3HpludZTPykSIRBkHhnteOhgHwNDywMSbT+JfOQHLWK5WpSX3SppISqrT9bOU4mzoMphJ0oLh7XwCHuDORrwkm9oGWU0tfsEMtsxH73LDavAJwaNuueC1tFWRELtTLgrkheXHg/SMMsODGQTqkS1jVuX/kCmmsSNNUE3TZbAVSsw2yRcOf8u14VfJl/0wcDhHllbm6N4UYYBqkPflRs7WXRfXGNN0OXM8Z71CSBXv//1pz+BYQg3oEuiQWzcqhkxi5bBbrnmkxmD1I/4lLctOokym8lofcTbLtODWEWI2F/VXjoESwB7UJ0RhJFP3C8HhYDLxu1ClcQBk0u8MpP5Em+6E26qhPQJCT4Ckl2+usyzD1LiVahv6QyPLBO4Z2uaLiWO87WYIlY8L3XZnsVQToioho4BdS9ApU3L3uJ7rvA+9U6oTpzm3GEVSQW9Ugoq5Wyvdpete4sKJbgptL8FV17FeexpV+4fPoCmALW+XOgBUgC3D5tizRmjyYlTNEIq8f/bdhDJfuaW04MLJGxMkCrXuEGX0+GEX8ddCX7pBZaATsY98hG9Uqo//NyQBOkAicrrjFXrZhmji4SkGL1l2Sxss+aIuzXFAlHySnbfJjLbMM8hqHrlh9Q48o+vlRJsgLRE29wFQISs3OumqKZ0f3TIGDB+tIn7fDcRMtPCjexwJpMe5koxlmz+OKaXXdXM9nDmFqG26qC6yF9yxQDzyzB76HE+pST6/Y4lalVDeL8p5jT6qmOVul/QWQp6A+zMAyN8A8ah1tOME8ZK5wof8QO3AfGedawH4PqCcGeSmi18TBY87oZBhbj7MZwBZVsy16UgpD92JkPe3KXpf6J4JlVc+BuEwjNObL2czBZnfqZmEes9sLZlp4694Q0quiCH0j0PmTb5+WEcxk0Xu3Jg/m/DDVU3Gq37o8rKv0fNlGpZ+Pdg5O4KwwffFQS8ZvdK7RzfGWxFDBatyTl0X2p717+QJWuPYn+GDRPFrQx3FOD1rzt0dn2DKYgl/icGwjKDJVglUfmNigpZBaNZZPsT3+W44UteLchcAWt8FIgoQDqbh0nts1N8S8yQeAeBqVje6NIoHR3EnxyeiPixwbm2aBlNWrlmSch3m7Pceru0Tx0BDjChtV4lUpeRe1md0ucqPvTWmIe1lykNAqz/PuxahoA/Ux+1L+TT6vFMU0qUkxqzozcIEuT/oGqrdclvepJHmWsLWor/6nkOGnREwTilUuqTF7/UIzULUms3oCO0gwGj9fEFgaVON+3iKg219R1N50KJI5bufX/RUGK6N6j+/yCHAuSqrD7D8K5AzHM7hetruU1RcMyScFOCfjh5QUXIEVD8NU57dUPY7oqFB2T6SxrC6i0ON1UZ63YnAZskUh3Wny5K1S4bFKam6hDUSKBkyi9rV5I6hop3YHz0IuXXVvgRkiQVxbhgoUhso0ctCaduhFlGFBl+wTxdWuj8nEGXM6ZyAt39f//ecfwUwM+gQgy5mK+sWgQLo67L1Ats4VFevxqvhGBQRvNGKbM2Tfn+w1qrXdQ8m/s0NFY4sjeQu22dcCs2z6Wd9+xSYgT0wDPNIHgmATJwYIGGsUvYw6+gPpSVRwRvGG7ZctbBeqL7VwBE3l+0c8gwdyuyehDiuAUH9/woUAQcPirsWD7F6wuH/EQ5P3jha3saynZej2v6L9p2PwXQHhmSd2ROGIJs2PbNS6RaWu+4M3kE2wqWNJRoyruYAPoz6TDkGGZxIYNJAZ20izBp7rSmoJuJzx6VEBEbGjjl1Ucc+YwTSiD1qcPTjfH1YfmoOsVd4pJhg2gB1G7150qu6pjEZ7ODheuXrbX0YSxgAVvfKNgJvzCKUOMlAro+J9Jcwz84cGrSa4LrOzdFWuhzPSiEV2YP3mMvLw7vt1wra3wfpT5vwZ32BdNn+YwA6fxryv/M/3i1QoJUtbG1NpRZOKLqBDwArGtlxQD5+lsyS8MvMMuE6pVkeyPCjYDrt4NtKr5R2S9Ihuf7qijL3+fJqnFmDpQq5dQi9zaJbkjVvy5sCgS4p29fl8dyq6SoymzirEH9ku4h9Muv6vAyJGdv4Im66uzXPx9UZBiHHQzThOPvAX48InlYGujz2niCHsTQgx/KdBhPr0hGGdhIMdLf8suYEUAlpfXCJAegeJkHZ81FrYucjdJ9sgALDK/JbTK/hdxCzEUCuWDvuheMlM/tSRQNd5quQiFMLSCO1bvZanLsSpsTddr7t2D9k6+1kpJC5034vuGZ4utZetfApaobEM4303QVaJMxD2WUBKQKAZEOnkZgPZN9vXPRoewJf01HArwCHQHSMeEGfmXOE5sqdhxyAgTQFwNz3hNfhmOufM1xPSfs/Nw/5mzcKWaLVyZBqeXlGwDkonmtc66OoXd5+0niGp1hqBpBwDh8Fa7y0+VcB2oahN+h3//H7v1pmb397u5F7tys/TjM1ndBOmQaMz6DEFxxuPEvJrvXL1tURfLyasA2n4r1/5JAr0148h1MML1eQH0l3JExRU3Slah1rE/ZAZ8HflH8WMTIXk4Nl1bprvST56kJ1RWdQeppWjKOMDQKRAsmgQrwUi4lHrRHiOCDtZeqN0W2oOMJqEhYVJ5R93dE7Of90crY76oa2yQGZfysWmzqa3slBbXF5QZgf9HzokUvJoDPccE8SOor8gLcmpJekpo9noBJWu2HZMkYY6FpykW8sdhKUOFy+2OTg10x78gDWB9goQTtDjICn9waUc/ZhkVQ1U3/yi6q9xLBKZV+j8yCgIVQe9+unZqiIWZLTMSlMnflRzOjmC5N4jP4v87qXWg27rYumYIRlLgmjHLe9fBxW+RKfgJRrpzPig4L8/0UBddBEazYJhDc5sC1YHv2BKblGQ08OTxQ50UQIyOv9arJFHhggbLcf1nB6HsDQ0C6yoYxaSX6VkoQQIYsM7zcQlLP1sGcb2+7yJwAW2FVAJGVJJ2KAjryTFriqbwD1B3nu9avg7oMtU8WsU0fuIyPBGGJV0n4epdPurj7doiPO16yd1Zummp1OozYi7tEfq3PZRAd1woT3j7VOETFY7VxElxsgL0aGgx6rOE+xUAMdnXIFa3rhkPziA5Pk2kwHf+ECMK4sF+xmwtGkEjRtI3fk7ibAofamwvQUEV38LLQybuKdsKdmrawRj4OVwTUe1zA63BKUJ8lBUvMbFrntpiQ1/serTDd/wdGKlz6/sQFwT8OdcXIEZ4LeBA5uMyP1ZCtpWWC4WkaM+EoKD/bs76a7UHNWHOzT6+dBvhcOtjebWXjXxloLOWskXsjc5i5qvTIeFRqxhOrBPYpHc/x86UObzOm83Gkyo09CzCg8qDuiReFN2JW59OY6IBK+cop2K9ST+A42YYmGPN9WMEPyb1P3AjbyEIHNkktvsnL9/7UmfcSs2oC5L4d4ubd0UTKsmA1ck//hEUSX6Yjo2b4+y/zvj9WX7FTUQwMhU14ktIOQtbEMBfPbK3u4vHxtKTezFPPbEEQqfIZ21aPcFmmhlU0+nCOr1WDuSxxrCDll9iLyMobWqBCWsE7t1Ztl4zwWw1QMof9ELrTS3jKxGZzCvuojTuR79VkOqik12kXDvaV4t0CiIFVIng30cK+33ipYei5TkNBgZZlN+JpUuvSjl/cjqa9DV6xliK14h8hGTZ3cHcMJmOZxwrgGn1HHhP3slU5vBfb3CFofC6FV0R7b7XFWQS6nTSQEwcXofCxNIsNt7u1E1Vs+0qZ2806TEKckH84yKrvZ3bSSOlb3x7Mst/VfDA4mS+HN3/Eya9UfSwu6uy37PVgUPVjG9QKvFxdBagpA4WYfUtE/pqg/bVyKV3WresRxWQRSHw3Z12Hvr6bBLJ/WUyAtIHMh20Ar6sTppXkR/B1sleCpkZAM1B0z+ZWP1Hokbl6dF/NwRp7CVzFZTMTa4SwVh10hzOMCxPZQO2pIVp3zUoY9vTr54s/ZFdSMn5CAXPXOTfLzZKb3oYcWqp1Gl1+BojVPlQoSF5YlPYTX09iMYY/+cTQwZfqYKjdmH/2Nteuf9mcASWU6oDcWUzxb27FlkdpP7om/IK4jqVERpeGyCDAgO5TM/l0FocAOQyOzp6c+58bWVNxI/inJo0i4KgpjX6ItEPiHmRQfqWQqmd3gTpw4Z3gqEprJZzj42Z01LSLpifTbddoZtmwIuv7I7j2G7qfgv7gkG/5LvRyLoSKBHNo8F/tATs5U3fLiCk7qWs7EkBi1IWsVXMwVDNiUbZEwrILu+isrqm7KOlTO0psoDY8hn3iywuYoeNUi0JcrEJ97SbwKT5H9Xbygl8U6hFpUARiJfsEtJ86VB0plBVuuAVHLkTSXot2YcQtLihcewThcBhvQodnfKS6AjoAvjH9hJb8AnmK/8G6Ib+2h4vkHKHPTGmwQINZusD+4fIihlBAlfe9bxufwId3LH7QlXJdkF1a/bPaLi2QRJCDNGuqL0rZ4uGop7DnI0VheSr0lQ4pxaXQB5G8O7+gOT5C7Z5eDWc6B5jZAIKRTFSLZy+fT1YM7kTGgtzmViWPeHIIc05KeTF9mGk2paxQRYElJ33OF0rSYXHtbSjHmiBaHXP6xXhRAGz/WsrflqffWORqgbm/z8C0m1e8VocRPvHWVW5iIl3UTWxHZOgMdaeC4ixW8DSTBcbaWY9VJaUkNSHvW1qVshYF0KJJRNZK7ICxNc1NO2r6KuZZuuAt6l40CZfDYZhZQgAZEDYM5gtnB/d4sg3Ke7Q1iyH+UWzmEVOTb1fArQpYMzDN1Is0JL66rVrDkC8GG6ykyHV/JY6zKGiKaVdLowP3QWowwRkQLWdjmSaYb5eKQ3wApSBoOKmIE5V1e3TJbfqyvQdmKbqow6UEKxAvt4J1edWzY6ICXiWdod2UBz3fHM2LZ11Gs3GdmRj98jbT0t/3fEbFPuc9TJeHiQXb7eGFUDhPDQd9Vw62OmA1/I0eM2usmbStl1p0VYOrU2VSMS5YZPRTJwLQgQ62s8t1hX41uplhkDfkAqCB13MMDMwhCgqV9hPDeDQudMgiqGX/lng2Y+fgEFNe0I145qQzZFH/JLKxPVmDCDxiLQyT07lIxOrtHcNJg2CYV8jfH1QAzxf1nIBAhQONcvi5YgAELlG8egI/PwExONaNEkRJTzZW13GC+ZyhMslLJ7SMnvvzoVB4Je2VRV6eJ0FWBoNJ4b0YObq0rfSJESjcfbOTGsIt6fjlRyfn7HHO0ciXwDTs9qzzvwgML7Q3Jac1lW7Oqiv6o/gIO3DkrxHBzqp86Y08GcHbErtV7I8Ja44sGUiARitiI6X5jYJinNHpul0ftHbK7NyO9hz/MzJD71T2HRRZ+h2qbb3Ap33OdhovsoL1G7vK5pM/2OjcmVZnQyEfpgcJ8MXfj5+yE6MUwJQCK0yPw1H9NGDC+K67wmN+ZlwcwOQBf87rbfso6lcdi9urBLkfk7J/Yo61Wz5+aS+yOAjdUKv8XzO1sbdCeGQ6fyUd+5NYG/Zh4gmFGaxQT4Xo/qQpdvKu6biNtOEk5K5jGtMIioqCRJ3bQbsV8JWVf9RE1H/ng50S5J4vdbckmgXqMo30fDYpHvh41iKL+NURDQWAZLqtSt47goWpkew+PM0nZ2d2mvSS0ivIcq0nWpVvdBz2slAVl3V1LVrI7h4JQKWbebjCBRRmqNqNOGZE8/Nmx78GFYLU5YSmeYAu4jOWCuAnNl1pDmcEXgj1kgR2n2LELdqeimV4+TKy8yu/kBM4y1BNsvN156RoicqrGLfZAb+M8kZsW1qUKAkCUuBOoidwH+gmB9CRrVPOoJ6" />
	</div>

	<script type="text/javascript">
		//<![CDATA[
		var theForm = document.forms['form1'];
		if (!theForm) {
			theForm = document.form1;
		}
		function __doPostBack(eventTarget, eventArgument) {
			if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
				theForm.__EVENTTARGET.value = eventTarget;
				theForm.__EVENTARGUMENT.value = eventArgument;
				theForm.submit();
			}
		}
		//]]>
    </script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZAn0GY69x6fFVGAZE00KwsLKlZk0jk-y9I3eMFPVDIJO4CQloC0oT_HxquFSVtCOlA2&amp;t=635793216349294682" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=uHIkleVeDJf4xS50Krz-yJisvXuHyHXu5jZ3KMwbBiQ4I6unIoRh0ex9n1KFDbQRdmw1Fmh7IwJYC5Yjk44QBImZTrIcUutmSiVCHLBw5jOlaposkXLGkLIWw1_iNNzejI9DXphetniXrYqL2V4FoEhX-2Zcs0NeQbDElGXe6lc1&amp;t=72e85ccd" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=Jw6tUGWnA15YEa3ai3FadGjAnQH5-8DFFfgd1AZJuo7YKDMQmnyKgRste-AV_bYiAfI6xynwDOfCm1HegFoxYiZPwk9sl5MUZ8tUBSPauqKNJ4yyCw6wWk_N9eCMsFVcsGTDDqzM54ojzjWaLxsVw_33ywMiiLhFqljoo5wdjZk1&amp;t=72e85ccd" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="90059987" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="gLhB2TiffMMNm/sqpwOfhpQBzEl4lWKAS9IhTcJwMGuNxM0SESJWNOCN7cSclndm6HV+LCR0LM68D62RUGxnvGZitxISeVq0wiq0Q0EnXT5Z/wrki5OikInNULebtRKHqxeLmSpLZDf1YoRwitjjpauDq+P4GlvLcW8tSPKk5PR4Xew3vOvGAC0mja4QVKw+gcilMN5UwZADyQ4WxpHN3wacakv4Ro/Z/aHkoLAKsgGvMeAsf9lLm4dBOuz4hQHsJyG9zT4hmpqubeLydIGTAKzHTXF89WfSL1UTkEjsdBzNSxwc610wAf+NnAlao1EB2nVQlyO6QCzkH1BKG6rBPiVFQ1rIYDbgM1CYNgkJX/SHmX+U40JpRH2cEW+uhFO43PUw4FWZtaCOfCcm3so357RQSLDYNMXd+6aMHNHPz0wLqAWpmJJ6f80hPkw555+OmHXKz6bcY7ee34wTkpqcBlYzdp9FjwXvRIoJKUgF8NS3r8UgC/rZ1W80JuvCqROjsBnzmWUyn9gzyynhChha/MYQuVCGwK2TAFtNUGeybe4wIV7wsrElhUrutHDwuNwU0ss6MjuPpSPwDYzUKCooOUHsijjQlLIeSVpxTXpgBA6fy1ukToXvJuythqxspRV1ASE11o2UIq1P9QqqTc1H5tfBXvKvFvzBgjG5Ai2MUbUxeZY9hiQW0V0YIEmmukq6TWYQDQYaJwkf57PihlwPNG4L4N0v/qW3dEFJKZcPl9xAIw9ibinXQgEhueW/tVXL8fc/W7GLQGckt0P2Go2e4UKEl5ZbzcbaMMrSoOr6uVBQzyzgBgL3V/GIpOTKZqiNzypPDwvoazmcrD5Be4p6F0FipIVe3rmAeVSLYpYN6hzdotLt7p8KLlsWzIi77nQRJ9fr8kqzOIQc02keJRO0kw3KD2ksAF3h10D03SHgNsZ6zvJly6gDc6XDjQGQ+tZpg7zZTXGW8RreVk4zxa6XvQ==" />
</div>
<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', [], [], [], 90, 'ctl00');
//]]>
</script>

<div>
	<div class="row head oth_border" style ="background-color:black; margin-left:0px;margin-right:0px">
		<div>
			<div class="col-md-1"></div>
			<div class="col-md-2">
				<a href="#main_content"><label class="skip skip_border"> &nbsp;&nbsp;Skip to main content &nbsp; &nbsp;</label></a>
			</div>
			<div class="col-md-4"></div>
			<div class="col-md-3">
				<input type="text" class="search_textbox" id="search_textbox" name="search_textbox" placeholder="Search- Keyword, Phrase" style="color:#000;">
				<img src="<?php echo base_url(); ?>assets/front/anandadhara/images/search_24.png" class="img in_search" title="Content Search" style="height:auto; width:5%; cursor:pointer;">
				<a href="http://www.google.com/search" rel ="noopener noreferrer" target="_blank" title="Google Search"><img src="<?php echo base_url(); ?>assets/front/anandadhara/images/google_24.png" class="img" style="height:auto; width:5%; "></a>

			</div>
			<div class="col-md-1" >
				<a href="../ProtectedPage/Login.aspx"><label class="skip">Login</label></a>
			</div>
			<div class="col-md-1">
				<input type="button" id="btnincfont" value="A+" style="font-size:.8em" />
				<input type="button" id="btndecfont" value="A-" style="font-size:.8em" />
			</div>
		</div>
	</div>


	<div class="col-md-11" style ="background-color:White;margin-left:4%; margin-right:4% ">
		<!--end of header-->
		<div class="container" >
			<div class="col-md-12" >
				<img class="img-responsive" src="<?php echo base_url(); ?>assets/front/images/TC_KOB.png"  height="152px" />
			</div>
                <!--<div class="col-sm-3">
                	<div class="support">
                		<i class="fa fa-envelope"></i> wbprd@gmail.com <br>
                   	 <i class="fa fa-phone-square"></i> 1234567890
                    </div>
                </div>-->
            </div>

            <nav class="navbar navbar-default" role="navigation">
            	<div class="container" style ="background:url(<?php echo base_url(); ?>assets/front/images/bg-noise.png) repeat-x; color:white">
            		<div class="navbar-header" >
            			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            				<span class="sr-only">Toggle navigation</span>
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
            			</button>

            		</div>
            		<!--/.navbar-header-->

            		<ul class="nav navbar-nav" >
            			<li ><a href="<?php echo base_url(); ?>">Home</a></li>
            			<!-- <li><a href="../ProtectedPage/wb_dictor.aspx" rel ="noopener noreferrer">Panchayats Directory</a></li> -->
            			<li class="dropdown">
            				<a href="" class="dropdown-toggle" data-toggle="dropdown">Schemes<b class="caret"></b></a>
            				<ul class="dropdown-menu">
            					<li><a href="../HtmlPage/srd_HomePage.aspx" rel ="noopener noreferrer">SRD</a></li>
            					<li><a href="../anandadhara/index.aspx" rel ="noopener noreferrer">Anandadhara</a></li>
            					<li><a href="../HtmlPage/sahay_homepage.aspx" rel ="noopener noreferrer">Sahay</a></li>
            					<li><a href="../HtmlPage/STARDPARD.aspx" rel ="noopener noreferrer">Starpard</a></li>
            					<li><a href="../HtmlPage/PMGSY.aspx" rel ="noopener noreferrer"> PMGSY</a></li>
            					<li><a href="../HtmlPage/RHOUSING.aspx" rel ="noopener noreferrer"> Rulal Housing</a></li>
            					<li><a href="../HtmlPage/SSECURITY.aspx" rel ="noopener noreferrer">Social Security</a></li>
            					<li> <a href="#" target="_blank" >ISGPP</a></li>
            					<li><a href="../HtmlPage/Chcmi1.aspx" rel ="noopener noreferrer">CHCMI</a></li>
            				</ul>
            			</li>


            			<li><a href="#">Acts & Rule</a></li>
            			<li class="dropdown">
            				<a href="" class="dropdown-toggle" data-toggle="dropdown">Organisations & Offices<b class="caret"></b></a>
            				<ul class="dropdown-menu">
            					<li><a href="#" rel ="noopener noreferrer">Directorate</a></li>
            					<li><a href="#" rel ="noopener noreferrer">WBSRDA</a></li>
            					<li><a href="#" rel ="noopener noreferrer">WBSRLM</a></li>
            					<li><a href="#" rel ="noopener noreferrer"> PBRSSM</a></li>
            					<li><a href="#" rel ="noopener noreferrer">WBCADC</a></li>
            				</ul>
            			</li>
            			<li><a href="#" rel ="noopener noreferrer">Finance</a></li>
            			<li><a href="#">Photo Gallery</a></li>
            			<li><a href="#" rel ="noopener noreferrer">Press & Media</a></li>
            			<li><a href="<?php echo base_url(); ?>page/contact-us" rel ="noopener noreferrer">Contact Us</a></li>
            			<li class="dropdown">
            				<a href="<?php echo base_url(); ?>page/contact-us" class="dropdown-toggle" data-toggle="dropdown">Contact Us<b class="caret"></b></a>
            				<ul class="dropdown-menu">

            				</ul>
            			</li>
            		</ul>
            	</div>
            	<!--/.navbar-collapse-->
            	<!--/.navbar-->

            </nav>
            <!--Navbar-->
            <!--/.Navbar-->
            <!--/start-footer-section-->
            <script type="text/javascript" src="<?php echo base_url(); ?>assets/front/js/crawler.js"></script>
            <script type="text/javascript" src="<?php echo base_url(); ?>assets/front/JS/interface.js"></script>

            <script type="text/javascript">

            	$(document).ready(
            		function () {
            			$('#dock').Fisheye(
            			{
            				maxWidth: 50,
            				items: 'a',
            				itemsText: 'span',
            				container: '.dock-container',
            				itemWidth: 40,
            				proximity: 25,
            				halign: 'center'
            			}
            			)
            		}
            		);
            	</script>
            	<style type ="text/css">
            		.news_marquee {clear:both; margin-top:30px; background:#fff;  /*border:6px solid #99ccff; */border-radius:14px;  line-height:normal; padding:0; float:left; }
            		.news_marquee h2 {float:left; width:107px; background:url(../images/marque_arrow.png) scroll right center no-repeat; color:#FFF; margin:0; padding:14px 19px; }
            		.news_marquee marquee {/*width:90%*/; padding:32px; margin:0 14px; }
            		.icon_scroll {clear:both; margin-top:30px; background:#fff; border-radius:14px; padding:20px; }
            		.icon_scroll li {display:inline-block; margin:0 20px; }
            		.icon_scroll li a {display:inline-block; text-decoration:none; }
            		.leftbtn {background:#000 none repeat scroll 0 0; margin:15px 0 0; padding:0; text-align:center; }
            		.leftbtn.photo_gallerybtn a {background:#79bb5a url(../images/photo_gallery_icon.png) no-repeat scroll left 30% center; color:#fff; display:inline-block;  font-style:italic; font-weight:700; line-height:21px; margin:auto; padding:4% 0 4% 7%; text-align:center; text-decoration:none; text-transform:uppercase; width:100%; }
            		.right_col h1 {background:#d8d9db; border-radius:3px; padding:5px 20px; margin:0px; }
            		.right_col p {font-family:arial;  line-height:22px; padding:5px 20px; margin:5px 0; }
            		.img {
            			max-width: 100%;
            			height: auto;
            			width: auto;
            		}
            		.tabcontainer{
            			width: auto;
            			margin: 0 auto;
            			height: 320px;
            			/*border: 1px solid blue*/
            		}
            		ul.tabs{
            			margin: 0px;
            			padding: 0px;
            			list-style: none;
            			border: 1px solid #ffffff;
            			background-color: #6699ff;
            			overflow: hidden;
            		}
            		ul.tabs li{
            			background: none;
            			color: #ffffff;
            			display: inline-block;
            			padding: 10px 15px;
            			cursor: pointer;
            			float: left;
            			border: 1px solid #ffffff;
            		}
            		ul.tabs li.current{
            			background: #0066cc;
            			color: #222;
            		}

            		.tab-content{
            			display: none;
            			padding: 8px 15px;
            			border: 1px solid #0066cc;
            			border-top: none;
            		}

            		ul.tabs li a {
            			display: inline-block;
            			color: white;
            			text-align: center;
            			padding: 5px 12px;
            			text-decoration: none;
            			transition: 0.3s;

            		}

            		/* Change background color of links on hover */
            		ul.tabs li a:hover {background-color: #0066cc; color: black;}

            		.tab-content.current{
            			display: inherit;
            			background-color: #ffffff; color: black;
            		}


            		/* Style the tab content */


            		.auto-style1 {
            			width: 106%;
            		}


            		.auto-style2 {
            			height: 19px;
            		}
            		.auto-style3 {
            			width: 106%;
            			height: 29px;
            		}


            	</style>



            	<script type="text/javascript">
            		marqueeInit({
            			uniqueid: 'mycrawler1',
            			style: {
            				'padding': '2px',
            				'width': '1150px',
            				'height': '150px'
            			},
        inc: 5, //speed - pixel increment for each iteration of this marquee's movement
        mouse: 'cursor driven', //mouseover behavior ('pause' 'cursor driven' or false)
        moveatleast: 2,
        neutral: 150,
        savedirection: true,
        random: true
    });

</script>

<script type="text/javascript">
	$(document).ready(function () {

		$('ul.tabs li').click(function () {
			var tab_id = $(this).attr('data-tab');

			$('ul.tabs li').removeClass('current');
			$('.tab-content').removeClass('current');

			$(this).addClass('current');
			$("#" + tab_id).addClass('current');
		})

	})
</script>


<script src="../js/js_UZ2dEg3PHUf1pm3YZ75gWIfbfijkws7bpwZZ-DCkGcM.js.download"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/front/CSS/merquee_css">

<script src="<?php echo base_url(); ?>assets/front/sliderengine/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/front/sliderengine/amazingslider.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/front/sliderengine/amazingslider-1.css">
<script src="<?php echo base_url(); ?>assets/front/sliderengine/initslider-1.js"></script>

<script src="<?php echo base_url(); ?>assets/front/centrejq/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/front/centrejq/amazingslider.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/front/centrejq/amazingslider-3.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/front/CSS/stylefooter.css">
<script src="<?php echo base_url(); ?>assets/front/centrejq/initslider-3.js"></script>

<div class="container"  >

	<div class="col-md-12" >
		<div class="slider" >
			<div >
				<div id="amazingslider-wrapper-1">
					<div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
						<ul class="amazingslider-slides" style="display:none;">
							<li><img src="<?php echo base_url(); ?>assets/front/images/1.jpg" alt=""  title="" />
							</li>
							<li><img src="<?php echo base_url(); ?>assets/front/images/4.JPG" alt=""  title="" />
							</li>
						</ul>
						<ul class="amazingslider-thumbnails" style="display:none;">
							<li><img src="<?php echo base_url(); ?>assets/front/images/1.JPG" alt="" title="" /></li>
							<li><img src="<?php echo base_url(); ?>assets/front/images/4.jpg" alt="" title="" /></li>
						</ul>

					</div>
				</div>
			</div>


		</div>
	</div>
	<!--//end-banner-->
	<!--/start-main-->

	<div id ="fontdiv" style ="font-size:14px"> 
		<div class="col-md-12" style="margin-top:12px">
			<div class="col-md-3 mag-innert-left">
				<div class="stay" style="height:auto; border: 1px solid #0066cc;">
					<ul>
						<li class="c5-element"><a href="<?php echo base_url(); ?>page/minister" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-user"></i></span><span class="text">Minister</span></a></li>
						<li class="c5-element"><a href="<?php echo base_url(); ?>page/prsecy" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-user"></i></span><span class="text">Secretary</span></a></li>
						<li class="c5-element"><a href="<?php echo base_url(); ?>page/prsecy" rel ="noopener noreferrer"><span class="icon icon_big"><i class="fa fa-users"></i></span><span class="text">Key Officials</span></a></li>
						<li class="c5-element"><a href="<?php echo base_url(); ?>page/prsecy" rel ="noopener noreferrer"><span class="icon icon_big"><i class="fa fa-users"></i></span><span class="text">Organogram</span></a></li>
						<li class="c5-element"><a href="<?php echo base_url(); ?>page/rti" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-file-text"></i></span><span class="text">RTI Act</span></a></li>
						<li class="c5-element"><a href="SAU/index.aspx" rel ="noopener noreferrer" target="_blank"><span class="icon"><i class="fa fa-file-text"></i></span><span class="text">Social Audit Unit</span></a></li>
						<li class="c5-element" style="margin-bottom: 0"><a href="HtmlPage/samacharPatraIndex.aspx" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-server"></i></span><span class="text">Panchayati Raj </span></a></li>
						<li class="c5-element"><a href="../HtmlPage/Notification.aspx" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-link"></i></span><span class="text">Notifications</span></a></li>
						<li class="c5-element"><a href="<?php echo base_url(); ?>page/recruitment" rel ="noopener noreferrer"><span class="icon icon_big"><i class="fa fa-area-chart"></i></span><span class="text">Recruitment</span></a></li>
						<li class="c5-element"><a href="EODB.aspx" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-file-text"></i></span><span class="text">Ease of doing Business</span></a></li>

						<li class="c5-element"><a href="../HtmlPage/IFMS_homepage.aspx" rel ="noopener noreferrer"><span class="icon icon_big"><i class="fa fa-bar-chart"></i></span><span class="text">Panchayats Accounts</span></a></li>
						<li class="c5-element" style="margin-bottom: 0"><a href="#" rel ="noopener noreferrer"><span class="icon"><i class="fa fa-server"></i></span><span class="text">SECC and NSAP</span></a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-9">
				<div class="col-md-8" style="padding: 0">
					<div class="mag-innert-center">
						<div class="tabcontainer">
							<ul class="tabs">
								<li class="tab-link current" data-tab="tab-1">Schemes</li>
								<li class="tab-link" data-tab="tab-2">Galary</li>
								<li class="tab-link" data-tab="tab-3">Videos</li>
							</ul>

							<div id="tab-1" class="tab-content current">
								<div id="amazingslider-wrapper-3" style="display:block;position:relative;max-width:540px;margin:0px auto 0px;">
									<div id="amazingslider-3" style="display:block;position:relative;margin:0 auto;">
										<ul class="amazingslider-slides" style="display:none;">
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (1).jpg" alt="01"  title="01" />
											</li>
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (2).jpg" alt="02"  title="02" />
											</li>
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (3).jpg" alt="03"  title="03" />
											</li>
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (4).jpg" alt="04"  title="04" />
											</li>
										</ul>
										<ul class="amazingslider-thumbnails" style="display:none;">
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (1).jpg" alt="01" title="01" /></li>
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (2).jpg" alt="02" title="02" /></li>
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (3).jpg" alt="03" title="03" /></li>
											<li><img src="<?php echo base_url(); ?>assets/front/images/Pix_13_Wbsrlm (4).jpg" alt="04" title="04" /></li>
										</ul>
										<div class="amazingslider-engine"><a href="http://amazingslider.com" title="Slider jQuery">Slider jQuery</a></div>
									</div>
								</div>
							</div>
							<div id="tab-2" class="tab-content" style="height:270px" >
								Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</div>
							<div id="tab-3" class="tab-content">
								Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
							</div>


						</div>
					</div>




				</div>
				
				<div class="col-md-4 mag-inner-right" >
					<div class="stay" style="height: 332px; border: 1px solid #0066cc; ">
						<h3 class="tittle bottom "><i class="fa fa-bell"></i> Latest Notifications</h3>
						&nbsp;
						<div  style="overflow: hidden; position: relative; width: auto; padding-right:15px; height: 246px; clip: rect(0pt, 367px, 420px, 0pt);
						background-color: rgb(255, 255, 255); top: 0px; left: 0px;">
						<marquee direction="up" scrollamount="2" onmouseover="this.stop()"   onmouseout="this.start()">
							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_0" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl00$LnkRptr11&#39;,&#39;&#39;)">16/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_0" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl00$LnkRptr12&#39;,&#39;&#39;)">Transfer order of Joint BDO</a>
							</div>
							<hr />

							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl01$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl01$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for Re-excavation of Sabarika pond at Kumari Kanan farm under WBCADC, Ajodhya Hills Project</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_2" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl02$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_2" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl02$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of concrete road at Baruipara farm under KVK, Sonamukhi dist Bankura</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl03$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl03$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction for Extension of Piggery Demonstration under WBCADC KVK Sonamukhi Dist - Bankura</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_4" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl04$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_4" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl04$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of Boundary wall including retaining wass at office complex under WBCADC Kalimpong.</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_5" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl05$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_5" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl05$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for installation for 2 nos. MDTW at Baruipara farm</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_6" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl06$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_6" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl06$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for supply fitting &#38 fixing of 6 nos. high Mast flood light.</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_7" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl07$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_7" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl07$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of mushroom spawn production unit at Satvaiya Farms under WBCADC Siliguri Naxalbari project</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_8" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl08$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_8" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl08$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of road with gate at WBCADC  Deganga project dist North 24 Pgs.</a>

							</div>
							<hr />


							<div  style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr11_9" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl09$LnkRptr11&#39;,&#39;&#39;)">11/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater1_LnkRptr12_9" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater1$ctl09$LnkRptr12&#39;,&#39;&#39;)">Transfer Order of  Jt. BDOs</a>

							</div>
							<hr />

						</marquee></div>

					</div>

					

				</div>

				<div class="col-md-8" style="margin-top:10px; margin-top:2px;padding-left:0px !important">
					<div class="stay" style="height: 210px; border: 1px solid #0066cc; margin-top:5px; ">
						<h3 class="tittle" ><i class="fa fa-line-chart"></i>Recruitment</h3>
						<div style="">
                                          <p style="font-size: 15px;margin: 0px 0px 0px 12px;">Recruitment of west bengal rural development department group d post on regular basis</p>
                                          <a href="<?php echo base_url(); ?>assets/front/notification/WBRDD NOTICE 1.pdf" target="_blank"><p style="font-size: 15px;margin: 0px 0px 0px 12px;">Notification No: WBRDD/06/2020 WB </p></a>
							<a href="<?php echo base_url(); ?>index.php/form"><p style="font-size: 15px;margin: 0px 0px 0px 12px;">Apply online</p></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 mag-inner-right">
					<div class="stay" style="height:210px; border: 1px solid #0066cc; margin-top:5px; ">
						<h3 class="tittle bottom" style="background-color:#0066cc;"><i class="fa fa-envelope"></i> Tender</h3>
						<div style="overflow: hidden; position: relative; width: auto; padding-right:15px; height: 160px; clip: rect(0pt, 367px, 420px, 0pt);
						background-color: rgb(255, 255, 255); top: 0px; left: 0px;">

						<marquee direction="up" scrollamount="2" onmouseover="this.stop()"   onmouseout="this.start()">


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_0" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl00$LnkRptr11&#39;,&#39;&#39;)">16/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_0" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl00$LnkRptr12&#39;,&#39;&#39;)">Transfer order of Joint BDO</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl01$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl01$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for Re-excavation of Sabarika pond at Kumari Kanan farm under WBCADC, Ajodhya Hills Project</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_2" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl02$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_2" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl02$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of concrete road at Baruipara farm under KVK, Sonamukhi dist Bankura</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl03$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl03$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction for Extension of Piggery Demonstration under WBCADC KVK Sonamukhi Dist - Bankura</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_4" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl04$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_4" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl04$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of Boundary wall including retaining wass at office complex under WBCADC Kalimpong.</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_5" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl05$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_5" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl05$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for installation for 2 nos. MDTW at Baruipara farm</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_6" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl06$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_6" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl06$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for supply fitting &#38 fixing of 6 nos. high Mast flood light.</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_7" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl07$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_7" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl07$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of mushroom spawn production unit at Satvaiya Farms under WBCADC Siliguri Naxalbari project</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_8" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl08$LnkRptr11&#39;,&#39;&#39;)">12/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_8" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl08$LnkRptr12&#39;,&#39;&#39;)">WBCADC invites a tender for construction of road with gate at WBCADC  Deganga project dist North 24 Pgs.</a>

							</div>
							<hr />


							<div style="border: medium none ; width: auto; "  align="justify">
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr11_9" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl09$LnkRptr11&#39;,&#39;&#39;)">11/03/2020</a>
								<br />
								<a id="ContentPlaceHolder1_Repeater2_LnkRptr12_9" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Repeater2$ctl09$LnkRptr12&#39;,&#39;&#39;)">Transfer Order of  Jt. BDOs</a>

							</div>
							<hr />

						</marquee>
					</div>
				</div>


			</div>    


		</div> 
		<div class="clearfix"></div>	

		<div class="col-md-12" style="margin-right:10px; margin-top:0px;padding-left:0px !important">
			<div style="text-align:center" >

				<p style="text-align:center">  <img src="<?php echo base_url(); ?>assets/front/images/blink_star.gif" alt="" height="30px" width="30px" /><a id="ContentPlaceHolder1_LinkButton3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$LinkButton3&#39;,&#39;&#39;)" style="text-align:center;font-size: .8em; font-family:Helvetica, Arial, Verdana, sans-serif; color;font-weight:bold ;color:#522E26;text-decoration: none;">BLIND AND VISUALLY IMPAIRED USERS CAN READ THE WEBSITE USING THIS SOFTWARE (32Bit/64Bit)</a><img src="images/blink_star.gif" alt="" height="30px" width="30px" /></p>
			</div>               


			<div style="width:auto; overflow: hidden; position: relative;  height:130px; margin-right: 0px !important; background-color:#80aaff">
				<a href="https://gis.wbprd.gov.in/secured/home.jsp">
					<img class="img" style="margin-left:10px; margin-right: 8px; padding-top: 12px; width:145px;height:118px "
					src="<?php echo base_url(); ?>assets/front/images/isgpp_1499240704_280.png" alt="ISGPP" title="ISGPP"/></a>
					<a href="#">
						<img class="img" style="margin-left: 3px; margin-right:8px; padding-top:12px;  width:145px;height:118px" 
						src="<?php echo base_url(); ?>assets/front/images/WBPMGSY1.png" alt="PMGSY" title="PMGSY" /></a>
						<a href="https://nrega.nic.in">
							<img class="img" style="margin-left: 3px; margin-right:8px; padding-top:12px;  width:145px;height:118px" 
							src="<?php echo base_url(); ?>assets/front/images/title_logo.png" alt="NREAGA" title="NREAGA" /></a>
							<a href="https://aajeevika.gov.in">
								<img style="margin-left: 3px; margin-right:8px; padding-top:12px;  width:145px;height:118px" 
								src="<?php echo base_url(); ?>assets/front/images/nrlm2.png" alt="WBSRLM" title="WBSRLM"></a> 


								<a href="#">
									<img class="img" style="margin-left: 3px; margin-right:8px; padding-top:12px;  width:145px;height:118px" 
									src="<?php echo base_url(); ?>assets/front/images/APY_update.png" alt="Atal Pension Yojana" title="Atal Pension Yojana" /></a>
									<a href="../child/Health_homePage.aspx">
										<img class="img" style="margin-left: 3px; margin-right:8px; padding-top:12px;  width:145px;height:118px"
										src="<?php echo base_url(); ?>assets/front/images/CHCMI.png" alt="CHCMI" title="CHCMI" /></a>
										<a href="http://www.missionnirmalbangla.in/">
											<img class="img" style="margin-left: 3px; margin-right:8px; padding-top:12px;  width:145px;height:118px"
											src="<?php echo base_url(); ?>assets/front/images/mnb.png" alt="Mision Nirmal Bangala" title="Mision Nirmal Bangala" /></a>

										</div> 
									</div>

								</div>


								<div class="clearfix"></div>
								<table  cellspacing="0" cellpadding="0" style="margin-top: 11px;margin-left:20px;  background-color: #f5f7f7; width:17%">
									<tbody><tr>
										<td  style=" padding-left:5px; text-align: left; font-family: Verdana;  height:18px"  >Visitors Online :  <span id="ContentPlaceHolder1_lblactvistr">1</span>
										</td>

									</tr>
									<tr>
										<td style=" padding-left: 5px; text-align: left; font-family: Verdana; height:18px" >No.of Visitors : <span id="ContentPlaceHolder1_lblTotalVisitor">891533</span>
										</td>
									</tr>
									<tr>
										<td style ="margin-bottom:30px">
										</td>
									</tr>



								</tbody></table>    
							</div>                                                                                       

							<div class="container">
								<img src="<?php echo base_url(); ?>assets/front/anandadhara/images/footer_top_bg.gif" style="height:175px; width:100%">


								<div class="content" >
									<ul class="visionList wow fadeInDown delay-05 animated" style="padding-top:20px;margin-bottom:50px" >
										<li>
											<a href="https://india.gov.in/" target="_blank" title="india.gov.in"><img alt="india.gov.in" height="51" src="<?php echo base_url(); ?>assets/front/images/india-gov-logo.png" width="137"></a></li>
										<li>
											<a href="http://mygov.in/" target="_blank" title="MyGov.in"><img alt="MyGov.in" height="51" src="<?php echo base_url(); ?>assets/front/images/my_gov_logo.png" width="61"></a></li>
										<li>
											<a href="http://evisitors.nic.in/public/Home.aspx" target="_blank" title="MyVisit"><img alt="MyVisit" height="51" src="<?php echo base_url(); ?>assets/front/images/my_visit.png" width="98"></a></li>
										<li>
											<a href="http://digitalindia.gov.in/" target="_blank" title="Digital India"><img alt="Digital India" height="51" src="<?php echo base_url(); ?>assets/front/images/digital_india.png" width="78"></a></li>
										<li class="wow fadeInDown delay-02s" >
											<a href="http://mhrd.gov.in/rti_he" title="Right to Information"><img alt="Right to Information" height="51" src="<?php echo base_url(); ?>assets/front/images/rti_logo.png" width="78"></a></li>
										<li>
											<a href="https://data.gov.in/" target="_blank" title="data.gov.in"><img alt="data.gov.in" height="51" src="<?php echo base_url(); ?>assets/front/images/datagov_logo.png" width="110"></a></li>
										<li>
											<a href="http://www.nvsp.in/" target="_blank" title="Online Services for Voters"><img alt="Online Services for Voters" height="51" src="<?php echo base_url(); ?>assets/front/images/onlineservice_logo.png" width="113"></a></li>
										<li>
											<a href="http://dial.gov.in/" target="_blank" title="Dial.gov"><img alt="Dial.gov" height="51" src="<?php echo base_url(); ?>assets/front/images/dialgov-logo.png" width="64"></a></li>

									</ul>
								</div>
							</div>
						</div>

						<div class="copyright" style ="background-color:white;margin-top:20px">
							<hr style ="margin-top: 5px ;margin-bottom: 5px ;border: 0;border-top: 2px solid #197cc5 ;"/>	
								<div class="container">
									<div class="col-md-12">
										<div class="col-md-10">
											<a href="../ProtectedPage/index.aspx" rel ="noopener noreferrer" title="home">Home</a>&nbsp;|&nbsp;
											<a href="#" rel ="noopener noreferrer"  title="Site Map">Site Map</a>&nbsp;|&nbsp;
											<a href="#" rel ="noopener noreferrer"  title="About the Portal">About the Portal</a>&nbsp;|&nbsp;
											<a href="<?php echo base_url(); ?>page/contact-us" rel ="noopener noreferrer" title="Contact Us">Contact Us</a>&nbsp;|&nbsp;
											<a href="#" rel ="noopener noreferrer"  title="Downloads">Downloads</a>
										</div>
										<div class="col-md-2">

											<a href="westbengal_map.aspx" rel ="noopener noreferrer" title="West Bengal Map"><img src="<?php echo base_url(); ?>assets/front/anandadhara/images/westbengal_map_logo.jpg" style="height:50px;width:153px; "></a>
										</div>

									</div>
									<div class="col-md-12">
										<br>

										<p style ="font-size: 14px; color:black;
										line-height: 1.42857143;
										">Disclaimer: Site Contents owned, designed, developed, maintained and updated by the <b>Govt. of West Bengal Rural Development Department</b>. Official Site of Rural Development Department, West Bengal, India </p></div>
									</div>
								</div>

							</div>

						</div>

					</form>