<section id="achive" class="achive section-bg">
      <div class="container">
        <div class="section-title"><h2> INITIATIVES & ACHIEVEMENTS</h2> </div>
        <div class="row">
          <div class="col-sm-4 initbg _inner_achiv">
            <p class="initc">
            </p>
            <p>HIGHEST EVER WIND CAPACITY&nbsp;<span style="font-size: 1rem; font-weight: 400;">ADDITION OF&nbsp;</span><span style="font-size: 1rem; font-weight: 400; font-style: normal;">5.5&nbsp;</span><span style="font-size: 1rem; font-weight: 400;">GW IN 2016-2017</span></p>
            <p></p>
          </div>
          <div class="col-sm-2 initbg _inner_achiv">
            <p class="initc">
              RECORD LOW SOLAR TARIFF <span>RS 2.44/UNIT</span> ACHIEVED IN BHADLA, RAJASTHAN
            </p>
          </div>
          <div class="col-sm-2 initbg _inner_achiv">
            <p class="initc">
              SOLAR PARK SCHEME DOUBLED FROM <span>20GW TO 40GW</span>
            </p>
          </div>
          <div class="col-sm-4 initbg _inner_achiv">
            <p class="initc">
            </p>
            <p>RENEWABLE ENERGY INSTALLED CAPACITY INCREASED 226% IN LAST 5 YEARS</p>
            <p></p>
          </div>
          <div class="col-sm-4 initbg _inner_achiv">
            <p class="initc">
            </p>
            <p><strong>ABOUT 19 TIMES HIGHER SOLAR PUMPS&nbsp;</strong><strong style="font-size: 1rem;">INSTALLED BETWEEN 2014-19&nbsp;</strong><strong style="font-size: 1rem;">| 2.25 LAKH VERSUS UPTO 2014 - 11,626</strong></p>
            <p></p>
          </div>
          <div class="col-sm-2 initbg _inner_achiv">
            <p class="initc">
              SOLAR POWER TARIFF REDUCED BY MORE THAN <span>75%</span> USING PLUG AND PLAY MODEL
            </p>
          </div>
          <div class="col-sm-2 initbg _inner_achiv">
            <p class="initc">
              India now at <span>5TH GLOBAL<br>
              POSITION</span> for overall installed renewable energy capacity
            </p>
          </div>
          <div class="col-sm-4 initbg _inner_achiv">
            <p class="initc">
              RENEWABLE ENERGY HAS A SHARE OF <span>23.39%</span> IN THE TOTAL INSTALLED GENERATION CAPACITY IN THE COUNTRY i.e. <span>368.98 GW</span> (Upto 29th February, 2020).
            </p>
          </div>
          <div class="col-sm-6 initbg _inner_achiv">
            <p class="initc">
              WORLD'S LARGEST RENEWABLE ENERGY EXPANSION PROGRAMME <span>175 GW TILL 2022</span>
            </p>
          </div>
          <div class="col-sm-6 initbg _inner_achiv">
            <p class="initc">
              SOLAR CAPACITY INCREASED IN THE LAST 5.5 YEARS FROM AROUND <span>2.6 GW TO MORE THAN 34 GW</span>
            </p>
          </div>
        </div>
      </div>
    </section>