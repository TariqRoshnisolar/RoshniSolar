<section id="clients" class="clients clients">
      <div class="container">

        <div class="owl-carousel owl-theme" id="clientSlider"> 

          <div class="clientbox ">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-1.png" class="img-fluid">
          </div>

          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-2.png" class="img-fluid">
          </div>

          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-3.png" class="img-fluid">
          </div>

          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-4.png" class="img-fluid" >
          </div>

          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-5.png" class="img-fluid">
          </div>

          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-6.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-7.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-8.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-9.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-10.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-11.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-12.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img src="<?php echo base_url();?>assets/front/img/clients/client-13.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img style="width: 160px;" src="<?php echo base_url();?>assets/front/img/clients/client-14.png" class="img-fluid">
          </div>
          <div class="clientbox">
            <img style="height: 110px;width: 160px;" src="<?php echo base_url();?>assets/front/img/clients/client-15.png" class="img-fluid">
          </div>
        </div>

      </div>
    </section>
