<?php $this->load->view('front/common/default/banner'); ?>
<main id="main">
<?php $this->load->view('front/common/default/about'); ?>
<?php $this->load->view('front/common/default/what_new'); ?>
<?php $this->load->view('front/common/default/videos'); ?>
<?php $this->load->view('front/common/default/achivements'); ?>
<?php $this->load->view('front/common/default/agencies'); ?>
<?php $this->load->view('front/common/default/resources'); ?>
<?php $this->load->view('front/common/default/contact'); ?>
</main>


