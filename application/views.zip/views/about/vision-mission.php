<?php $base_assets_url = '/backend/about/'; ?>

<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>UVSIL</title>
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo $base_assets_url; ?>css/all.css">

<!-- Navigation CSS -->
<link href="<?php echo $base_assets_url; ?>plugins/nav_menu/bootstrap-4-hover-navbar.css" rel="stylesheet">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo $base_assets_url; ?>css/bootstrap.min.css">

<!--Carousel-->
<link href="<?php echo $base_assets_url; ?>plugins/crousal-script/ashwani.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $base_assets_url; ?>plugins/crousal-script/crousal.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $base_assets_url; ?>plugins/crousal-script/clientele.css" rel="stylesheet" type="text/css" />

<!-- My CSS -->
<link rel="stylesheet" href="<?php echo $base_assets_url; ?>css/uvsil.css">
</head>
<body>
<div class="top_bar">
  <div class="container">
    <div class="top_left"> For Complain :<a href="#"> 0000-000-000</a> </div>
    <div class="top_right_bar">
      <ul>
        <li><a href="#">Screen Reader Access</a></li>
        <li><a href="#">Skip to Main Content</a></li>
        <li><a href="#">Feedback</a></li>
        <li><a href="#">Sitemap</a></li>
        <li><a href="#">A-</a></li>
        <li><a href="#">A</a></li>
        <li><a href="#">A+</a></li>
        <li><a href="#">हिन्दी</a></li>
      </ul>
    </div>
  </div>
</div>
<div class="main_header">
  <div class="container">
    <div class="logo"><a href="https://uvsil.in"><img src="<?php echo $base_assets_url; ?>images/logo.png" class="img-fluid" alt="uvsil logo"></a></div>
    <div class="top_right">
      <ul id="clienteleDemo1">
        <li>
          <div class="ccr_clients">
            <div class="img_box"> <img src="<?php echo $base_assets_url; ?>images/clients1.jpg" class="img-fluid" alt="uvsil"> </div>
          </div>
        </li>
        <li>
          <div class="ccr_clients">
            <div class="img_box"> <img src="<?php echo $base_assets_url; ?>images/clients2.jpg" class="img-fluid" alt="uvsil"> </div>
          </div>
        </li>
        <li>
          <div class="ccr_clients">
            <div class="img_box"> <img src="<?php echo $base_assets_url; ?>images/clients3.jpg" class="img-fluid" alt="uvsil"> </div>
          </div>
        </li>
        <li>
          <div class="ccr_clients">
            <div class="img_box"> <img src="<?php echo $base_assets_url; ?>images/clients4.jpg" class="img-fluid" alt="uvsil"> </div>
          </div>
        </li>
        <li>
          <div class="ccr_clients">
            <div class="img_box"> <img src="<?php echo $base_assets_url; ?>images/clients5.jpg" class="img-fluid" alt="uvsil"> </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</div>
<div class="navigtaion_bar">
  <div class="container">
    <nav class="navbar navbar-expand-md navbar-light btco-hover-menu"> 
      <!--<a class="navbar-brand" href="#">Navbar</a>-->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item"> <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a> </li>
          <li class="nav-item active"> <a class="nav-link" href="about-us.html">About Us</a> </li>
          <li class="nav-item"> <a class="nav-link" href="#">Know Solar</a></li>
          <li class="nav-item"> <a class="nav-link" href="#">Our services</a> </li>
          <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Abstract</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="#">Our Advantages</a> </li>
              <li><a class="dropdown-item dropdown-toggle" href="#">Our Solutions</a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <li><a class="dropdown-item" href="#">Grid & Rooftop System</a> </li>
                  <li><a class="dropdown-item" href="#">Solar for Rural Energy System</a></li>
                  <li><a class="dropdown-item" href="#">New Innovations</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Recruitment</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="#">Recruitment Notice</a> </li>
              <li><a class="dropdown-item" href="#">Online Application</a></li>
            </ul>
          </li>
          <li class="nav-item"> <a class="nav-link" href="#">Our products</a> </li>
          <li class="nav-item"> <a class="nav-link" href="gallery.html">Gallery</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contact-us.html">Contact us</a> </li>
        </ul>
      </div>
    </nav>
  </div>
</div>
<div class="innerpage_banner"> <img src="<?php echo $base_assets_url; ?>images/vision-mission.jpg" class="img-fluid"> </div>
<div class="ccr_inner_section">
  <div class="container">
    <div class="row border-bottom">
      <div class="col-md-6">
        <h1>Vision, Mission & Values</h1>
      </div>
      <div class="col-md-6">
        <div class="inner_bread_crumb">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="#">Vision, Mission & Values</a></li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-md-3">
        <div class="left_item">
          <h3 class="text-uppercase">Learn more about Ujjal Vikas</h3>
          <ul>
            <li class="active"> <a href="#">
              <div class="media"> <img src="<?php echo $base_assets_url; ?>images/vision.jpg" class="mr-3" alt="...">
                <div class="media-body">
                  <h5 class="mt-0">Our Heritage</h5>
                </div>
              </div>
              </a> </li>
            <li> <a href="#">
              <div class="media"> <img src="<?php echo $base_assets_url; ?>images/vision.jpg" class="mr-3" alt="...">
                <div class="media-body">
                  <h5 class="mt-0">Vision, Mission & Values</h5>
                </div>
              </div>
              </a> </li>
            <li> <a href="#">
              <div class="media"> <img src="<?php echo $base_assets_url; ?>images/vision.jpg" class="mr-3" alt="...">
                <div class="media-body">
                  <h5 class="mt-0">Company Milestones</h5>
                </div>
              </div>
              </a> </li>
            <li> <a href="#">
              <div class="media"> <img src="<?php echo $base_assets_url; ?>images/vision.jpg" class="mr-3" alt="...">
                <div class="media-body">
                  <h5 class="mt-0">Corporate Policies</h5>
                </div>
              </div>
              </a> </li>
            <li> <a href="#">
              <div class="media"> <img src="<?php echo $base_assets_url; ?>images/vision.jpg" class="mr-3" alt="...">
                <div class="media-body">
                  <h5 class="mt-0">Learn about Solar Power</h5>
                </div>
              </div>
              </a> </li>
          </ul>
        </div>
      </div>
      <div class="col-md-9">
        <div class="vission_right">
          <div class="vission_back">
            <h3 class="mb-0">Vision</h3>
            <p>To be the most admired and responsible solar power company enabling solar everywhere with an international footprint, delivering sustainable value to all stakeholders.</p>
            <h3 class="mt-3 mb-0">Mission</h3>
            <ul class="list_square">
              <li>Delivering benchmark customer experience and thereby earning customer affection</li>
              <li>Executing projects safely and first time correct with predictable benchmark quality, cost and time</li>
              <li>Ensuring cost leadership and growing profitability across all segments in the solar space in focussed geographies</li>
              <li>Being lead adopter of technology with spirit of pioneering and calculated risk taking</li>
              <li>Practicing "leadership with care" by pursuing best practices on care for our environment, community, customers, shareholders, people and creating a culture that will reinforce our values</li>
              <li>Enabling employees and associates to achieve and unleash their full potential to deliver outcomes in a sustainable way</li>
            </ul>
          </div>
          <div class="clearfix"></div>
          <h3 class="pt-5">Values</h3>
          <ul class="values">
            <li>
              <div class="value_box"> <i class="fas fa-shield-alt"></i>
                <h4>Safety</h4>
                <p>Safety is a core value over which no business objective can have a higher priority</p>
              </div>
            </li>
            <li>
              <div class="value_box"> <i class="far fa-clock"></i>
                <h4>Agility</h4>
                <p>Safety is a core value over which no business objective can have a higher priority</p>
              </div>
            </li>
            <li>
              <div class="value_box"> <i class="fas fa-hand-holding-heart"></i>
                <h4>Care</h4>
                <p>Safety is a core value over which no business objective can have a higher priority</p>
              </div>
            </li>
            <li>
              <div class="value_box"> <i class="far fa-handshake"></i>
                <h4>Respect</h4>
                <p>Safety is a core value over which no business objective can have a higher priority</p>
              </div>
            </li>
            <li>
              <div class="value_box"> <i class="fas fa-balance-scale"></i>
                <h4>Ethics</h4>
                <p>Safety is a core value over which no business objective can have a higher priority</p>
              </div>
            </li>
            <li>
              <div class="value_box"> <i class="fas fa-chart-line"></i>
                <h4>Diligence</h4>
                <p>Safety is a core value over which no business objective can have a higher priority</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section ccr_committee">
  <div class="container">
    <div class="title_bar text-center">
      <h2><span class="dark_blue text-white">our </span> Branches</h2>
      <div class="border_blue bg-white"><span></span></div>
    </div>
    <ul id="crousalDemo1">
      <li>
        <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front"> <span class="name">Bihar</span> </div>
            <div class="back">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front"> <span class="name">Utter pradesh</span> </div>
            <div class="back">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front"> <span class="name">assam</span> </div>
            <div class="back">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front"> <span class="name">Karnataka</span> </div>
            <div class="back">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front"> <span class="name">Madhya Pradesh</span> </div>
            <div class="back">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front"> <span class="name">Jharkhand</span> </div>
            <div class="back">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>
<div class="ccr_footer">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="our_links">
          <ul>
            <h5>About us</h5>
            <li><a href="#">Our Heritage</a></li>
            <li><a href="#">Vision, Mission & Values</a></li>
            <li><a href="#">Company Milestones</a></li>
            <li><a href="#">Awards</a></li>
            <li><a href="#">Corporate Policies</a></li>
            <li><a href="#">Learn About Solar</a></li>
            <li><a href="#">Case Studies</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="our_links">
          <ul>
            <h5>Rooftops</h5>
            <li><a href="#">Residential</a></li>
            <li><a href="#">Commercial & Industrial</a></li>
            <li><a href="#">Institutions</a></li>
            <li><a href="#">Financing</a></li>
            <li><a href="#">Remote Monitoring</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="our_links">
          <ul>
            <h5>Manufacturing Edge Media</h5>
            <li><a href="#">Industry Events</a></li>
            <li><a href="#">Press Releases</a></li>
            <li><a href="#">Media Coverage</a></li>
            <li><a href="#">Media Kit</a></li>
            <li><a href="#">Gallery</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="our_links">
          <ul>
            <h5>Contact us</h5>
            <li><a href="#">Offices</a></li>
            <li><a href="#">Find a Dealer</a>
            <li>
            <li><a href="#">Enquiries</a></li>
          </ul>
        </div>
        <div class="social_media">
          <ul>
            <h3>Follow us - </h3>
            <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="bottom_footer">
      <div class="copy_right"> Copyright © Ujjal Vikas Solar India Limited solar panels 2019 All Rights Reserved. </div>
      <div class="design_by"> Design and Developed by :<a href="#"> Trigent</a> </div>
    </div>
  </div>
</div>
<div class="right_product">
  <div class="skool-icon">
    <ul>
      <li class="qlCallus"><a href="#">Call us (Toll free) <span>0000-000-000</span></a></li>
      <li class="qlCu"><a href="#">Contact <br>
        Us</a></li>
      <li class="qlSc"><a href="#">Solar <br>
        Calculator</a></li>
      <li class="qlDl"><a href="#">Dealer <br>
        Locator</a></li>
    </ul>
  </div>
</div>

<!-- Optional JavaScript --> 
<!-- jQuery first, then Popper.js, then Bootstrap JS --> 
<script src="<?php echo $base_assets_url; ?>js/jquery-3.3.1.slim.min.js"></script>
<script src="<?php echo $base_assets_url; ?>js/popper.min.js"></script>
<script src="<?php echo $base_assets_url; ?>js/bootstrap.min.js"></script>

<!-- Navigation JavaScript --> 
<script src="<?php echo $base_assets_url; ?>plugins/nav_menu/bootstrap-4-hover-navbar.js"></script>

<!--nivo slider---------------------------------------------> 
<script src="<?php echo $base_assets_url; ?>js/jquery-1.11.3.min.js"></script>
<link rel="stylesheet" href="<?php echo $base_assets_url; ?>plugins/nivoslider/themes/default/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo $base_assets_url; ?>plugins/nivoslider/nivo-css/nivo-slider.css" type="text/css" media="screen" />

<!--<script type="text/javascript" src="plugins/nivoslider/nivo-js/jquery.min.js"></script>--> 
<script type="text/javascript" src="<?php echo $base_assets_url; ?>plugins/nivoslider/nivo-js/jquery.nivo.slider.js"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('#slider').nivoSlider();			
	});
</script> 
<script>
$(window).scroll(function() {	
	var scroll = $(window).scrollTop();	
		if(scroll >= 200) {	
		$(".navigtaion_bar").addClass("darkHeader");
		} else {	
		$(".navigtaion_bar").removeClass("darkHeader");
	}	
});
</script> 

<!-- carousel--> 
<script type="text/javascript" src="<?php echo $base_assets_url; ?>plugins/crousal-script/jquery.ashwani.js"></script>
<script type="text/javascript" src="<?php echo $base_assets_url; ?>plugins/crousal-script/jquery.crousal.js"></script>
<script type="text/javascript" src="<?php echo $base_assets_url; ?>plugins/crousal-script/jquery.clientele.js"></script>
<script type="text/javascript">    
    $(window).load(function() {
        $("#crousalDemo1").crousal({
            visibleItems:6,
            animationSpeed:1200,
            autoPlay: true,
            autoPlaySpeed: 3000,            
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: { 
                portrait: { 
                    changePoint:550,
                    visibleItems: 2
                }, 
                landscape: { 
                    changePoint:800,
                    visibleItems:3
                },
                tablet: { 
                    changePoint:1024,
                    visibleItems:4
                }
            }
        });	
		$("#clienteleDemo1").clientele({
            visibleItems:3,
            animationSpeed:1200,
            autoPlay: false,
            autoPlaySpeed: 3000,            
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: { 
                portrait: { 
                    changePoint:550,
                    visibleItems: 1
                }, 
                landscape: { 
                    changePoint:800,
                    visibleItems:2
                },
                tablet: { 
                    changePoint:1024,
                    visibleItems:3
                }
            }
        });	
		
		   $("#ashwani").vaish({
            visibleItems:6,
            animationSpeed:1200,
            autoPlay: true,
            autoPlaySpeed: 3000,            
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: { 
                portrait: { 
                    changePoint:550,
                    visibleItems: 2
                }, 
                landscape: { 
                    changePoint:800,
                    visibleItems:3
                },
                tablet: { 
                    changePoint:1024,
                    visibleItems:4
                }
            }
        });
		
					
	   });	   
</script>
</body>
</html>