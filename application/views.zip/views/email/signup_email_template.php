<!DOCTYPE html>
<html>
<head>
</head>
<body>
<table style="width: 100%; height: 100%; min-height: 100%; border-spacing: 0px;" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>
<table style="width: 100%; height: 437px; min-height: 100%; min-width: 300px; max-width: 600px; border-spacing: 0px; background: #ffffff; margin: 60px auto; border-radius: 2px; box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 30px;" cellspacing="0" cellpadding="0">
<tbody>
<tr style="height: 78px;">
<td style="height: 78px;">
<table style="width: 100%; padding: 10px; margin: 0 auto; border-bottom: #ddd solid 1px; background: #fff;" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center"><img style="width: 100px; max-height: 50px;" src="http://www.surveyofindia.gov.in/logo/logo.jpg" title="logo.png" /></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr style="height: 307px;">
<td style="height: 307px;">
<table style="width: 100%; font-size: 14px; padding: 20px;" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>
<p style="font-weight: bold; font-size: 16px; margin: 0 auto 15px auto; text-align: left;">Hay,</p>
<p align="center">Dear Candidate,</p>
<p align="center">You have successfully registered in Surveyindia . Login creditional are below </p>
<p align="center"><strong><span style="color: #003366;">User Id :<?php echo $email; ?></span></strong></p>
<p align="center"><strong><span style="color: #003366;">Password :<?php echo $password; ?></span></strong></p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>
<p></p>
</td>
</tr>
<tr>
<td style="padding: 15px; background: #f5f5f5; color: #000; font-size: 12px; text-align: center;">If you have any comments or questions, please reach us at : <a href="mailto:info@mdemo.us">info@mdemo.us</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table style="width: 100%; padding: 15px; margin: 0 auto; background: #eee; text-align: center;" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="color: #666;"><a style="font-style: italic; color: #666; text-decoration: none;" href="http://surveyindia.gov.in.aspx.ooo/" target="_blank" rel="noopener">Copyright &copy; Surveyindia 2020 | All rights reserved</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body>
</html>