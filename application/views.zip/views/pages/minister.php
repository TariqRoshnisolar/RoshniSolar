<style type="text/css">
 th{font: bold 16px Verdana,Arial,Helvetica,sans-serif;color:#003399;letter-spacing: 2px;margin-bottom:5px;text-align: left;         padding: 6px 6px 6px 12px;/*background: #f7ecdf url(../images/cell2.png) repeat-x;*/background-position: top;}
.style1{width: 100%;border: "0";left: 10px;padding-left: 0px;border-color: #B35E1B;/*-webkit-box-shadow:1px 2px 9px rgba(50, 50, 50, 0.75);-moz-box-shadow:1px 2px 9px rgba(50, 50, 50, 0.75);*/ } 
.td {
            color:#003399;     
        
    }
            
   
    
 th
        {
            font: bold 16px Verdana,Arial,Helvetica,sans-serif;
            color:#003399;
            letter-spacing: 2px;
            margin-bottom:5px;
            text-align: left;
            padding: 6px 6px 6px 12px;
            /*background: #f7ecdf url(../images/cell2.png) repeat-x;*/
            background-position: top;
        }
             
        .style1
        {
            width: 97%;
            left: 10px;
            padding-right: 100px;
            border-color: #B35E1B;
            /*-webkit-box-shadow:9px 9px 9px rgba(50, 50, 50, 0.75);
            -moz-box-shadow:9px 9px 9px rgba(50, 50, 50, 0.75);*/
           
        } 
        .td {
            color:#003399;     
        
    }
            
    </style>

    
     
    <script type="text/javascript">
        $(document).ready(function () {

            $('ul.tabs li').click(function () {
                var tab_id = $(this).attr('data-tab');

                $('ul.tabs li').removeClass('current');
                $('.tab-content').removeClass('current');

                $(this).addClass('current');
                $("#" + tab_id).addClass('current');
            })

        })
</script>
<form method="post" action="<?php echo base_url(); ?>page/minister" id="form1">
    <div class="aspNetHidden">
        <input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
        <input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
        <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="Vtxqu8kYebHjEUi+uAHOmAEO6iZSlAgDjf5n658gg/ko/QGmRRZZd6M95K4I7Zp6/s3jxFIWk5gQEkxvDXHx2L6Yr3NAWNy7U9Ly0TAgyy4=" />
    </div>

    <script type="text/javascript">
    //<![CDATA[
    var theForm = document.forms['form1'];
    if (!theForm) {
        theForm = document.form1;
    }
    function __doPostBack(eventTarget, eventArgument) {
        if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
            theForm.__EVENTTARGET.value = eventTarget;
            theForm.__EVENTARGUMENT.value = eventArgument;
            theForm.submit();
        }
    }
    //]]>
    </script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZAn0GY69x6fFVGAZE00KwsLKlZk0jk-y9I3eMFPVDIJO4CQloC0oT_HxquFSVtCOlA2&amp;t=635793216349294682" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=uHIkleVeDJf4xS50Krz-yJisvXuHyHXu5jZ3KMwbBiQ4I6unIoRh0ex9n1KFDbQRdmw1Fmh7IwJYC5Yjk44QBImZTrIcUutmSiVCHLBw5jOlaposkXLGkLIWw1_iNNzejI9DXphetniXrYqL2V4FoEhX-2Zcs0NeQbDElGXe6lc1&amp;t=72e85ccd" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=Jw6tUGWnA15YEa3ai3FadGjAnQH5-8DFFfgd1AZJuo7YKDMQmnyKgRste-AV_bYiAfI6xynwDOfCm1HegFoxYiZPwk9sl5MUZ8tUBSPauqKNJ4yyCw6wWk_N9eCMsFVcsGTDDqzM54ojzjWaLxsVw_33ywMiiLhFqljoo5wdjZk1&amp;t=72e85ccd" type="text/javascript"></script>
<div class="aspNetHidden">

    <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="7D06D548" />
    <input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
</div>
<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', [], [], [], 90, 'ctl00');
//]]>
</script>




<div >  


    <div class="row head oth_border" style ="background-color:black; margin-left:0px;margin-right:0px">

        <div  >
            <div class="col-md-1"></div>
            <div class="col-md-2">
                <a href="#main_content"><label class="skip skip_border"> &nbsp;&nbsp;Skip to main content &nbsp; &nbsp;</label></a>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-3">
                <input type="text" class="search_textbox" id="search_textbox" name="search_textbox" placeholder="Search- Keyword, Phrase" style="color:#000;">
                <img src="<?php echo base_url(); ?>assets/front/anandadhara/images/search_24.png" class="img in_search" title="Content Search" style="height:auto; width:5%; cursor:pointer;">
                <a href="http://www.google.com/search" rel ="noopener noreferrer" target="_blank" title="Google Search"><img src="<?php echo base_url(); ?>assets/front/anandadhara/images/google_24.png" class="img" style="height:auto; width:5%; "></a>

            </div>
            <div class="col-md-1" >
                <a href="../ProtectedPage/Login.aspx"><label class="skip">Login</label></a>
            </div>
            <div class="col-md-1">
                <input type="button" id="btnincfont" value="A+" style="font-size:.8em" />
                <input type="button" id="btndecfont" value="A-" style="font-size:.8em" />

            </div>



        </div>

    </div>


    <div class="col-md-11" style ="background-color:White;margin-left:4%; margin-right:4% ">




        <!--end of header-->

        <div class="container" >
        	<div class="col-md-12" >
             <img class="img-responsive" src="<?php echo base_url(); ?>assets/front/images/TC_KOB.png"  height="152px" />

         </div>

            <!--<div class="col-sm-3">
            	<div class="support">
            		<i class="fa fa-envelope"></i> wbprd@gmail.com <br>
               	 <i class="fa fa-phone-square"></i> 1234567890
                </div>
            </div>-->
        </div>




        <nav class="navbar navbar-default" role="navigation">

            <div class="container" style ="background:url(<?php echo base_url(); ?>assets/front/images/bg-noise.png) repeat-x; color:white">
              <div class="navbar-header" >
                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

            </div>
            <!--/.navbar-header-->

            <ul class="nav navbar-nav">
               <li ><a href="<?php echo base_url(); ?>">Home</a></li>
               <!-- <li><a href="../ProtectedPage/wb_dictor.aspx" rel ="noopener noreferrer">Panchayats Directory</a></li> -->
               <li class="dropdown">
                   <a href="" class="dropdown-toggle" data-toggle="dropdown">Schemes<b class="caret"></b></a>
                   <ul class="dropdown-menu">
                     <li><a href="../HtmlPage/srd_HomePage.aspx" rel ="noopener noreferrer">SRD</a></li>
                     <li><a href="../anandadhara/index.aspx" rel ="noopener noreferrer">Anandadhara</a></li>
                     <li><a href="../HtmlPage/sahay_homepage.aspx" rel ="noopener noreferrer">Sahay</a></li>
                     <li><a href="../HtmlPage/STARDPARD.aspx" rel ="noopener noreferrer">Starpard</a></li>
                     <li><a href="../HtmlPage/PMGSY.aspx" rel ="noopener noreferrer"> PMGSY</a></li>
                     <li><a href="../HtmlPage/RHOUSING.aspx" rel ="noopener noreferrer"> Rulal Housing</a></li>
                     <li><a href="../HtmlPage/SSECURITY.aspx" rel ="noopener noreferrer">Social Security</a></li>
                     <li> <a href="#" target="_blank" >ISGPP</a></li>
                     <li><a href="../HtmlPage/Chcmi1.aspx" rel ="noopener noreferrer">CHCMI</a></li>
                 </ul>
             </li>


             <li><a href="#">Acts & Rule</a></li>
             <li class="dropdown">
               <a href="" class="dropdown-toggle" data-toggle="dropdown">Organisations & Offices<b class="caret"></b></a>
               <ul class="dropdown-menu">
                 <li><a href="#" rel ="noopener noreferrer">Directorate</a></li>
                 <li><a href="#" rel ="noopener noreferrer">WBSRDA</a></li>
                 <li><a href="#" rel ="noopener noreferrer">WBSRLM</a></li>
                 <li><a href="#" rel ="noopener noreferrer"> PBRSSM</a></li>
                 <li><a href="#" rel ="noopener noreferrer">WBCADC</a></li>
             </ul>
         </li>



         <li><a href="#" rel ="noopener noreferrer">Finance</a></li>
         <li><a href="#">Photo Gallery</a></li>
         <li><a href="#" rel ="noopener noreferrer">Press & Media</a></li>
         <li><a href="<?php echo base_url(); ?>page/contact-us" rel ="noopener noreferrer">Contact Us</a></li>
         <li class="dropdown">
           <a href="<?php echo base_url(); ?>page/contact-us" class="dropdown-toggle" data-toggle="dropdown">Contact Us<b class="caret"></b></a>
           <ul class="dropdown-menu">
           </ul>
       </li>
   </ul>
</div>
<!--/.navbar-collapse-->
<!--/.navbar-->
</nav>





<!--Navbar-->

<!--/.Navbar-->


<!--/start-footer-section-->





<table width="100%" cellpadding="0" cellspacing="0" class="style2" >
    <tr>
        <td>

            <table class="tbl" width="100%" border="0" cellspacing="0" cellpadding="0" align="left">
              <br />


              <tr>
                <th style="width: 100%; text-align:Center; border-width: 0px;">
                    <span id="ContentPlaceHolder1_Label1">MINISTER-IN-CHARGE</span>
                </th>
                <th style="width:0%; text-align: right; border-width: 0px;">

                </th>
            </tr>
        </table>


        <tr>

            <td width="100%">
                <div style ="font-family:georgia;color:#505050; font-size :13px ;text-align: justify; font:verdana; padding :15px;">
                 <div class="busi_content" style="padding-left:10px;font-size:13px;color:black">


                  <div align="justify">
                   <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png"><strong> &nbsp;&nbsp;Shri. Subrata Mukerjee</strong>

               </div>


               <div class="busi_content" style="padding-left:12px; margin-top:10px; margin-bottom:20px">
                  <div align="justify">
                     <p>Minister-In-Charge</p>
                     <p> Department of Panchayats & Rural Development,</p> 
                     <p>Government of West Bengal.</p><br />

                     <p>Joint Administrative Building,</p>
                     <p>Block HC-7, Sector III, SaltLake,</p> 
                     <p>Kolkata &#8211; 700106.</p>                               

                 </div></div>

             </div>

         </td>
     </tr>








     <tr>

        <td width="100%">
            <div style ="font-family:georgia;color:#505050; font-size :13px ;text-align: justify; font:verdana; padding :15px;">
             <div class="busi_content" style="padding-left:10px;font-size:13px;color:black">


              <div align="justify">
               <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png"><strong>  &nbsp;&nbsp;Smt. Chandrima Bhattacharya  </strong>

           </div>


           <div class="busi_content" style="padding-left:12px; margin-top:10px; margin-bottom:20px">
              <div align="justify">
                 <p>Minister of State (Independent Charge),</p>
                 <p> Department of Panchayats & Rural Development,</p> 
                 <p>Government of West Bengal.</p><br />

                 <p>Joint Administrative Building,</p>
                 <p>Block HC-7, Sector III, SaltLake,</p> 
                 <p>Kolkata &#8211; 700106.</p>                               

             </div></div>

         </div>

     </td>
 </tr>
</table>



<br />
<br />
<div align="left" style="padding-left:10px;">
    <a href="javascript:history.back()" class="style1">Back</a>
</div>
<br />


<div class="copyright" style ="background-color:white;margin-top:20px">



    <hr style ="margin-top: 5px ;
    margin-bottom: 5px ;
    border: 0;
    border-top: 2px solid #197cc5 ;"/>	

    <div class="container">
        <div class="col-md-12">

            <div class="col-md-10">
                <a href="<?php echo base_url(); ?>" rel ="noopener noreferrer" title="home">Home</a>&nbsp;|&nbsp;
                <a href="#" rel ="noopener noreferrer"  title="Site Map">Site Map</a>&nbsp;|&nbsp;
                <a href="#" rel ="noopener noreferrer"  title="About the Portal">About the Portal</a>&nbsp;|&nbsp;
                <a href="<?php echo base_url(); ?>page/contact-us" rel ="noopener noreferrer" title="Contact Us">Contact Us</a>&nbsp;|&nbsp;
                <a href="#" rel ="noopener noreferrer"  title="Downloads">Downloads</a>
            </div>
            <div class="col-md-2">

                <a href="westbengal_map.aspx" rel ="noopener noreferrer" title="West Bengal Map"><img src="<?php echo base_url(); ?>assets/front/anandadhara/images/westbengal_map_logo.jpg" style="height:50px;width:153px; "></a>
            </div>

        </div>
        <div class="col-md-12">
            <br>

            <p style ="font-size: 14px; color:black;
            line-height: 1.42857143;
            ">Disclaimer: Site Contents owned, designed, developed, maintained and updated by the <b>Govt. of West Bengal Rural Development Department</b>. Official Site of Rural Development Department, West Bengal, India </p></div>
        </div>
    </div>

</div>

</div>

</form>
