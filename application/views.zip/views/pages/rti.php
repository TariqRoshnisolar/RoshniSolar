<style type="text/css">

th
{
    font: bold 16px Verdana,Arial,Helvetica,sans-serif;
    color:#003399;
    letter-spacing: 2px;
    margin-bottom:5px;
    text-align: left;
    padding: 6px 6px 6px 12px;
    /*background: #f7ecdf url(../images/cell2.png) repeat-x;*/
    background-position: top;
}
     
.style1
{
    width: 100%;
    border: "0";
    left: 10px;
    padding-left: 0px;
    border-color: #B35E1B;
    /*-webkit-box-shadow:1px 2px 9px rgba(50, 50, 50, 0.75);
    -moz-box-shadow:1px 2px 9px rgba(50, 50, 50, 0.75);*/
   
} 
.td {
    color:#003399;     

}
    


th
{
    font: bold 16px Verdana,Arial,Helvetica,sans-serif;
    color:#003399;
    letter-spacing: 2px;
    margin-bottom:5px;
    text-align: left;
    padding: 6px 6px 6px 12px;
    /*background: #f7ecdf url(../images/cell2.png) repeat-x;*/
    background-position: top;
}
     
.style1
{
    width: 97%;
    left: 10px;
    padding-right: 100px;
    border-color: #B35E1B;
    /*-webkit-box-shadow:9px 9px 9px rgba(50, 50, 50, 0.75);
    -moz-box-shadow:9px 9px 9px rgba(50, 50, 50, 0.75);*/
   
} 
.td {
    color:#003399;     

}
    
</style>



<script type="text/javascript">
$(document).ready(function () {

    $('ul.tabs li').click(function () {
        var tab_id = $(this).attr('data-tab');

        $('ul.tabs li').removeClass('current');
        $('.tab-content').removeClass('current');

        $(this).addClass('current');
        $("#" + tab_id).addClass('current');
    })

})
</script>

<form method="post" action="<?php echo base_url(); ?>page/rti" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="x8VQrypOD5n7A99PMgk3eyfx3WSi5ooe9c9G8eRbhAsvAYGIaq26W1v485WWFA8TLeRuXTErRnvnkDI8c+aX/SRQPeCg1kK0LjOcDq3zKMk=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
theForm.__EVENTTARGET.value = eventTarget;
theForm.__EVENTARGUMENT.value = eventArgument;
theForm.submit();
}
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZAn0GY69x6fFVGAZE00KwsLKlZk0jk-y9I3eMFPVDIJO4CQloC0oT_HxquFSVtCOlA2&amp;t=635793216349294682" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=uHIkleVeDJf4xS50Krz-yJisvXuHyHXu5jZ3KMwbBiQ4I6unIoRh0ex9n1KFDbQRdmw1Fmh7IwJYC5Yjk44QBImZTrIcUutmSiVCHLBw5jOlaposkXLGkLIWw1_iNNzejI9DXphetniXrYqL2V4FoEhX-2Zcs0NeQbDElGXe6lc1&amp;t=72e85ccd" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=Jw6tUGWnA15YEa3ai3FadGjAnQH5-8DFFfgd1AZJuo7YKDMQmnyKgRste-AV_bYiAfI6xynwDOfCm1HegFoxYiZPwk9sl5MUZ8tUBSPauqKNJ4yyCw6wWk_N9eCMsFVcsGTDDqzM54ojzjWaLxsVw_33ywMiiLhFqljoo5wdjZk1&amp;t=72e85ccd" type="text/javascript"></script>
<div class="aspNetHidden">

<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="060553C8" />
<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="67rt2oLGE26RnaFKaE017cCdUd41ehLtQYjUQK0JPOS+AY5RJqv0jr0ZvgiikLu8Ob1z8GRJDxJD4i8LhximJTm+HVIPpbVY3ohfauV4ZNxOTgkDfM7PbgPJLhCxTm+kYoxkyVnicz9TYHT/eM0GEKVHna0mdxSMq2d0D/IF9swa6TwRjoeQYxT7zAQntniGfQRRaQHX7VFPp6ZJYuDSvz6HSNMMEoVdHXMIouGUZFMnM6fAumShPO7SFcEu+A8ZsjH3tVinXamgQP+VVP3uYpEJOxZlZ5rULhaBxjJxO0wuaEK/389rMdj6cKLWt676xKhfHyIcuoLfy9RQjszuYT/FDeFGPp9C4Vc1QuwFQczHCCWiu3WYOMtn+408fNS61pDL7UanLEAOMsalMMJBL86opf3Ri3xMH/EkY3eERONE5ZZ1b8CQUhRKUMJeM2llpKlyHZf/OouNmqfS7xpqxjCvwhs6TdlHhHNJWK/JCpRvjqry3l39HhljNFr+J8nBon4bCUypObokISKo1MrhQahC8bIjP0gGCQlNUkxXtUoHHadu5/1nRHh0+HmZ1cYuPEoo9WtSimTbPdAVWP89U/3AFcvFs2svuM93cFooT2QCD5JZT34s/i05avA7QS1emRAFymKPeLFW6jR+b+LeJA866D5gF0ICR4zD7G2iSIZVD1mQxx+2pnrBQYU4kAiov6ZmU6Stx8jtKfl6XllknFHHm4gf6sXWk0h3xz03Zpo=" />
</div>
 <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', [], [], [], 90, 'ctl00');
//]]>
</script>




<div >  


<div class="row head oth_border" style ="background-color:black; margin-left:0px;margin-right:0px">

<div  >
<div class="col-md-1"></div>
<div class="col-md-2">
<a href="#main_content"><label class="skip skip_border"> &nbsp;&nbsp;Skip to main content &nbsp; &nbsp;</label></a>
</div>
<div class="col-md-4"></div>
<div class="col-md-3">
<input type="text" class="search_textbox" id="search_textbox" name="search_textbox" placeholder="Search- Keyword, Phrase" style="color:#000;">
<img src="<?php echo base_url(); ?>assets/front/anandadhara/images/search_24.png" class="img in_search" title="Content Search" style="height:auto; width:5%; cursor:pointer;">
<a href="http://www.google.com/search" rel ="noopener noreferrer" target="_blank" title="Google Search"><img src="<?php echo base_url(); ?>assets/front/anandadhara/images/google_24.png" class="img" style="height:auto; width:5%; "></a>

</div>
<div class="col-md-1" >
<a href="../ProtectedPage/Login.aspx"><label class="skip">Login</label></a>
</div>
<div class="col-md-1">
<input type="button" id="btnincfont" value="A+" style="font-size:.8em" />
<input type="button" id="btndecfont" value="A-" style="font-size:.8em" />

</div>



</div>

</div>


<div class="col-md-11" style ="background-color:White;margin-left:4%; margin-right:4% ">



 
<!--end of header-->

<div class="container" >
    	<div class="col-md-12" >
			<img class="img-responsive" src="<?php echo base_url(); ?>assets/front/images/TC_KOB.png"  height="152px" />
            
    	</div>

        <!--<div class="col-sm-3">
        	<div class="support">
        		<i class="fa fa-envelope"></i> wbprd@gmail.com <br>
           	 <i class="fa fa-phone-square"></i> 1234567890
            </div>
        </div>-->
</div>




<nav class="navbar navbar-default" role="navigation">

   <div class="container" style ="background:url(<?php echo base_url(); ?>assets/front/images/bg-noise.png) repeat-x; color:white">
	<div class="navbar-header" >
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		
	</div>
	<!--/.navbar-header-->

	<ul class="nav navbar-nav" >
			 <li ><a href="<?php echo base_url(); ?>" >Home</a></li>
       <!--  <li><a href="../ProtectedPage/wb_dictor.aspx" rel ="noopener noreferrer">Panchayats Directory</a></li> -->
			   <li class="dropdown">
				<a href="" class="dropdown-toggle" data-toggle="dropdown">Schemes<b class="caret"></b></a>
                 
				<ul class="dropdown-menu">
					
					 <li><a href="../HtmlPage/srd_HomePage.aspx" rel ="noopener noreferrer">SRD</a></li>
					
					 
                    	<li><a href="../anandadhara/index.aspx" rel ="noopener noreferrer">Anandadhara</a></li>
					
					<li><a href="../HtmlPage/sahay_homepage.aspx" rel ="noopener noreferrer">Sahay</a></li>
                   
					<li><a href="../HtmlPage/STARDPARD.aspx" rel ="noopener noreferrer">Starpard</a></li>
					
					<li><a href="../HtmlPage/PMGSY.aspx" rel ="noopener noreferrer"> PMGSY</a></li>
					
					<li><a href="../HtmlPage/RHOUSING.aspx" rel ="noopener noreferrer"> Rulal Housing</a></li>
				
					
				
					<li><a href="../HtmlPage/SSECURITY.aspx" rel ="noopener noreferrer">Social Security</a></li>
                   
					<li> <a href="#" target="_blank" >ISGPP</a></li>
					<li><a href="../HtmlPage/Chcmi1.aspx" rel ="noopener noreferrer">CHCMI</a></li>
					
				</ul>
			  </li>
		   
				
		<li><a href="#">Acts & Rule</a></li>
           <li class="dropdown">
				<a href="" class="dropdown-toggle" data-toggle="dropdown">Organisations & Offices<b class="caret"></b></a>
           <ul class="dropdown-menu">
					
					 <li><a href="#" rel ="noopener noreferrer">Directorate</a></li>
					
					 
					
					<li><a href="#" rel ="noopener noreferrer">WBSRDA</a></li>
                   
					<li><a href="#" rel ="noopener noreferrer">WBSRLM</a></li>
					
					<li><a href="#" rel ="noopener noreferrer"> PBRSSM</a></li>
					
					<li><a href="#" rel ="noopener noreferrer">WBCADC</a></li>
			
				</ul>
			  </li>
		   


           <li><a href="#" rel ="noopener noreferrer">Finance</a></li>
           <li><a href="#">Photo Gallery</a></li>
           <li><a href="#" rel ="noopener noreferrer">Press & Media</a></li>
        
        
           <li><a href="<?php echo base_url(); ?>page/contact-us" rel ="noopener noreferrer">Contact Us</a></li>
              
              <li class="dropdown">
				<a href="<?php echo base_url(); ?>page/contact-us" class="dropdown-toggle" data-toggle="dropdown">Contact Us<b class="caret"></b></a>
				<ul class="dropdown-menu">
					
				</ul>
			  </li>
		</ul>
    </div>
	<!--/.navbar-collapse-->
<!--/.navbar-->

</nav>





<!--Navbar-->

<!--/.Navbar-->


<!--/start-footer-section-->



<table class="style1"  cellpadding="0" cellspacing="0" style ="background-color:#ffffff; margin-right: 0px;">
<tr>
    <td style="padding-left: 0px;" align="center">
       <table style="width: 101%; border-width: 0px;" border="0" cellpadding="0" cellspacing="0">


<br />


<tr>
                <th style="width: 100%; text-align:Center; border-width: 0px;">
                    <span id="ContentPlaceHolder1_Label7">RIGHT TO INFORMATION</span>
                </th>
                <th style="width:0%; text-align: right; border-width: 0px;">
                   
                </th>
            </tr>
        </table>
        </td>
    </tr>    
        <tr>
                <td width="100%" align="justify">
                    <div style ="font-family:georgia;color:#505050; font-size :13px ;text-align: justify; font:verdana; padding :15px;">
                        
                    

  
                         <span id="ContentPlaceHolder1_Label8" style="color:#4d1300; font-weight:bold">RIGHT TO INFORMATION</span>
<div class="busi_content" style="padding-left:40px">
<div align="justify">
            
                   <p> <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk1&#39;,&#39;&#39;)">Right to Information Act,  2005</a></p>
                
            
                    <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a href="notification.aspx">Major Features of RTI Act</a></p>
                
                    <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk2" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk2&#39;,&#39;&#39;)">Public Information officers at various levels of the Department-Notification</a></p>
                
                    <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk3&#39;,&#39;&#39;)">Public Information officers at various levels of the Department</a></p>
              
                    <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a href="notification.aspx">Notifications related to "Right to Information Act'2005"</a></p>
   </div>
</div>
                
            
            
            
            
            
            
              <span id="ContentPlaceHolder1_Label1" style="color:#4d1300; font-weight:bold">VOLUNTARY DISCLOSURE UNDER RTI ACT - 2005</span>
<div class="busi_content" style="padding-left:40px">
<div align="justify">
                    <p> <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk11" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk11&#39;,&#39;&#39;)">Proactive disclosure of P&RD Dept, Govt of WB as per provision of the RTI Act 2005</a>
                
                    <p> <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk12" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk12&#39;,&#39;&#39;)">List of Staff</a></p>
                
                    <p> <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk13" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk13&#39;,&#39;&#39;)">RTI Rules</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk14" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk14&#39;,&#39;&#39;)">Panchayat Samiti</a></p>
                
                    <p> <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk15" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk15&#39;,&#39;&#39;)">Gram Panchayat Sukti Sita</a></p>
                
                    <p> <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_lnk16" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$lnk16&#39;,&#39;&#39;)">Bengali template for Zilla Parishad</a></p>
                
             </div></div>
            <span id="ContentPlaceHolder1_Label2" style="color:#4d1300; font-weight:bold">AMENDMENTS OF WB PANCHAYATS ACTS SINCE 2010</span>
<div class="busi_content" style="padding-left:40px">
<div align="justify">
             
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_1&#39;,&#39;&#39;)">1.1 WB Panchayat (Amendment) Act, 2010</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_2" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_2&#39;,&#39;&#39;)">1.2 WB Panchayat (2nd Amendment) Act, 2010</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_3" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_3&#39;,&#39;&#39;)">2.1 West Bengal Panchayat (Amendment) Ordinance, 2012</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_4" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_4&#39;,&#39;&#39;)">2.2. WB Panchayat (Amendment) Act, 2012</a></p>
                
                    <img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_5" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_5&#39;,&#39;&#39;)">2.3. W.B.Panchayat  (2nd amndt) Act 2012</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_6" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_6&#39;,&#39;&#39;)">2.4. West Bengal Panchayat Elections (Amendment) Ordinance, 2012</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_7" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_7&#39;,&#39;&#39;)">2.5. W.B Panchayat Election (Amndt) Act 2012</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_8" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_8&#39;,&#39;&#39;)">2.6.The W.B.Panchayat Election 2nd (Amndt ) Act 2012</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_9" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_9&#39;,&#39;&#39;)">3.1.The WB Panchayat  Amendment Act,  2014</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_10" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_10&#39;,&#39;&#39;)">3.2. The WB Panchayat Second Amendment Act,  2014</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_11" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_11&#39;,&#39;&#39;)">4.The WB Panchayat  Amendment Act,  2015</a></p>
              
            </div></div>
             <span id="ContentPlaceHolder1_Label3" style="color:#4d1300; font-weight:bold">AMENDMENTS OF WB PANCHAYATS RULES SINCE 2010</span>
<div class="busi_content" style="padding-left:40px">
<div align="justify">
            
            
           
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_12" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_12&#39;,&#39;&#39;)">1.1.  Amendment of WB Panchayat Election Rules, 2006 ( in the year 2012)</a></p>
              
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_13" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_13&#39;,&#39;&#39;)">1. 2. W.B Panchayat (Constitution ) Rules 1975 with all ammendments</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_14" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_14&#39;,&#39;&#39;)">2.  W.B . PS Administration Rules, 2008</a></p>
              
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_15" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_15&#39;,&#39;&#39;)">2.1. 1st  Amendment to W.B. Panchayat PS  Admn. Rules, 2008 ( in the year 2015)</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_16" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_16&#39;,&#39;&#39;)">3. W.B. G.P.Administrative Rule.. 2004</a></p>
              
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_17" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_17&#39;,&#39;&#39;)">3.1.. 2nd Amendment to  W.B. Panchayat GP Admn. Rules, 2004 (in the year 2015)</a>
                
            </div></div>

                          <span id="ContentPlaceHolder1_Label4" style="color:#4d1300; font-weight:bold">WEST BENGAL PANCHAYATS ACT 1973</span>
                        <div class="busi_content" style="padding-left:40px">
                        <div align="justify">
             
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_18" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_18&#39;,&#39;&#39;)">1.1 Cover Page-WB Panchayat Act, 1973</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_19" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_19&#39;,&#39;&#39;)">1.2 WB Panchayat Act Page 1-100</a></p>
               
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_Link_20" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$Link_20&#39;,&#39;&#39;)">1.3 WB Panchayat Act Page Page 101-204</a></p>
                
                     <p><img border="0" src="<?php echo base_url(); ?>assets/front/images/bullet.png">
                    <a id="ContentPlaceHolder1_LinkButton1" href="javascript:__doPostBack(&#39;ctl00$ContentPlaceHolder1$LinkButton1&#39;,&#39;&#39;)">1.4 WB Panchayat Act Page Page i-xiv</a></p>
               
   </div></div></div>
                    </td>
                    </tr>

           
            
           
        </table>


<br />
        <br />
        <div align="left" style="padding-left:10px;">
        <a href="javascript:history.back()" class="style1">Back</a>
        </div>
        <br />
   

<div class="copyright" style ="background-color:white;margin-top:20px">
				
			

<hr style ="margin-top: 5px ;
margin-bottom: 5px ;
border: 0;
border-top: 2px solid #197cc5 ;"/>	

<div class="container">
<div class="col-md-12">

<div class="col-md-10">
<a href="<?php echo base_url(); ?>" rel ="noopener noreferrer" title="home">Home</a>&nbsp;|&nbsp;
<a href="#" rel ="noopener noreferrer"  title="Site Map">Site Map</a>&nbsp;|&nbsp;
<a href="#" rel ="noopener noreferrer"  title="About the Portal">About the Portal</a>&nbsp;|&nbsp;
<a href="<?php echo base_url(); ?>page/contact-us" rel ="noopener noreferrer" title="Contact Us">Contact Us</a>&nbsp;|&nbsp;
<a href="#" rel ="noopener noreferrer"  title="Downloads">Downloads</a>
</div>
<div class="col-md-2">

<a href="westbengal_map.aspx" rel ="noopener noreferrer" title="West Bengal Map"><img src="<?php echo base_url(); ?>assets/front/anandadhara/images/westbengal_map_logo.jpg" style="height:50px;width:153px; "></a>
</div>

</div>
<div class="col-md-12">
<br>

<p style ="font-size: 14px; color:black;
line-height: 1.42857143;
">Disclaimer: Site Contents owned, designed, developed, maintained and updated by the <b>Govt. of West Bengal Rural Development Department</b>. Official Site of Rural Development Department, West Bengal, India </p></div>
</div>
</div>

</div>

</div>

</form>
