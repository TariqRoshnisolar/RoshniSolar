<style>
.successtext{
    font-size: 18px;
}
</style>
<div class="ccr_section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="form_part">
                
                <div class="col-md-6 offset-3">
                <div class="alert alert-success successtext" role="alert">
                    Dear Candicate! Your Application Number <?php echo $login_user_data['application_no'] ?> has been submitted successfully.
                </div>
            </div>

                </div>

            </div>

        </div>

    </div>

</div>