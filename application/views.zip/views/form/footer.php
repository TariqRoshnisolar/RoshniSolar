<script>
$(document).ready(function(){
    var date_format = 'dd-mm-yyyy';
    $('.date').datepicker({
        //  format: "dd-mm-yyyy",
        format: date_format,
        autoclose: true,
    });     
});
</script>
</body>
</html>