<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title>Ujjal Vikas solar india limited</title>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/JS/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/JS/interface.js"></script>
<link href="<?php echo base_url(); ?>assets/front/CSS/IntraPRD.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/front/CSS/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/front/CSS/test.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/front/anandadhara/css/mycss.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        body{margin-top: 0px;margin-bottom: 0px;}
        .lft{left: -177px;}
        .imgrtdwn{border: medium none;padding-bottom: 2px;}
        textarea{resize: none;}
    </style>

  <script type="text/javascript">
      function openinnewTab() {
          var win = window.open("http://asp.net", '_blank');
          win.focus();
      }
   </script>  
<script type="text/javascript">
    $(document).ready(function() {
        var divtxt = $('#fontdiv');
        // Increase Font Size
        $('#btnincfont').click(function() {
            var curSize = divtxt.css('fontSize');
            var newSize = parseInt(curSize.replace("px", "")) + 1;
            $(divtxt).css("fontSize", newSize + "px");
        });
        // Decrease Font Size
        $('#btndecfont').click(function () {
            var curSize = divtxt.css('fontSize');
            var newSize = parseInt(curSize.replace("px", "")) - 1;
            $(divtxt).css("fontSize", newSize + "px");
        })
    });
</script>

 <meta name="viewport" content="width=device-width, initial-scale=1" />
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link href="<?php echo base_url(); ?>assets/front/CSS/bootstrap-3.1.1.min.css" rel="stylesheet" type="text/css" />
 <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo base_url(); ?>assets/front/CSS/style.css" rel="stylesheet" type="text/css" />
	
<script src="<?php echo base_url(); ?>assets/front/JS/jquery.min.js" type="text/javascript"> </script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/JS/bootstrap-3.1.1.min.js"></script>
    


<style type ="text/css">
.topSection_wrapper{background-color:#000}
#topSection{width:994px;margin:0 auto;height:39px;position:relative}
#topSection{width:994px;margin:0 auto;height:39px;position:relative}
.language{width:auto;float:left;color:#fff;margin:0;padding:13px 0 0 15px;padding-left:0;display:block}
.language li{list-style:none;display:block;padding:0 10px 0 0;float:left}
.language li a{color:#fff}
.skipText{display:block;float:left;font-size:12px;color:#1b1b1b;text-transform:uppercase;
          margin:0 0 0 70px;width:150px;padding:12px 10px 0 0;font-style:italic}
.skipText a{color:#1b1b1b;text-decoration:underline;font-weight:bol}\
.skipText a:hover{text-decoration:underline;color:#28b9fa}                       
#fontIncreaser{width:auto;float:right;padding:0;margin:0 0 0 17px}
#fontIncreaser img{float:left;display:block;color:#fff;padding:0 2px;background-color:#dcdada;margin:0 1px 0 0;width:40px;height:35px;text-align:center;vertical-align:middle;}                  
</style>
<script type="text/javascript">
    $(document).ready(function () {
        $('ul.tabs li').click(function () {
            var tab_id = $(this).attr('data-tab');
            $('ul.tabs li').removeClass('current');
            $('.tab-content').removeClass('current');
            $(this).addClass('current');
            $("#" + tab_id).addClass('current');
        })

    })
</script>
<style type ="text/css">    
    .tabcontainer{width: 550px;margin: 0 auto;}
	ul.tabs{margin: 0px;padding: 0px;list-style: none;border: 1px solid #ffffff;background-color: #6699ff;overflow: hidden;}
	ul.tabs li{background: none;color: #ffffff;display: inline-block;padding: 10px 15px;cursor: pointer;float: left;border: 1px solid #ffffff;}
	ul.tabs li.current{background: #0066cc;color: #222;}
	.tab-content{display: none;padding: 8px 15px;border: 1px solid #0066cc;border-top: none;}
	ul.tabs li a {display: inline-block;color: white;text-align: center;padding: 5px 12px;text-decoration: none;transition: 0.3s;
    font-size: 17px;}
    /* Change background color of links on hover */
    ul.tabs li a:hover {background-color: #0066cc; color: black;}
    .tab-content.current{display: inherit;background-color: #ffffff; color: black;}
</style>
</head>
<body class="col-md-12" style =" background-color:#e4eae7">